/*
 * eNACH Banking Application - Authentication Flow
 * 
 * COMPLETE USER FLOWS:
 * 
 * 1. BANK REGISTRATION (All Users):
 *    - Step 1: Logo Setup (Login & Main logos with size adjustment)
 *    - Step 2: Bank Details (Bank Code, Name, IIN, CBS Bank Code, Number of Branches, Website)
 *    - Step 3: Head Office Address & Admin User (Branch details + Admin user creation)
 *    - Step 4: Modules Selection (BASE, ITR Validation, API EMandate with sub-modules)
 *    - Step 5: License Activation (Registration Request Code, Auto/Manual validation)
 * 
 * 2. NORMAL USER - FIRST TIME LOGIN:
 *    - Login with Username & Password
 *    - Google Authenticator Setup (Scan QR, verify 6-digit code)
 *    - Password Change (Current password, new password, confirm password)
 *    - Logout & redirect to Login
 *    - Second Login: Username & Password → Google Auth Code → Dashboard
 * 
 * 3. NORMAL USER - SUBSEQUENT LOGINS:
 *    - Login with Username & Password
 *    - Enter Google Authenticator 6-digit code
 *    - Dashboard
 * 
 * 4. SUPERADMIN USER (All Logins):
 *    - Login with Username & Password
 *    - Enter TOTP code from CRM panel
 *    - Dashboard
 * 
 * TESTING:
 * - Use "superadmin" as username for Superadmin flow
 * - Use any other username for Normal User flow
 * - Click "[Dev] Reset First-Time Setup" on login page to test first-time flow again
 */

import { useState } from "react";
import { LoginPage } from "./components/LoginPage";
import { OTPVerification } from "./components/OTPVerification";
import { BankRegistration } from "./components/BankRegistration";
import { Dashboard } from "./components/Dashboard";
import { GoogleAuthSetup } from "./components/GoogleAuthSetup";
import { PasswordChange } from "./components/PasswordChange";
import { Toaster } from "./components/ui/sonner";

type UserType = "normal" | "superadmin" | null;
type Screen = "registration" | "login" | "googleauth" | "passwordchange" | "otp" | "dashboard";

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("registration");
  const [userType, setUserType] = useState<UserType>(null);
  const [isFirstTimeLogin, setIsFirstTimeLogin] = useState(false);

  const handleRegistrationComplete = () => {
    setCurrentScreen("login");
  };

  const handleLoginSuccess = (type: UserType) => {
    setUserType(type);
    
    // For normal users, check if it's first-time login
    if (type === "normal") {
      // In real app, this would be checked from backend
      // For demo purposes, we'll assume first login if localStorage flag isn't set
      const hasCompletedSetup = localStorage.getItem("user_setup_complete");
      
      if (!hasCompletedSetup) {
        setIsFirstTimeLogin(true);
        setCurrentScreen("googleauth");
      } else {
        setCurrentScreen("otp");
      }
    } else {
      // Superadmin goes directly to OTP
      setCurrentScreen("otp");
    }
  };

  const handleGoogleAuthSetupComplete = () => {
    // After Google Auth setup, go to password change
    setCurrentScreen("passwordchange");
  };

  const handlePasswordChangeComplete = () => {
    // After password change, mark setup as complete and logout
    localStorage.setItem("user_setup_complete", "true");
    setIsFirstTimeLogin(false);
    setUserType(null);
    setCurrentScreen("login");
  };

  const handleOTPSuccess = () => {
    setCurrentScreen("dashboard");
  };

  const handleLogout = () => {
    setCurrentScreen("login");
    setUserType(null);
  };

  return (
    <>
      {currentScreen === "registration" && (
        <BankRegistration onComplete={handleRegistrationComplete} />
      )}
      {currentScreen === "login" && (
        <LoginPage onLoginSuccess={handleLoginSuccess} />
      )}
      {currentScreen === "googleauth" && (
        <GoogleAuthSetup onComplete={handleGoogleAuthSetupComplete} />
      )}
      {currentScreen === "passwordchange" && (
        <PasswordChange onComplete={handlePasswordChangeComplete} />
      )}
      {currentScreen === "otp" && userType && (
        <OTPVerification userType={userType} onOTPSuccess={handleOTPSuccess} />
      )}
      {currentScreen === "dashboard" && (
        <Dashboard onLogout={handleLogout} />
      )}
      <Toaster position="top-right" richColors />
    </>
  );
}