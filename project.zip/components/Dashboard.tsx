import { useState } from "react";
import { 
  Home, 
  Users, 
  FileText, 
  Settings, 
  LogOut, 
  ChevronRight,
  ChevronDown,
  Menu,
  X,
  BarChart3,
  Wrench,
  AlertTriangle,
  Layers
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { CertificateConfigurations } from "./CertificateConfigurations";
import { ApiConfigurations } from "./ApiConfigurations";
import { AppParameters } from "./AppParameters";
import { MailSmsConfigurations } from "./MailSmsConfigurations";
import { ProductConfigurations } from "./ProductConfigurations";
import { Troubleshooting } from "./Troubleshooting";
import { BankMaster } from "./BankMaster";
import { BranchMaster } from "./BranchMaster";
import { RoleMaster } from "./RoleMaster";
import { PermissionMaster } from "./PermissionMaster";
import { UserMaster } from "./UserMaster";
import { BankIINMaster } from "./BankIINMaster";

interface DashboardProps {
  onLogout: () => void;
}

export function Dashboard({ onLogout }: DashboardProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [expandedMenu, setExpandedMenu] = useState<string | null>(null);
  const [activeScreen, setActiveScreen] = useState<string>("Dashboard");

  // Mock data for ITR Request chart
  const chartData = [
    { date: '2025-11-20', Success: 1.2, Failed: 0.3 },
    { date: '2025-11-21', Success: 1.5, Failed: 0.2 },
    { date: '2025-11-22', Success: 1.8, Failed: 0.4 },
    { date: '2025-11-23', Success: 1.3, Failed: 0.5 },
    { date: '2025-11-24', Success: 2.1, Failed: 0.3 },
    { date: '2025-11-25', Success: 1.7, Failed: 0.2 },
    { date: '2025-11-26', Success: 1.9, Failed: 0.4 },
  ];

  const menuItems = [
    { icon: Home, label: "Dashboard", active: true, hasSubmenu: false },
    { 
      icon: Users, 
      label: "Master", 
      active: false, 
      hasSubmenu: true,
      subItems: [
        "Bank",
        "Branch",
        "Role",
        "Permission",
        "User",
        "Bank IIN"
      ]
    },
    { icon: Layers, label: "Miscellaneous", active: false, hasSubmenu: true },
    { icon: FileText, label: "Aadhaar Seeding", active: false, hasSubmenu: false },
    { 
      icon: Settings, 
      label: "App Configurations", 
      active: false, 
      hasSubmenu: true,
      subItems: [
        "Certificate Configurations",
        "Api Configurations",
        "App Parameters",
        "Mail and SMS Configurations",
        "Product Configurations",
        "TroubleShooting"
      ]
    },
    { icon: Wrench, label: "Utility", active: false, hasSubmenu: true },
    { icon: AlertTriangle, label: "Troubleshooting", active: false, hasSubmenu: false },
    { icon: BarChart3, label: "Report", active: false, hasSubmenu: true },
  ];

  const toggleMenu = (label: string) => {
    setExpandedMenu(expandedMenu === label ? null : label);
  };

  return (
    <div className="h-screen bg-gray-50 flex overflow-hidden">
      {/* Left Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-gradient-to-b from-[#0a2351] to-[#1a3a6b] transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'} transition-transform duration-300`}>
        {/* Logo Section */}
        <div className="p-6 border-b border-blue-800/30">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
              <span className="text-blue-900">eN</span>
            </div>
            <div>
              <div className="text-white">eNACH</div>
              <div className="text-xs text-blue-300">@ServiceNow</div>
            </div>
          </div>
          
          {/* Close button for mobile */}
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden absolute top-4 right-4 p-2 text-white hover:bg-white/10 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Menu Items */}
        <nav className="p-4 space-y-1 overflow-y-auto" style={{ maxHeight: 'calc(100vh - 120px)' }}>
          {menuItems.map((item, index) => (
            <div key={index}>
              <button
                onClick={() => item.hasSubmenu && toggleMenu(item.label)}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition-colors ${
                  item.active 
                    ? 'bg-blue-600 text-white' 
                    : 'text-blue-100 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center gap-3">
                  <item.icon className="w-5 h-5" />
                  <span className="text-sm">{item.label}</span>
                </div>
                {item.hasSubmenu && (
                  expandedMenu === item.label ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )
                )}
              </button>
              
              {/* Submenu Items */}
              {item.hasSubmenu && expandedMenu === item.label && item.subItems && (
                <div className="mt-1 ml-4 space-y-1">
                  {item.subItems.map((subItem, subIndex) => (
                    <button
                      key={subIndex}
                      onClick={() => {
                        setActiveScreen(subItem);
                        setSidebarOpen(false);
                      }}
                      className={`w-full text-left block px-4 py-2 text-xs rounded-lg transition-colors ${
                        activeScreen === subItem
                          ? "bg-blue-500 text-white"
                          : "text-blue-200 hover:bg-white/10"
                      }`}
                    >
                      {subItem}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>
      </aside>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header */}
        <header className="bg-white border-b border-gray-200 flex-shrink-0">
          <div className="px-4 py-2">
            <div className="flex items-center justify-between">
              {/* Left: Menu button & Company Info */}
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setSidebarOpen(true)}
                  className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"
                >
                  <Menu className="w-5 h-5" />
                </button>
                <div>
                  <h2 className="text-gray-800 text-sm">SOFT-TECH SOLUTIONS</h2>
                  <div className="flex items-center gap-2 text-xs text-gray-600">
                    <span>Welcome, <span className="text-blue-600">Akash Gupta</span></span>
                    <span className="hidden md:inline">•</span>
                    <span className="hidden md:inline">Last Login: 25-11-2025</span>
                  </div>
                </div>
              </div>

              {/* Right: User Menu & Logout */}
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs">AG</span>
                  </div>
                  <div className="hidden md:block">
                    <div className="text-xs text-gray-800">Akash Gupta</div>
                    <div className="text-xs text-gray-500">Dashboard</div>
                  </div>
                </div>
                <button
                  onClick={onLogout}
                  className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                  title="Logout"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Breadcrumb */}
          <div className="px-4 pb-2">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Home className="w-4 h-4" />
              <ChevronRight className="w-4 h-4" />
              <span className="text-blue-600">{activeScreen}</span>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-hidden">
          {activeScreen === "Bank" ? (
            <BankMaster />
          ) : activeScreen === "Branch" ? (
            <BranchMaster />
          ) : activeScreen === "Role" ? (
            <RoleMaster />
          ) : activeScreen === "Permission" ? (
            <PermissionMaster />
          ) : activeScreen === "User" ? (
            <UserMaster />
          ) : activeScreen === "Bank IIN" ? (
            <BankIINMaster />
          ) : activeScreen === "Certificate Configurations" ? (
            <CertificateConfigurations />
          ) : activeScreen === "Api Configurations" ? (
            <ApiConfigurations />
          ) : activeScreen === "App Parameters" ? (
            <AppParameters />
          ) : activeScreen === "Mail and SMS Configurations" ? (
            <MailSmsConfigurations />
          ) : activeScreen === "Product Configurations" ? (
            <ProductConfigurations onBack={() => setActiveScreen("Dashboard")} />
          ) : activeScreen === "Troubleshooting" || activeScreen === "TroubleShooting" ? (
            <Troubleshooting />
          ) : (
            <div className="h-full p-4 overflow-y-auto">
          {/* Action Button */}
          <div className="mb-4">
            <button className="px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors shadow-lg shadow-blue-200">
              Add Transaction Request
            </button>
          </div>

          {/* ITR Request Chart */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 mb-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-800 text-sm">ITR Request</h3>
              <button className="p-1.5 hover:bg-gray-100 rounded-lg">
                <Menu className="w-4 h-4 text-gray-500" />
              </button>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 12 }}
                  stroke="#999"
                />
                <YAxis 
                  tick={{ fontSize: 12 }}
                  stroke="#999"
                />
                <Tooltip />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="Success" 
                  stroke="#10b981" 
                  strokeWidth={2}
                  dot={{ fill: '#10b981', r: 4 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="Failed" 
                  stroke="#ef4444" 
                  strokeWidth={2}
                  dot={{ fill: '#ef4444', r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Today Transaction Table */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-4 border-b border-gray-200">
              <h3 className="text-gray-800 text-sm">Today Transaction</h3>
            </div>
            
            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs text-gray-600">Request Date</th>
                    <th className="px-4 py-2 text-left text-xs text-gray-600">Account Details</th>
                    <th className="px-4 py-2 text-left text-xs text-gray-600">Initiator From</th>
                    <th className="px-4 py-2 text-left text-xs text-gray-600">Request API Type</th>
                    <th className="px-4 py-2 text-left text-xs text-gray-600">Response To ITR</th>
                    <th className="px-4 py-2 text-left text-xs text-gray-600">API Acknowledge</th>
                  </tr>
                </thead>
                <tbody>
                  {/* Empty State */}
                  <tr>
                    <td colSpan={6} className="px-4 py-8">
                      <div className="flex flex-col items-center justify-center text-center">
                        <div className="w-40 h-32 mb-3">
                          <svg viewBox="0 0 200 150" className="w-full h-full">
                            {/* Server/Database illustration */}
                            <g>
                              {/* Database stack */}
                              <rect x="40" y="40" width="40" height="60" fill="#e5e7eb" stroke="#9ca3af" strokeWidth="2" rx="2" />
                              <rect x="40" y="48" width="40" height="8" fill="#d1d5db" />
                              <rect x="40" y="64" width="40" height="8" fill="#d1d5db" />
                              <rect x="40" y="80" width="40" height="8" fill="#d1d5db" />
                              
                              {/* Monitor */}
                              <rect x="90" y="50" width="70" height="45" fill="#f3f4f6" stroke="#9ca3af" strokeWidth="2" rx="2" />
                              <rect x="95" y="55" width="60" height="30" fill="#e5e7eb" />
                              <line x1="110" y1="60" x2="135" y2="60" stroke="#9ca3af" strokeWidth="2" />
                              <line x1="110" y1="67" x2="140" y2="67" stroke="#9ca3af" strokeWidth="1.5" />
                              <line x1="110" y1="74" x2="130" y2="74" stroke="#9ca3af" strokeWidth="1.5" />
                              
                              {/* Person */}
                              <circle cx="170" cy="65" r="8" fill="#6b7280" />
                              <path d="M 170 73 L 170 95 M 160 85 L 180 85 M 170 95 L 165 110 M 170 95 L 175 110" stroke="#6b7280" strokeWidth="3" strokeLinecap="round" />
                            </g>
                          </svg>
                        </div>
                        <p className="text-gray-500 text-sm">No transactions found for today</p>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
              <div className="text-sm text-gray-600">
                Showing 0 to 0 of 0 entries
              </div>
              <div className="flex items-center gap-2">
                <select className="px-3 py-1.5 border border-gray-300 rounded text-sm">
                  <option>10</option>
                  <option>25</option>
                  <option>50</option>
                  <option>100</option>
                </select>
              </div>
            </div>
          </div>
            </div>
          )}
        </main>

        {/* Footer */}
        <footer className="bg-white border-t border-gray-200 px-6 py-3">
          <div className="flex items-center justify-between text-xs text-gray-600">
            <div className="flex items-center gap-4">
              <span>Version: 25.11.08</span>
              <span>•</span>
              <span>Licence Expire: <span className="text-blue-600">01-12-2025</span> to ITR: <span className="text-blue-600">01-12-2025</span></span>
            </div>
            <div>
              Copyright © 2025 <span className="text-blue-600">SOFT-TECH SOLUTIONS</span>. All rights reserved - eNACH Solutions
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}