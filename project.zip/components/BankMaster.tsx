import { useState } from "react";
import { 
  Building2,
  MapPin,
  Phone,
  Mail,
  Globe,
  Edit3,
  Save,
  X,
  Check,
  FileText,
  Users,
  Calendar,
  Shield,
  Package,
  RefreshCw
} from "lucide-react";
import { LicenseManagement } from "./LicenseManagement";

export function BankMaster() {
  const [isEditMode, setIsEditMode] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showRenewalModal, setShowRenewalModal] = useState(false);

  // Bank details from registration (Step 1)
  const [bankDetails, setBankDetails] = useState({
    // Basic Information
    bankName: "State Bank of India",
    bankShortName: "SBI",
    bankCode: "SBIN",
    ifscCode: "SBIN0001234",
    
    // Contact Information
    registeredAddress: "State Bank Bhavan, Madame Cama Road",
    city: "Mumbai",
    state: "Maharashtra",
    pincode: "400021",
    country: "India",
    phoneNumber: "1800-11-2211",
    email: "customercare@sbi.co.in",
    website: "www.onlinesbi.sbi",
    
    // Additional Details
    establishedDate: "1955-07-01",
    chairmanName: "Mr. Dinesh Kumar Khara",
    headOffice: "Mumbai, Maharashtra",
    branchCount: "22405",
    
    // Module and License Details
    modules: "eNACH Registration, Payment Gateway, Mandate Management, API Integration",
    expiryDate: "2025-12-31",
    
    // Registration Details (from setup)
    registrationDate: "2025-01-15",
    registeredBy: "Akash Gupta",
    lastModified: "2025-01-15",
    modifiedBy: "Akash Gupta"
  });

  const [editedDetails, setEditedDetails] = useState(bankDetails);

  const handleEdit = () => {
    setIsEditMode(true);
    setEditedDetails(bankDetails);
  };

  const handleCancel = () => {
    setIsEditMode(false);
    setEditedDetails(bankDetails);
  };

  const handleSave = () => {
    setBankDetails(editedDetails);
    setIsEditMode(false);
    setShowSuccess(true);
    
    // Update last modified details
    const now = new Date().toISOString().split('T')[0];
    setBankDetails(prev => ({
      ...editedDetails,
      lastModified: now,
      modifiedBy: "Akash Gupta"
    }));

    setTimeout(() => setShowSuccess(false), 3000);
  };

  const handleRenewal = () => {
    setShowRenewalModal(true);
  };

  const handleLicenseManagementComplete = (data: any) => {
    if (data.action === 'renewal') {
      const currentExpiry = new Date(bankDetails.expiryDate);
      const newExpiry = new Date(currentExpiry);
      newExpiry.setMonth(newExpiry.getMonth() + data.duration);
      
      setBankDetails(prev => ({
        ...prev,
        expiryDate: newExpiry.toISOString().split('T')[0],
        lastModified: new Date().toISOString().split('T')[0],
        modifiedBy: "Akash Gupta"
      }));
    } else if (data.action === 'add-module') {
      // Get module names from IDs
      const moduleNames = data.modules.map((id: string) => {
        const moduleMap: { [key: string]: string } = {
          'base': 'BASE',
          'itr': 'ITR VALIDATION',
          'payment-gateway': 'Payment Gateway',
          'api-emandate': 'API EMandate',
          'mandate-mgmt': 'Mandate Management'
        };
        return moduleMap[id] || id;
      });
      
      // Add new modules to existing ones
      const currentModules = bankDetails.modules.split(',').map(m => m.trim());
      const updatedModules = [...new Set([...currentModules, ...moduleNames])].join(', ');
      
      setBankDetails(prev => ({
        ...prev,
        modules: updatedModules,
        lastModified: new Date().toISOString().split('T')[0],
        modifiedBy: "Akash Gupta"
      }));
    }
    
    setShowRenewalModal(false);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const handleChange = (field: string, value: string) => {
    setEditedDetails(prev => ({ ...prev, [field]: value }));
  };

  const InfoCard = ({ icon: Icon, title, children }: any) => (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
      <div className="flex items-center gap-3 mb-4 pb-3 border-b border-gray-200">
        <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
          <Icon className="w-5 h-5 text-white" />
        </div>
        <h3 className="text-base text-gray-800">{title}</h3>
      </div>
      {children}
    </div>
  );

  const InfoRow = ({ label, value, field, type = "text", readOnly = false }: any) => (
    <div className="mb-4 last:mb-0">
      <label className="block text-xs text-gray-600 mb-1.5">{label}</label>
      {isEditMode && !readOnly ? (
        <input
          type={type}
          value={editedDetails[field as keyof typeof editedDetails]}
          onChange={(e) => handleChange(field, e.target.value)}
          className="w-full px-3 py-2 border border-blue-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm bg-blue-50"
        />
      ) : (
        <div className="px-3 py-2 bg-gray-50 rounded-lg text-sm text-gray-800 border border-gray-200">
          {value || "—"}
        </div>
      )}
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Success Message */}
      {showSuccess && (
        <div className="fixed top-4 right-4 z-50 bg-green-500 text-white px-6 py-3 rounded-lg shadow-xl flex items-center gap-3 animate-slide-in">
          <Check className="w-5 h-5" />
          <span>Bank details updated successfully!</span>
        </div>
      )}

      {/* Header Section */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              <Building2 className="w-8 h-8 text-white" />
            </div>
            <div>
              <h2 className="text-xl text-gray-800">Bank Master</h2>
              <p className="text-sm text-gray-600">View and manage your bank information</p>
            </div>
          </div>
          
          {!isEditMode ? (
            <button
              onClick={handleEdit}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-lg transition-all shadow-lg shadow-blue-200"
            >
              <Edit3 className="w-4 h-4" />
              <span>Edit Details</span>
            </button>
          ) : (
            <div className="flex items-center gap-3">
              <button
                onClick={handleCancel}
                className="flex items-center gap-2 px-5 py-2.5 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
                <span>Cancel</span>
              </button>
              <button
                onClick={handleSave}
                className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-lg transition-all shadow-lg shadow-green-200"
              >
                <Save className="w-4 h-4" />
                <span>Save Changes</span>
              </button>
            </div>
          )}
        </div>

        {/* Edit Mode Banner */}
        {isEditMode && (
          <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
              <Edit3 className="w-4 h-4 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-blue-900">Edit Mode Active</p>
              <p className="text-xs text-blue-700">Make changes to bank details and click Save Changes when done</p>
            </div>
          </div>
        )}
      </div>

      {/* Content Section */}
      <div className="flex-1 overflow-y-auto px-6 py-6">
        <div className="max-w-7xl mx-auto">
          {/* Basic Information Section */}
          <div className="grid grid-cols-2 gap-6 mb-6">
            <InfoCard icon={Building2} title="Basic Information">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <InfoRow 
                    label="Bank Name" 
                    value={bankDetails.bankName}
                    field="bankName"
                  />
                </div>
                <InfoRow 
                  label="Short Name" 
                  value={bankDetails.bankShortName}
                  field="bankShortName"
                />
                <InfoRow 
                  label="Bank Code" 
                  value={bankDetails.bankCode}
                  field="bankCode"
                />
                <InfoRow 
                  label="IFSC Code" 
                  value={bankDetails.ifscCode}
                  field="ifscCode"
                />
                <InfoRow 
                  label="Established Date" 
                  value={bankDetails.establishedDate}
                  field="establishedDate"
                  type="date"
                />
              </div>
            </InfoCard>

            <InfoCard icon={Users} title="Organization Details">
              <InfoRow 
                label="Chairman Name" 
                value={bankDetails.chairmanName}
                field="chairmanName"
              />
              <InfoRow 
                label="Head Office" 
                value={bankDetails.headOffice}
                field="headOffice"
              />
              <InfoRow 
                label="Total Branches" 
                value={bankDetails.branchCount}
                field="branchCount"
              />
            </InfoCard>
          </div>

          {/* Module and License Information */}
          <div className="mb-6">
            <InfoCard icon={Package} title="Module & License Information">
              <div className="grid grid-cols-1 gap-4">
                <div className="mb-4 last:mb-0">
                  <label className="block text-xs text-gray-600 mb-1.5">Active Modules</label>
                  {isEditMode ? (
                    <textarea
                      value={editedDetails.modules}
                      onChange={(e) => handleChange("modules", e.target.value)}
                      rows={2}
                      className="w-full px-3 py-2 border border-blue-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm bg-blue-50 resize-none"
                      placeholder="e.g., eNACH Registration, Payment Gateway, Mandate Management"
                    />
                  ) : (
                    <div className="px-3 py-2 bg-gray-50 rounded-lg text-sm text-gray-800 border border-gray-200 min-h-[60px]">
                      {bankDetails.modules || "—"}
                    </div>
                  )}
                </div>
                
                <div className="grid grid-cols-2 gap-4 items-end">
                  <div className="mb-4 last:mb-0">
                    <label className="block text-xs text-gray-600 mb-1.5">License Expiry Date</label>
                    {/* Expiry date is not editable - can only be changed through Modify License */}
                    {isEditMode ? (
                      <div className="px-3 py-2 bg-gray-100 rounded-lg text-sm text-gray-600 border border-gray-300 cursor-not-allowed">
                        {editedDetails.expiryDate || "—"}
                      </div>
                    ) : (
                      <div className="flex items-center gap-3">
                        <div className="flex-1 px-3 py-2 bg-gray-50 rounded-lg text-sm text-gray-800 border border-gray-200">
                          {bankDetails.expiryDate || "—"}
                        </div>
                        {(() => {
                          const expiry = new Date(bankDetails.expiryDate);
                          const today = new Date();
                          const daysLeft = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                          
                          if (daysLeft < 0) {
                            return (
                              <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-xs">
                                Expired
                              </span>
                            );
                          } else if (daysLeft <= 30) {
                            return (
                              <span className="px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-xs">
                                {daysLeft} days left
                              </span>
                            );
                          } else {
                            return (
                              <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs">
                                Active
                              </span>
                            );
                          }
                        })()}
                      </div>
                    )}
                  </div>
                  
                  {!isEditMode && (
                    <button
                      onClick={handleRenewal}
                      className="flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-lg transition-all shadow-lg shadow-emerald-200 h-[42px]"
                    >
                      <RefreshCw className="w-4 h-4" />
                      <span>Modify License</span>
                    </button>
                  )}
                </div>
              </div>
            </InfoCard>
          </div>

          {/* Contact Information Section */}
          <div className="grid grid-cols-2 gap-6 mb-6">
            <InfoCard icon={MapPin} title="Address Information">
              <InfoRow 
                label="Registered Address" 
                value={bankDetails.registeredAddress}
                field="registeredAddress"
              />
              <div className="grid grid-cols-2 gap-4">
                <InfoRow 
                  label="City" 
                  value={bankDetails.city}
                  field="city"
                />
                <InfoRow 
                  label="State" 
                  value={bankDetails.state}
                  field="state"
                />
                <InfoRow 
                  label="Pincode" 
                  value={bankDetails.pincode}
                  field="pincode"
                />
                <InfoRow 
                  label="Country" 
                  value={bankDetails.country}
                  field="country"
                />
              </div>
            </InfoCard>

            <InfoCard icon={Phone} title="Contact Information">
              <InfoRow 
                label="Phone Number" 
                value={bankDetails.phoneNumber}
                field="phoneNumber"
                type="tel"
              />
              <InfoRow 
                label="Email Address" 
                value={bankDetails.email}
                field="email"
                type="email"
              />
              <InfoRow 
                label="Website" 
                value={bankDetails.website}
                field="website"
                type="url"
              />
            </InfoCard>
          </div>

          {/* System Information Section */}
          <InfoCard icon={Shield} title="System Information">
            <div className="grid grid-cols-4 gap-4">
              <InfoRow 
                label="Registration Date" 
                value={bankDetails.registrationDate}
                field="registrationDate"
                readOnly
              />
              <InfoRow 
                label="Registered By" 
                value={bankDetails.registeredBy}
                field="registeredBy"
                readOnly
              />
              <InfoRow 
                label="Last Modified" 
                value={bankDetails.lastModified}
                field="lastModified"
                readOnly
              />
              <InfoRow 
                label="Modified By" 
                value={bankDetails.modifiedBy}
                field="modifiedBy"
                readOnly
              />
            </div>
          </InfoCard>

          {/* Info Banner */}
          <div className="mt-6 p-4 bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-amber-500 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                <FileText className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-sm text-amber-900 mb-1">Important Note</p>
                <p className="text-xs text-amber-800">
                  These details were captured during the initial bank registration process. You can update them here as needed. 
                  Any changes will be logged with timestamp and user information for audit purposes.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* License Management Wizard */}
      {showRenewalModal && (
        <LicenseManagement
          onClose={() => setShowRenewalModal(false)}
          onComplete={handleLicenseManagementComplete}
          currentExpiryDate={bankDetails.expiryDate}
          currentModules={bankDetails.modules}
        />
      )}
    </div>
  );
}
