import { useState, useRef, KeyboardEvent, ClipboardEvent } from "react";

type UserType = "normal" | "superadmin";

interface OTPVerificationProps {
  userType: UserType;
  onOTPSuccess: () => void;
}

export function OTPVerification({ userType, onOTPSuccess }: OTPVerificationProps) {
  const [otp, setOtp] = useState<string[]>(["", "", "", "", "", ""]);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const handleChange = (index: number, value: string) => {
    // Only allow numbers
    if (value && !/^\d$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Move to next input if value is entered
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: KeyboardEvent<HTMLInputElement>) => {
    // Move to previous input on backspace if current input is empty
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData("text").trim();
    
    // Only process if it's exactly 6 digits
    if (/^\d{6}$/.test(pastedData)) {
      const newOtp = pastedData.split("");
      setOtp(newOtp);
      inputRefs.current[5]?.focus();
    }
  };

  const handleVerify = () => {
    const otpValue = otp.join("");
    if (otpValue.length === 6) {
      console.log("OTP Verified:", otpValue);
      onOTPSuccess();
    }
  };

  const isSuperAdmin = userType === "superadmin";

  return (
    <div className="h-screen relative flex items-center justify-center p-6 bg-gray-50 overflow-hidden">
      {/* Decorative Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-64 h-64 bg-blue-100 rounded-full opacity-20 blur-3xl" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-200 rounded-full opacity-20 blur-3xl" />
      </div>

      {/* OTP Card */}
      <div className="relative z-10 w-full max-w-6xl h-[calc(100vh-3rem)] bg-white rounded-2xl shadow-2xl overflow-hidden">
        <div className="grid md:grid-cols-[1fr_1.5fr] gap-0 h-full">
          {/* Left Side - Branding */}
          <div className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 p-12 flex flex-col items-center justify-center text-white relative overflow-hidden">
            {/* Decorative Circuit Pattern */}
            <div className="absolute inset-0 opacity-10">
              <svg className="w-full h-full" viewBox="0 0 400 400" fill="none">
                <path d="M50 100 L150 100 L150 200 L250 200" stroke="white" strokeWidth="2" />
                <path d="M100 50 L100 150 L200 150 L200 250" stroke="white" strokeWidth="2" />
                <path d="M200 100 L300 100 L300 200 L350 200" stroke="white" strokeWidth="2" />
                <path d="M150 250 L250 250 L250 350" stroke="white" strokeWidth="2" />
                <circle cx="150" cy="100" r="4" fill="white" />
                <circle cx="150" cy="200" r="4" fill="white" />
                <circle cx="100" cy="150" r="4" fill="white" />
                <circle cx="200" cy="150" r="4" fill="white" />
                <circle cx="300" cy="100" r="4" fill="white" />
                <circle cx="250" cy="250" r="4" fill="white" />
              </svg>
            </div>

            {/* Rupee Symbol with Circuit Lines */}
            <div className="relative z-10 mb-8">
              <div className="w-48 h-48 flex items-center justify-center relative">
                {/* Circuit lines extending from rupee */}
                <svg className="absolute inset-0 w-full h-full" viewBox="0 0 200 200" fill="none">
                  <path d="M100 100 L180 80" stroke="white" strokeWidth="1" opacity="0.3" />
                  <path d="M100 100 L180 120" stroke="white" strokeWidth="1" opacity="0.3" />
                  <path d="M100 100 L170 100" stroke="white" strokeWidth="1" opacity="0.3" />
                  <circle cx="180" cy="80" r="2" fill="white" opacity="0.3" />
                  <circle cx="180" cy="120" r="2" fill="white" opacity="0.3" />
                  <circle cx="170" cy="100" r="2" fill="white" opacity="0.3" />
                </svg>
                
                {/* Rupee Symbol */}
                <svg viewBox="0 0 100 120" fill="none" className="w-32 h-32 relative z-10">
                  <path
                    d="M20 20 L80 20 M20 35 L75 35 M30 35 Q40 45 45 60 L45 100 L50 105 L60 95 L85 50 M45 60 Q50 75 65 85"
                    stroke="white"
                    strokeWidth="6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
            </div>

            {/* Info Text */}
            <div className="text-center space-y-3 relative z-10">
              <p className="text-sm leading-relaxed opacity-80 px-4">
                NPCI has launched Bharat Aadhaar Seeding Enabler (BASE) platform to facilitate
                Aadhaar Seeding and De-seeding activities in self-service mode for Direct benefit
                Transfer for enabling the citizens to verify our Million Activities in digital mode.
              </p>
            </div>
          </div>

          {/* Right Side - OTP Form */}
          <div className="p-12 flex flex-col justify-center">
            {/* OTP Verification Content */}
            <div className="flex-1 flex flex-col justify-center">
              <div className="text-center mb-8">
                <h1 className="text-gray-800 mb-2">OTP Verification</h1>
                <div className="flex justify-center mb-4">
                  <div className="w-16 h-1 bg-gradient-to-r from-blue-600 to-blue-400 rounded-full" />
                </div>
                <div className="text-gray-700 mb-2">
                  {isSuperAdmin ? "TOTP Verification" : "Google Auth Code Verification"}
                </div>
                <p className="text-sm text-gray-500 leading-relaxed px-4">
                  {isSuperAdmin 
                    ? "Kindly authenticate yourself by entering 6-digit TOTP code. (Get TOTP from CRM panel to authenticate your login.)"
                    : "Kindly authenticate yourself by entering 6-digit google authentication code. (Open Google Authenticator app to get 6-digit authentication code for the login.)"
                  }
                </p>
              </div>

              {/* OTP Input Fields */}
              <div className="flex justify-center gap-3 mb-8">
                {otp.map((digit, index) => (
                  <input
                    key={index}
                    ref={(el) => (inputRefs.current[index] = el)}
                    type="text"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleChange(index, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(index, e)}
                    onPaste={index === 0 ? handlePaste : undefined}
                    className="w-14 h-14 text-center border-2 border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                  />
                ))}
              </div>

              {/* Verify Button */}
              <button
                onClick={handleVerify}
                disabled={otp.some((digit) => !digit)}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white py-3 rounded-lg transition-all duration-300 shadow-lg disabled:shadow-none"
              >
                Verify
              </button>
            </div>

            {/* Footer */}
            <div className="mt-8 pt-6 border-t border-gray-200 text-center">
              <div className="text-sm text-gray-600 mb-1">
                <span className="text-blue-600">eNach</span> Version <span className="text-gray-800">25.11.18</span>
              </div>
              <div className="text-xs text-gray-500">
                Designed & Developed By <span className="text-gray-700">SOFT-TECH SOLUTIONS</span>
              </div>
              <div className="text-xs text-gray-500 mt-1">
                Copyright © 2014 - 2025 | All Right Reserved
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}