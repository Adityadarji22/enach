import { useState } from "react";
import { 
  Search,
  Lock,
  ChevronDown,
  Check
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface Branch {
  id: string;
  code: string;
  name: string;
  checked: boolean;
}

interface FormPermission {
  formName: string;
  isParent?: boolean;
  indent?: number;
  show: boolean;
  saveImport: boolean;
  updateExport: boolean;
  delete: boolean;
  cut: boolean;
  copy: boolean;
  paste: boolean;
  rightClick: boolean;
  autoAuth: boolean;
}

export function PermissionMaster() {
  const [activeTab, setActiveTab] = useState<"branch" | "form">("branch");
  
  // Branch Permission State
  const [selectedUser, setSelectedUser] = useState("");
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [branchSearchTerm, setBranchSearchTerm] = useState("");
  
  const users = [
    "Abhishek Parihar",
    "Aditya Daraji",
    "Akshay Patel",
    "Bhavna patel",
    "Bhoomi Patel",
    "Bindu Patel"
  ];

  const [branches, setBranches] = useState<Branch[]>([
    { id: "001", code: "001", name: "Main Branch", checked: true },
    { id: "010", code: "010", name: "Sirohi branch", checked: false },
    { id: "002", code: "002", name: "Jalor branch", checked: false },
    { id: "02", code: "02", name: "Ahmedabad Branch", checked: false },
    { id: "01", code: "01", name: "Palanpur Branch", checked: false }
  ]);

  // Form Permission State
  const [selectedRole, setSelectedRole] = useState("Maker");
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  
  const roles = ["Maker", "Checker", "Administrator", "Viewer"];

  const [formPermissions, setFormPermissions] = useState<FormPermission[]>([
    { formName: "Dashboard", isParent: true, show: true, saveImport: false, updateExport: false, delete: false, cut: false, copy: false, paste: false, rightClick: false, autoAuth: false },
    { formName: "Master", isParent: true, show: true, saveImport: false, updateExport: false, delete: false, cut: false, copy: false, paste: false, rightClick: false, autoAuth: false },
    { formName: "Bank", indent: 1, show: true, saveImport: false, updateExport: true, delete: false, cut: true, copy: true, paste: true, rightClick: true, autoAuth: false },
    { formName: "Branch", indent: 1, show: true, saveImport: true, updateExport: true, delete: true, cut: true, copy: true, paste: true, rightClick: true, autoAuth: false },
    { formName: "Bank IIN", indent: 1, show: true, saveImport: true, updateExport: true, delete: true, cut: true, copy: true, paste: true, rightClick: true, autoAuth: false },
    { formName: "User", indent: 1, show: true, saveImport: true, updateExport: true, delete: true, cut: true, copy: true, paste: true, rightClick: true, autoAuth: false },
    { formName: "User Role", indent: 1, show: true, saveImport: true, updateExport: true, delete: true, cut: true, copy: true, paste: true, rightClick: true, autoAuth: false },
    { formName: "User Permission", indent: 1, show: true, saveImport: false, updateExport: true, delete: false, cut: true, copy: true, paste: true, rightClick: true, autoAuth: false },
    { formName: "Miscellaneous", isParent: true, show: true, saveImport: false, updateExport: false, delete: false, cut: false, copy: false, paste: false, rightClick: false, autoAuth: false },
    { formName: "Account Status", indent: 1, show: true, saveImport: true, updateExport: true, delete: true, cut: true, copy: true, paste: true, rightClick: true, autoAuth: false },
    { formName: "Aadhaar Seeding", isParent: true, show: true, saveImport: false, updateExport: false, delete: false, cut: false, copy: false, paste: false, rightClick: false, autoAuth: false },
    { formName: "App Configurations", isParent: true, show: true, saveImport: false, updateExport: false, delete: false, cut: false, copy: false, paste: false, rightClick: false, autoAuth: false },
    { formName: "Utility", isParent: true, show: true, saveImport: false, updateExport: false, delete: false, cut: false, copy: false, paste: false, rightClick: false, autoAuth: false },
    { formName: "Report", isParent: true, show: true, saveImport: false, updateExport: false, delete: false, cut: false, copy: false, paste: false, rightClick: false, autoAuth: false }
  ]);

  const filteredBranches = branches.filter(branch =>
    branch.code.toLowerCase().includes(branchSearchTerm.toLowerCase()) ||
    branch.name.toLowerCase().includes(branchSearchTerm.toLowerCase())
  );

  const handleBranchToggle = (id: string) => {
    setBranches(branches.map(b =>
      b.id === id ? { ...b, checked: !b.checked } : b
    ));
  };

  const handleBranchPermissionUpdate = () => {
    if (!selectedUser) {
      toast.error("Please select a user");
      return;
    }
    const checkedCount = branches.filter(b => b.checked).length;
    toast.success(`Branch permissions updated for ${selectedUser} (${checkedCount} branches assigned)`);
  };

  const handleFormPermissionUpdate = () => {
    toast.success(`Form permissions updated for ${selectedRole} role`);
  };

  const togglePermission = (formName: string, field: keyof FormPermission) => {
    setFormPermissions(formPermissions.map(fp =>
      fp.formName === formName ? { ...fp, [field]: !fp[field] } : fp
    ));
  };

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-orange-600 to-red-600 rounded-lg flex items-center justify-center">
            <Lock className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2 text-xs text-gray-600 mb-1">
              <span>Master</span>
              <span>/</span>
              <span className="text-orange-600">User Permission</span>
            </div>
            <h2 className="text-gray-800">Permission Master</h2>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b border-gray-200 px-6">
        <div className="flex gap-1">
          <button
            onClick={() => setActiveTab("branch")}
            className={`px-6 py-3 text-sm rounded-t-lg transition-colors ${
              activeTab === "branch"
                ? "bg-orange-500 text-white"
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            Branch Permission
          </button>
          <button
            onClick={() => setActiveTab("form")}
            className={`px-6 py-3 text-sm rounded-t-lg transition-colors ${
              activeTab === "form"
                ? "bg-orange-500 text-white"
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            Form Permission
          </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-auto p-6">
        {activeTab === "branch" ? (
          /* Branch Permission Tab */
          <div className="bg-white rounded-lg border border-gray-200 p-6 max-w-4xl">
            {/* User Selection */}
            <div className="mb-6">
              <label className="block text-sm text-gray-700 mb-2">
                User<span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <button
                  onClick={() => setShowUserDropdown(!showUserDropdown)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg text-left flex items-center justify-between hover:border-gray-400 transition-colors"
                >
                  <span className={selectedUser ? "text-gray-800" : "text-gray-400"}>
                    {selectedUser || "Select User"}
                  </span>
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </button>
                {showUserDropdown && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-300 rounded-lg shadow-lg z-10 max-h-64 overflow-y-auto">
                    <div className="bg-orange-500 text-white px-4 py-2 text-sm sticky top-0">
                      Select User
                    </div>
                    {users.map((user) => (
                      <button
                        key={user}
                        onClick={() => {
                          setSelectedUser(user);
                          setShowUserDropdown(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-100 transition-colors"
                      >
                        {user}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {selectedUser && (
              <>
                {/* Search */}
                <div className="mb-4">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search ....."
                      value={branchSearchTerm}
                      onChange={(e) => setBranchSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
                    />
                  </div>
                </div>

                {/* Update Button */}
                <div className="mb-4 flex justify-end">
                  <button
                    onClick={handleBranchPermissionUpdate}
                    className="flex items-center gap-2 px-6 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors text-sm"
                  >
                    <Check className="w-4 h-4" />
                    <span>Update</span>
                  </button>
                </div>

                {/* Branch List */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredBranches.map((branch) => (
                    <label
                      key={branch.id}
                      className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                    >
                      <input
                        type="checkbox"
                        checked={branch.checked}
                        onChange={() => handleBranchToggle(branch.id)}
                        className="w-4 h-4 text-orange-500 border-gray-300 rounded focus:ring-orange-500 cursor-pointer"
                      />
                      <div className="text-sm">
                        <span className="text-gray-800">{branch.code}</span>
                        <span className="text-gray-600"> - {branch.name}</span>
                      </div>
                    </label>
                  ))}
                </div>
              </>
            )}
          </div>
        ) : (
          /* Form Permission Tab */
          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            {/* Role Selection */}
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex-1 max-w-xs">
                  <label className="block text-sm text-gray-700 mb-2">
                    Role<span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <button
                      onClick={() => setShowRoleDropdown(!showRoleDropdown)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg text-left flex items-center justify-between hover:border-gray-400 transition-colors"
                    >
                      <span className="text-gray-800">{selectedRole}</span>
                      <ChevronDown className="w-4 h-4 text-gray-400" />
                    </button>
                    {showRoleDropdown && (
                      <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-300 rounded-lg shadow-lg z-10">
                        {roles.map((role) => (
                          <button
                            key={role}
                            onClick={() => {
                              setSelectedRole(role);
                              setShowRoleDropdown(false);
                            }}
                            className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-100 transition-colors"
                          >
                            {role}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <button
                  onClick={handleFormPermissionUpdate}
                  className="flex items-center gap-2 px-6 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors text-sm"
                >
                  <Check className="w-4 h-4" />
                  <span>Update</span>
                </button>
              </div>
            </div>

            {/* Permissions Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-100 sticky top-0">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs text-gray-600 min-w-[200px]">Form Name</th>
                    <th className="px-4 py-3 text-center text-xs text-gray-600 w-20">Show</th>
                    <th className="px-4 py-3 text-center text-xs text-gray-600 w-28">Save/Import</th>
                    <th className="px-4 py-3 text-center text-xs text-gray-600 w-28">Update/Export</th>
                    <th className="px-4 py-3 text-center text-xs text-gray-600 w-20">Delete</th>
                    <th className="px-4 py-3 text-center text-xs text-gray-600 w-20">Cut</th>
                    <th className="px-4 py-3 text-center text-xs text-gray-600 w-20">Copy</th>
                    <th className="px-4 py-3 text-center text-xs text-gray-600 w-20">Paste</th>
                    <th className="px-4 py-3 text-center text-xs text-gray-600 w-24">Right Click</th>
                    <th className="px-4 py-3 text-center text-xs text-gray-600 w-24">Auto Auth.</th>
                  </tr>
                </thead>
                <tbody>
                  {formPermissions.map((form, index) => (
                    <tr
                      key={index}
                      className={`border-b border-gray-200 ${
                        form.isParent ? "bg-yellow-50" : "hover:bg-gray-50"
                      }`}
                    >
                      <td className="px-4 py-3 text-sm text-gray-800">
                        <span style={{ paddingLeft: `${(form.indent || 0) * 20}px` }}>
                          {form.formName}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <label className="inline-flex items-center justify-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={form.show}
                            onChange={() => togglePermission(form.formName, "show")}
                            className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500 cursor-pointer"
                          />
                        </label>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <label className="inline-flex items-center justify-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={form.saveImport}
                            onChange={() => togglePermission(form.formName, "saveImport")}
                            className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500 cursor-pointer"
                          />
                        </label>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <label className="inline-flex items-center justify-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={form.updateExport}
                            onChange={() => togglePermission(form.formName, "updateExport")}
                            className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500 cursor-pointer"
                          />
                        </label>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <label className="inline-flex items-center justify-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={form.delete}
                            onChange={() => togglePermission(form.formName, "delete")}
                            className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500 cursor-pointer"
                          />
                        </label>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <label className="inline-flex items-center justify-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={form.cut}
                            onChange={() => togglePermission(form.formName, "cut")}
                            className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500 cursor-pointer"
                          />
                        </label>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <label className="inline-flex items-center justify-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={form.copy}
                            onChange={() => togglePermission(form.formName, "copy")}
                            className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500 cursor-pointer"
                          />
                        </label>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <label className="inline-flex items-center justify-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={form.paste}
                            onChange={() => togglePermission(form.formName, "paste")}
                            className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500 cursor-pointer"
                          />
                        </label>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <label className="inline-flex items-center justify-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={form.rightClick}
                            onChange={() => togglePermission(form.formName, "rightClick")}
                            className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500 cursor-pointer"
                          />
                        </label>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <label className="inline-flex items-center justify-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={form.autoAuth}
                            onChange={() => togglePermission(form.formName, "autoAuth")}
                            className="w-5 h-5 text-orange-500 border-gray-300 rounded focus:ring-orange-500 cursor-pointer"
                          />
                        </label>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
