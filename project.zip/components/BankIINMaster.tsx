import { useState } from "react";
import { 
  Building2, 
  Search, 
  Plus, 
  Edit, 
  Trash2, 
  X,
  AlertTriangle
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface BankIIN {
  id: number;
  bankName: string;
  iin: string;
  ifsc: string;
  micr: string;
}

export function BankIINMaster() {
  const [bankIINs, setBankIINs] = useState<BankIIN[]>([
    {
      id: 1,
      bankName: "510 ARMY BASE W S CREDIT CO OP PRIMARY BANK LTD",
      iin: "990134",
      ifsc: "ICIC0ABWCC",
      micr: "250184021"
    },
    {
      id: 2,
      bankName: "AB BANK LIMITED",
      iin: "990312",
      ifsc: "HDFC0CABBLM",
      micr: "400240262"
    },
    {
      id: 3,
      bankName: "ABHINANDAN URBAN CO OP BANK AMRAVATI",
      iin: "608061",
      ifsc: "HDFC0CAMAN01",
      micr: "444085101"
    },
    {
      id: 4,
      bankName: "ABHYUDAYA CO OP BANK LTD",
      iin: "607261",
      ifsc: "ABHY0065001",
      micr: "400065001"
    },
    {
      id: 5,
      bankName: "ACE CO OP BANK LTD",
      iin: "607186",
      ifsc: "IBKL0100ACB",
      micr: "400876002"
    },
    {
      id: 6,
      bankName: "ADARNIYA P D PATILSAHEB SAHAKARI BANK LTD KARAD",
      iin: "607606",
      ifsc: "HDFC0CPDPBK",
      micr: "415032352"
    },
    {
      id: 7,
      bankName: "ADARSH CO OPERATIVE BANK LTD",
      iin: "508612",
      ifsc: "HDFC0CADARS",
      micr: "395575002"
    },
    {
      id: 8,
      bankName: "ADARSH MAHILA MERCANTILE CO OPERATIVE BANK LTD",
      iin: "990139",
      ifsc: "HDFC0CAMMCO",
      micr: "251805002"
    },
    {
      id: 9,
      bankName: "ADV SHAMRAOJI SHINDE SATYASHODHAK BANK LTD",
      iin: "990094",
      ifsc: "YESBSATYA0",
      micr: "416250263"
    },
    {
      id: 10,
      bankName: "AGARTALA CO OP URBAN BANK LTD",
      iin: "990336",
      ifsc: "UTBI0SACUB1",
      micr: "799087002"
    }
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [editingBankIIN, setEditingBankIIN] = useState<BankIIN | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  
  const [formData, setFormData] = useState({
    bankName: "",
    iin: "",
    ifsc: "",
    micr: ""
  });

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const handleAddBankIIN = () => {
    setEditingBankIIN(null);
    setFormData({
      bankName: "",
      iin: "",
      ifsc: "",
      micr: ""
    });
    setShowAddModal(true);
  };

  const handleEditBankIIN = (bankIIN: BankIIN) => {
    setEditingBankIIN(bankIIN);
    setFormData({
      bankName: bankIIN.bankName,
      iin: bankIIN.iin,
      ifsc: bankIIN.ifsc,
      micr: bankIIN.micr
    });
    setShowAddModal(true);
  };

  const handleSaveBankIIN = () => {
    // Validation
    if (!formData.bankName || !formData.iin) {
      toast.error("Please fill all required fields");
      return;
    }

    // IIN validation (should be numeric)
    if (!/^\d+$/.test(formData.iin)) {
      toast.error("IIN must contain only numbers");
      return;
    }

    if (editingBankIIN) {
      // Update existing bank IIN
      setBankIINs(bankIINs.map(b =>
        b.id === editingBankIIN.id
          ? {
              ...b,
              bankName: formData.bankName,
              iin: formData.iin,
              ifsc: formData.ifsc,
              micr: formData.micr
            }
          : b
      ));
      toast.success("Bank IIN updated successfully");
    } else {
      // Add new bank IIN
      const newBankIIN: BankIIN = {
        id: Math.max(...bankIINs.map(b => b.id), 0) + 1,
        bankName: formData.bankName,
        iin: formData.iin,
        ifsc: formData.ifsc,
        micr: formData.micr
      };
      setBankIINs([...bankIINs, newBankIIN]);
      toast.success("Bank IIN added successfully");
    }
    setShowAddModal(false);
  };

  const handleDeleteClick = (id: number) => {
    setDeleteId(id);
    setShowConfirmDialog(true);
  };

  const handleConfirmDelete = () => {
    if (deleteId) {
      setBankIINs(bankIINs.filter(b => b.id !== deleteId));
      toast.success("Bank IIN deleted successfully");
    }
    setShowConfirmDialog(false);
    setDeleteId(null);
  };

  const filteredBankIINs = bankIINs.filter(bankIIN =>
    bankIIN.bankName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bankIIN.iin.includes(searchTerm) ||
    bankIIN.ifsc.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bankIIN.micr.includes(searchTerm)
  );

  // Pagination calculations
  const totalPages = Math.ceil(filteredBankIINs.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentBankIINs = filteredBankIINs.slice(startIndex, endIndex);

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-gray-800">Bank IIN</h2>
              <p className="text-xs text-gray-600">Manage Bank IIN, IFSC and MICR codes</p>
            </div>
          </div>
          <button
            onClick={handleAddBankIIN}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-lg hover:from-orange-600 hover:to-orange-700 transition-all shadow-lg shadow-orange-200"
          >
            <Plus className="w-4 h-4" />
            <span className="text-sm">Add Bank IIN</span>
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center gap-4">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
            />
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto px-6 py-4">
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-left text-xs text-gray-600">Bank Name</th>
                <th className="px-4 py-3 text-left text-xs text-gray-600">IIN</th>
                <th className="px-4 py-3 text-left text-xs text-gray-600">IFSC</th>
                <th className="px-4 py-3 text-left text-xs text-gray-600">MICR</th>
                <th className="px-4 py-3 text-left text-xs text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {currentBankIINs.map((bankIIN) => (
                <tr key={bankIIN.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="text-sm text-gray-800">{bankIIN.bankName}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-sm text-gray-800">{bankIIN.iin}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-sm text-gray-800">{bankIIN.ifsc}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-sm text-gray-800">{bankIIN.micr}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleEditBankIIN(bankIIN)}
                        className="p-2 text-white bg-blue-600 hover:bg-blue-700 rounded transition-colors"
                        title="Edit"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteClick(bankIIN.id)}
                        className="p-2 text-white bg-red-600 hover:bg-red-700 rounded transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filteredBankIINs.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <Building2 className="w-12 h-12 mx-auto mb-3 text-gray-400" />
              <p>No bank IIN records found</p>
            </div>
          )}
        </div>
      </div>

      {/* Pagination */}
      <div className="bg-white border-t border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <select
              value={itemsPerPage}
              onChange={(e) => {
                setItemsPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="px-3 py-1.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm"
            >
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
            <span className="text-sm text-gray-600">
              Showing {startIndex + 1} to {Math.min(endIndex, filteredBankIINs.length)} of {filteredBankIINs.length} entries
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Previous
            </button>
            
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <button
                key={page}
                onClick={() => setCurrentPage(page)}
                className={`px-3 py-1.5 rounded-lg text-sm transition-colors ${
                  currentPage === page
                    ? "bg-blue-600 text-white"
                    : "border border-gray-300 text-gray-700 hover:bg-gray-50"
                }`}
              >
                {page}
              </button>
            ))}

            <button
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
              className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      {showConfirmDialog && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
            <div className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6 text-red-600" />
                </div>
                <div className="flex-1">
                  <h3 className="text-gray-800">Delete Bank IIN</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Are you sure you want to delete this bank IIN record? This action cannot be undone.
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 mt-6">
                <button
                  onClick={() => {
                    setShowConfirmDialog(false);
                    setDeleteId(null);
                  }}
                  className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmDelete}
                  className="px-6 py-2 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-lg hover:from-red-600 hover:to-red-700 transition-all shadow-lg shadow-red-200"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit Bank IIN Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
            <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h3 className="text-gray-800">
                {editingBankIIN ? "Edit IIN" : "Add IIN"}
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm text-gray-700 mb-2">
                  Bank Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.bankName}
                  onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter bank name"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    IIN <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.iin}
                    onChange={(e) => setFormData({ ...formData, iin: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="IIN"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">IFSC</label>
                  <input
                    type="text"
                    value={formData.ifsc}
                    onChange={(e) => setFormData({ ...formData, ifsc: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="IFSC"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">MICR</label>
                  <input
                    type="text"
                    value={formData.micr}
                    onChange={(e) => setFormData({ ...formData, micr: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="MICR"
                  />
                </div>
              </div>

              <button
                onClick={handleSaveBankIIN}
                className="w-full px-6 py-2 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all shadow-lg shadow-blue-200"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}