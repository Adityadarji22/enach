import { useState } from "react";
import { Info, Save } from "lucide-react";

export function AppParameters() {
  // Password Policy State
  const [passwordExpireDays, setPasswordExpireDays] = useState("30");
  const [passwordExpireReminderDays, setPasswordExpireReminderDays] = useState("5");

  // Login/Forgot Password Configuration State
  const [loginMaxAttempts, setLoginMaxAttempts] = useState("3");
  const [otpExpiryMinutes, setOtpExpiryMinutes] = useState("5");
  const [userLockTimeMinutes, setUserLockTimeMinutes] = useState("30");

  // Default Configuration State
  const [default2FAMethod, setDefault2FAMethod] = useState("Google Authenticator App");
  const [databaseBackupLocation, setDatabaseBackupLocation] = useState("E:\\My_Workspace\\BASEDB");
  const [additionalEmailsID, setAdditionalEmailsID] = useState("aditya@soft-techsolutions.com");
  const [licenseExpiryThreshold, setLicenseExpiryThreshold] = useState("15");
  const [sslCertificateExpiryThreshold, setSslCertificateExpiryThreshold] = useState("15");
  const [bankSignatureExpiryThreshold, setBankSignatureExpiryThreshold] = useState("15");

  const [activeSection, setActiveSection] = useState<string>("Password Policy");

  const handleUpdatePasswordPolicy = () => {
    console.log("Updating Password Policy:", {
      passwordExpireDays,
      passwordExpireReminderDays
    });
    // Add API call here
  };

  const handleUpdateLoginForgotConfig = () => {
    console.log("Updating Login/Forgot Password Configuration:", {
      loginMaxAttempts,
      otpExpiryMinutes,
      userLockTimeMinutes
    });
    // Add API call here
  };

  const handleUpdateDefaultConfig = () => {
    console.log("Updating Default Configuration:", {
      default2FAMethod,
      databaseBackupLocation,
      additionalEmailsID,
      licenseExpiryThreshold,
      sslCertificateExpiryThreshold,
      bankSignatureExpiryThreshold
    });
    // Add API call here
  };

  return (
    <div className="h-full flex">
      {/* Left Sidebar Menu */}
      <div className="w-48 bg-white border-r border-gray-200 overflow-y-auto">
        <div className="p-3 space-y-1">
          <button
            onClick={() => setActiveSection("Password Policy")}
            className={`w-full text-left px-3 py-2.5 text-xs rounded transition-colors ${
              activeSection === "Password Policy"
                ? "bg-blue-600 text-white"
                : "text-gray-700 hover:bg-gray-100"
            }`}
          >
            Password Policy
          </button>
          <button
            onClick={() => setActiveSection("Login/Forgot Password Configuration")}
            className={`w-full text-left px-3 py-2.5 text-xs rounded transition-colors ${
              activeSection === "Login/Forgot Password Configuration"
                ? "bg-blue-600 text-white"
                : "text-gray-700 hover:bg-gray-100"
            }`}
          >
            Login/Forgot Password Configuration
          </button>
          <button
            onClick={() => setActiveSection("Default Configuration")}
            className={`w-full text-left px-3 py-2.5 text-xs rounded transition-colors ${
              activeSection === "Default Configuration"
                ? "bg-blue-600 text-white"
                : "text-gray-700 hover:bg-gray-100"
            }`}
          >
            Default Configuration
          </button>
        </div>
      </div>

      {/* Right Content Area */}
      <div className="flex-1 bg-gray-50 overflow-y-auto">
        <div className="p-6 space-y-6">
          
          {/* Password Policy Section */}
          {activeSection === "Password Policy" && (
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-gray-800">Parameter</h2>
                <p className="text-blue-600 text-sm mt-1">Password Policy</p>
              </div>
              
              <div className="p-6">
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 text-sm mb-2">
                      Password Expire Days <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={passwordExpireDays}
                      onChange={(e) => setPasswordExpireDays(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                      placeholder="30"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-gray-700 text-sm mb-2">
                      Password Expire Reminder Showing Before Days <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={passwordExpireReminderDays}
                      onChange={(e) => setPasswordExpireReminderDays(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                      placeholder="5"
                    />
                  </div>
                </div>

                <div className="mt-6 flex justify-end">
                  <button
                    onClick={handleUpdatePasswordPolicy}
                    className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors flex items-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Update
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Login/Forgot Password Configuration Section */}
          {activeSection === "Login/Forgot Password Configuration" && (
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-gray-800">Parameter</h2>
                <p className="text-blue-600 text-sm mt-1">Login/Forgot Password Configuration</p>
              </div>
              
              <div className="p-6">
                <div className="grid grid-cols-3 gap-6">
                  <div>
                    <label className="block text-gray-700 text-sm mb-2">
                      Login/Forgot Password Max Attempts <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={loginMaxAttempts}
                      onChange={(e) => setLoginMaxAttempts(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm appearance-none bg-white"
                      style={{
                        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E")`,
                        backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'right 12px center'
                      }}
                    >
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                      <option value="6">6</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-gray-700 text-sm mb-2">
                      OTP Code Expiry Minutes <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={otpExpiryMinutes}
                      onChange={(e) => setOtpExpiryMinutes(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm appearance-none bg-white"
                      style={{
                        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E")`,
                        backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'right 12px center'
                      }}
                    >
                      <option value="3">3</option>
                      <option value="5">5</option>
                      <option value="10">10</option>
                      <option value="15">15</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-gray-700 text-sm mb-2 flex items-center gap-1">
                      User Lock Time in Minutes <span className="text-red-500">*</span>
                      <Info className="w-3.5 h-3.5 text-gray-400" />
                    </label>
                    <select
                      value={userLockTimeMinutes}
                      onChange={(e) => setUserLockTimeMinutes(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm appearance-none bg-white"
                      style={{
                        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E")`,
                        backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'right 12px center'
                      }}
                    >
                      <option value="15">15</option>
                      <option value="30">30</option>
                      <option value="45">45</option>
                      <option value="60">60</option>
                    </select>
                  </div>
                </div>

                <div className="mt-6 flex justify-end">
                  <button
                    onClick={handleUpdateLoginForgotConfig}
                    className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors flex items-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Update
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Default Configuration Section */}
          {activeSection === "Default Configuration" && (
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-gray-800">Parameter</h2>
                <p className="text-blue-600 text-sm mt-1">Default Configuration</p>
              </div>
              
              <div className="p-6 space-y-6">
                <div className="grid grid-cols-3 gap-6">
                  <div>
                    <label className="block text-gray-700 text-sm mb-2">
                      Default 2FA Method for New Users <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={default2FAMethod}
                      onChange={(e) => setDefault2FAMethod(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm appearance-none bg-white"
                      style={{
                        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E")`,
                        backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'right 12px center'
                      }}
                    >
                      <option value="Google Authenticator App">Google Authenticator App</option>
                      <option value="SMS OTP">SMS OTP</option>
                      <option value="Email OTP">Email OTP</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-gray-700 text-sm mb-2">
                      Database Backup Location <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={databaseBackupLocation}
                      onChange={(e) => setDatabaseBackupLocation(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 text-sm mb-2 flex items-center gap-1">
                      Additional Emails ID <span className="text-red-500">*</span>
                      <Info className="w-3.5 h-3.5 text-gray-400" />
                    </label>
                    <input
                      type="text"
                      value={additionalEmailsID}
                      onChange={(e) => setAdditionalEmailsID(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-6">
                  <div>
                    <label className="block text-gray-700 text-sm mb-2">
                      License Expiry Reminder Threshold (Days) <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={licenseExpiryThreshold}
                      onChange={(e) => setLicenseExpiryThreshold(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm appearance-none bg-white"
                      style={{
                        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E")`,
                        backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'right 12px center'
                      }}
                    >
                      <option value="7">7</option>
                      <option value="10">10</option>
                      <option value="15">15</option>
                      <option value="30">30</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-gray-700 text-sm mb-2">
                      SSL Certificate Expiry Reminder Threshold (Days) <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={sslCertificateExpiryThreshold}
                      onChange={(e) => setSslCertificateExpiryThreshold(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm appearance-none bg-white"
                      style={{
                        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E")`,
                        backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'right 12px center'
                      }}
                    >
                      <option value="7">7</option>
                      <option value="10">10</option>
                      <option value="15">15</option>
                      <option value="30">30</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-gray-700 text-sm mb-2">
                      Bank Signature/Encryption Certificate And PFX Expiry Reminder Threshold (Days) <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={bankSignatureExpiryThreshold}
                      onChange={(e) => setBankSignatureExpiryThreshold(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm appearance-none bg-white"
                      style={{
                        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E")`,
                        backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'right 12px center'
                      }}
                    >
                      <option value="7">7</option>
                      <option value="10">10</option>
                      <option value="15">15</option>
                      <option value="30">30</option>
                    </select>
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={handleUpdateDefaultConfig}
                    className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors flex items-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Update
                  </button>
                </div>
              </div>
            </div>
          )}



        </div>
      </div>
    </div>
  );
}
