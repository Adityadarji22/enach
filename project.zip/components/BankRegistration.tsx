import { useState } from "react";
import { Upload, X, Check, ChevronLeft, ChevronRight, Building2, ChevronDown, User } from "lucide-react";

interface BankRegistrationProps {
  onComplete: () => void;
}

type Step = 1 | 2 | 3 | 4 | 5;

export function BankRegistration({ onComplete }: BankRegistrationProps) {
  const [currentStep, setCurrentStep] = useState<Step>(1);
  const [loginLogo, setLoginLogo] = useState<string | null>(null);
  const [mainLogo, setMainLogo] = useState<string | null>(null);
  const [selectedModules, setSelectedModules] = useState<string[]>([]);
  const [selectedSubModules, setSelectedSubModules] = useState<string[]>([]);
  const [licenseStatus, setLicenseStatus] = useState<"idle" | "requested" | "validated">("idle");
  const [isProcessing, setIsProcessing] = useState(false);
  const [registrationCode] = useState<string>("REG-" + Math.random().toString(36).substring(2, 15).toUpperCase());
  const [manualLicenseKey, setManualLicenseKey] = useState<string>("");
  
  const [formData, setFormData] = useState({
    bankCode: "SVCX",
    bankName: "SOFT-TECH SOLUTIONS",
    iin: "000000",
    cbsBankCode: "",
    numberOfBranches: "",
    website: "https://soft-techsolutions.com",
    branchName: "Head Office",
    branchCode: "0001",
    branchIfsc: "SVCX0000001",
    address1: "205, 2nd Floor, Satyam Complex",
    address2: "Science City Road, Sola",
    country: "IN",
    state: "Gujarat",
    city: "Ahmedabad",
    pincode: "390060",
    adminUsername: "admin",
    adminPassword: "",
    adminConfirmPassword: "",
    adminMobile: "9727788331",
    adminEmail: "admin@soft-techsolutions.com",
    loginLogoWidth: "200",
    loginLogoHeight: "80",
    mainLogoWidth: "200",
    mainLogoHeight: "80",
  });

  const modules = [
    { 
      id: "base", 
      name: "BASE", 
      description: "Bharat Aadhaar Seeding Enabler",
      hasSubmodules: false 
    },
    { 
      id: "itr", 
      name: "ITR VALIDATION", 
      description: "Income Tax Return validation module",
      hasSubmodules: false 
    },
    { 
      id: "api-emandate", 
      name: "API EMandate Destination", 
      description: "Electronic mandate management through APIs",
      hasSubmodules: true 
    },
  ];

  const apiEmandateSubModules = [
    { id: "aadhar-mandate", name: "Aadhar Mandate" },
    { id: "debit-mandate", name: "Debit Mandate" },
    { id: "netbanking-mandate", name: "Netbanking Mandate" },
    { id: "pan-mandate", name: "Pan Mandate" },
    { id: "cust-id", name: "Cust Id" },
    { id: "aadhar-simplified", name: "Aadhar Simplified" },
    { id: "casr-destination", name: "CASR Destination" },
  ];

  const toggleModule = (moduleId: string) => {
    setSelectedModules(prev => {
      const newModules = prev.includes(moduleId) 
        ? prev.filter(id => id !== moduleId)
        : [...prev, moduleId];
      
      // If unchecking API EMandate, clear its sub-modules
      if (!newModules.includes("api-emandate")) {
        setSelectedSubModules([]);
      }
      
      return newModules;
    });
  };

  const toggleSubModule = (subModuleId: string) => {
    setSelectedSubModules(prev => 
      prev.includes(subModuleId) 
        ? prev.filter(id => id !== subModuleId)
        : [...prev, subModuleId]
    );
  };

  const handleFileUpload = (type: "login" | "main", event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (type === "login") {
          setLoginLogo(reader.result as string);
        } else {
          setMainLogo(reader.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const removeLogo = (type: "login" | "main") => {
    if (type === "login") {
      setLoginLogo(null);
      setFormData({ ...formData, loginLogoWidth: "200", loginLogoHeight: "80" });
    } else {
      setMainLogo(null);
      setFormData({ ...formData, mainLogoWidth: "200", mainLogoHeight: "80" });
    }
  };

  const handleNext = () => {
    if (currentStep < 5) {
      setCurrentStep((currentStep + 1) as Step);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep((currentStep - 1) as Step);
    }
  };

  const handleGetLicense = () => {
    setIsProcessing(true);
    // Simulate API call to request license
    setTimeout(() => {
      setLicenseStatus("requested");
      setIsProcessing(false);
    }, 2000);
  };

  const handleSubmitForValidation = () => {
    setIsProcessing(true);
    // Simulate online validation
    setTimeout(() => {
      setLicenseStatus("validated");
      setIsProcessing(false);
      // Redirect to login after successful validation
      setTimeout(() => {
        onComplete();
      }, 2000);
    }, 2000);
  };

  const handleValidateLicense = () => {
    if (!manualLicenseKey.trim()) {
      alert("Please enter a valid license key");
      return;
    }
    
    setIsProcessing(true);
    // Simulate manual validation
    setTimeout(() => {
      if (manualLicenseKey.length > 10) {
        setLicenseStatus("validated");
        setTimeout(() => {
          onComplete();
        }, 2000);
      } else {
        alert("Invalid license key");
      }
      setIsProcessing(false);
    }, 1500);
  };

  const steps = [
    { number: 1, title: "Logo Setup", description: "Upload your bank logos" },
    { number: 2, title: "Bank Details", description: "Basic bank information" },
    { number: 3, title: "Head Office", description: "Address & Admin" },
    { number: 4, title: "Modules", description: "Select required modules" },
    { number: 5, title: "License", description: "License activation" },
  ];

  return (
    <div className="h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex items-center justify-center p-3 overflow-hidden">
      {/* Exit Button */}
      <button
        onClick={onComplete}
        className="absolute top-3 right-3 px-3 py-1.5 text-xs text-gray-600 hover:text-gray-800 hover:bg-white/50 rounded-lg transition-colors"
      >
        Exit Setup
      </button>

      {/* Main Setup Container */}
      <div className="w-full max-w-5xl h-full flex flex-col py-2">
        {/* Header */}
        <div className="text-center mb-3">
          <div className="flex items-center justify-center gap-2 mb-1">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-gray-800 text-xl">Bank Registration Setup</h1>
              <p className="text-xs text-gray-600">Let's set up your bank profile to get started</p>
            </div>
          </div>
        </div>

        {/* Progress Steps */}
        <div className="mb-3">
          <div className="flex items-center justify-center gap-1">
            {steps.map((step, index) => (
              <div key={step.number} className="flex items-center">
                <div className="flex flex-col items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-all text-xs ${
                      currentStep === step.number
                        ? "bg-blue-600 text-white shadow-lg shadow-blue-300"
                        : currentStep > step.number
                        ? "bg-green-500 text-white"
                        : "bg-gray-200 text-gray-500"
                    }`}
                  >
                    {currentStep > step.number ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      <span>{step.number}</span>
                    )}
                  </div>
                  <div className="mt-1 text-center">
                    <div
                      className={`text-xs ${
                        currentStep === step.number ? "text-blue-600" : "text-gray-600"
                      }`}
                    >
                      {step.title}
                    </div>
                  </div>
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`w-8 h-0.5 mx-1 mb-6 transition-all ${
                      currentStep > step.number ? "bg-green-500" : "bg-gray-200"
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content Card - Scrollable Area */}
        <div className="bg-white rounded-xl shadow-xl border border-gray-100 p-4 flex-1 overflow-y-auto mb-3">
          {/* Step 1: Logo Setup */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div>
                <h2 className="text-gray-800 mb-1 text-lg">Upload Your Bank Logos</h2>
                <p className="text-xs text-gray-600">
                  Add your login and main logos to personalize your application
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                {/* Square Logo */}
                <div>
                  <label className="block text-xs text-gray-700 mb-2">
                    Square Logo <span className="text-red-500">*</span>
                  </label>
                  <div className="border-2 border-dashed border-blue-300 rounded-lg p-3 bg-gradient-to-br from-blue-50 to-white hover:border-blue-400 transition-colors relative overflow-hidden">
                    {!loginLogo ? (
                      <label className="cursor-pointer flex flex-col items-center justify-center h-32">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mb-2">
                          <Upload className="w-5 h-5 text-blue-600" />
                        </div>
                        <span className="text-xs text-gray-700 mb-1">Click to upload</span>
                        <span className="text-[10px] text-gray-500">PNG, JPG up to 5MB</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleFileUpload("login", e)}
                          className="hidden"
                        />
                      </label>
                    ) : (
                      <div className="relative flex items-center justify-center h-32 bg-gray-50 rounded overflow-hidden">
                        <img
                          src={loginLogo}
                          alt="Square Logo Preview"
                          className="pointer-events-none select-none"
                          style={{
                            width: `${Math.min(Number(formData.loginLogoWidth), 300)}px`,
                            height: `${Math.min(Number(formData.loginLogoHeight), 128)}px`,
                            objectFit: "contain",
                            maxWidth: "100%",
                            maxHeight: "100%"
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => removeLogo("login")}
                          className="absolute -top-2 -right-2 p-1 bg-red-500 hover:bg-red-600 text-white rounded-full transition-colors shadow-lg z-10"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Size Controls for Square Logo */}
                  {loginLogo && (
                    <div className="mt-2 p-2 bg-gray-50 rounded-lg space-y-2">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[10px] text-gray-700">Width</label>
                          <span className="text-[10px] text-blue-600">{formData.loginLogoWidth}px</span>
                        </div>
                        <input
                          type="range"
                          min="50"
                          max="300"
                          value={formData.loginLogoWidth}
                          onChange={(e) =>
                            setFormData({ ...formData, loginLogoWidth: e.target.value })
                          }
                          className="w-full h-1 bg-blue-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                        />
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[10px] text-gray-700">Height</label>
                          <span className="text-[10px] text-blue-600">{formData.loginLogoHeight}px</span>
                        </div>
                        <input
                          type="range"
                          min="30"
                          max="128"
                          value={formData.loginLogoHeight}
                          onChange={(e) =>
                            setFormData({ ...formData, loginLogoHeight: e.target.value })
                          }
                          className="w-full h-1 bg-blue-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                        />
                      </div>
                    </div>
                  )}

                  {/* Square Logo Preview */}
                  {loginLogo && (
                    <div className="mt-3 p-3 bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg border border-purple-200">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-5 h-5 bg-purple-500 rounded flex items-center justify-center">
                          <Check className="w-3 h-3 text-white" />
                        </div>
                        <div className="text-[10px] text-gray-700">Preview</div>
                      </div>
                      <div className="bg-white rounded-lg p-3 border border-gray-200">
                        <div className="w-32 h-32 mx-auto flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg overflow-hidden">
                          <img
                            src={loginLogo}
                            alt="Square Logo Preview"
                            className="pointer-events-none select-none"
                            style={{
                              width: `${Math.min(Number(formData.loginLogoWidth), 128)}px`,
                              height: `${Math.min(Number(formData.loginLogoHeight), 128)}px`,
                              objectFit: "contain"
                            }}
                          />
                        </div>
                        <div className="text-[10px] text-gray-500 mt-2 text-center">
                          {formData.loginLogoWidth}px × {formData.loginLogoHeight}px
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Rectangle Logo */}
                <div>
                  <label className="block text-xs text-gray-700 mb-2">
                    Rectangle Logo <span className="text-red-500">*</span>
                  </label>
                  <div className="border-2 border-dashed border-blue-300 rounded-lg p-3 bg-gradient-to-br from-blue-50 to-white hover:border-blue-400 transition-colors relative overflow-hidden">
                    {!mainLogo ? (
                      <label className="cursor-pointer flex flex-col items-center justify-center h-32">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mb-2">
                          <Upload className="w-5 h-5 text-blue-600" />
                        </div>
                        <span className="text-xs text-gray-700 mb-1">Click to upload</span>
                        <span className="text-[10px] text-gray-500">PNG, JPG up to 5MB</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleFileUpload("main", e)}
                          className="hidden"
                        />
                      </label>
                    ) : (
                      <div className="relative flex items-center justify-center h-32 bg-gray-50 rounded overflow-hidden">
                        <img
                          src={mainLogo}
                          alt="Rectangle Logo Preview"
                          className="pointer-events-none select-none"
                          style={{
                            width: `${Math.min(Number(formData.mainLogoWidth), 350)}px`,
                            height: `${Math.min(Number(formData.mainLogoHeight), 128)}px`,
                            objectFit: "contain",
                            maxWidth: "100%",
                            maxHeight: "100%"
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => removeLogo("main")}
                          className="absolute -top-2 -right-2 p-1 bg-red-500 hover:bg-red-600 text-white rounded-full transition-colors shadow-lg z-10"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Size Controls for Rectangle Logo */}
                  {mainLogo && (
                    <div className="mt-2 p-2 bg-gray-50 rounded-lg space-y-2">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[10px] text-gray-700">Width</label>
                          <span className="text-[10px] text-blue-600">{formData.mainLogoWidth}px</span>
                        </div>
                        <input
                          type="range"
                          min="50"
                          max="350"
                          value={formData.mainLogoWidth}
                          onChange={(e) =>
                            setFormData({ ...formData, mainLogoWidth: e.target.value })
                          }
                          className="w-full h-1 bg-blue-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                        />
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[10px] text-gray-700">Height</label>
                          <span className="text-[10px] text-blue-600">{formData.mainLogoHeight}px</span>
                        </div>
                        <input
                          type="range"
                          min="30"
                          max="128"
                          value={formData.mainLogoHeight}
                          onChange={(e) =>
                            setFormData({ ...formData, mainLogoHeight: e.target.value })
                          }
                          className="w-full h-1 bg-blue-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                        />
                      </div>
                    </div>
                  )}

                  {/* Rectangle Logo Preview */}
                  {mainLogo && (
                    <div className="mt-3 p-3 bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg border border-purple-200">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-5 h-5 bg-purple-500 rounded flex items-center justify-center">
                          <Check className="w-3 h-3 text-white" />
                        </div>
                        <div className="text-[10px] text-gray-700">Preview</div>
                      </div>
                      <div className="bg-white rounded-lg p-3 border border-gray-200">
                        <div className="h-32 flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg overflow-hidden">
                          <img
                            src={mainLogo}
                            alt="Rectangle Logo Preview"
                            className="pointer-events-none select-none"
                            style={{
                              width: `${Math.min(Number(formData.mainLogoWidth), 350)}px`,
                              height: `${Math.min(Number(formData.mainLogoHeight), 128)}px`,
                              objectFit: "contain"
                            }}
                          />
                        </div>
                        <div className="text-[10px] text-gray-500 mt-2 text-center">
                          {formData.mainLogoWidth}px × {formData.mainLogoHeight}px
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Bank Details */}
          {currentStep === 2 && (
            <div className="space-y-3">
              <div>
                <h2 className="text-gray-800 mb-1 text-lg">Bank Information</h2>
                <p className="text-xs text-gray-600">
                  Enter your bank's basic details and configuration
                </p>
              </div>

              <div className="grid gap-2">
                <div className="grid md:grid-cols-3 gap-3">
                  {/* Bank Code */}
                  <div>
                    <label className="block text-xs text-gray-700 mb-1">
                      Bank Code <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.bankCode}
                      onChange={(e) => setFormData({ ...formData, bankCode: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                      placeholder="Enter bank code"
                    />
                  </div>

                  {/* Bank Name */}
                  <div className="md:col-span-2">
                    <label className="block text-xs text-gray-700 mb-1">
                      Bank Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.bankName}
                      onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                      placeholder="Enter bank name"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-3">
                  {/* IIN */}
                  <div>
                    <label className="block text-xs text-gray-700 mb-1">
                      IIN <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.iin}
                      onChange={(e) => setFormData({ ...formData, iin: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                      placeholder="Enter IIN"
                    />
                  </div>

                  {/* CBS Bank Code */}
                  <div>
                    <label className="block text-xs text-gray-700 mb-1">
                      CBS Bank Code
                    </label>
                    <input
                      type="text"
                      value={formData.cbsBankCode}
                      onChange={(e) => setFormData({ ...formData, cbsBankCode: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                      placeholder="Enter CBS Bank Code"
                    />
                  </div>

                  {/* Number of Branches */}
                  <div>
                    <label className="block text-xs text-gray-700 mb-1">
                      Number of Branches <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      value={formData.numberOfBranches}
                      onChange={(e) => setFormData({ ...formData, numberOfBranches: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                      placeholder="Enter number"
                    />
                  </div>
                </div>

                {/* Website */}
                <div>
                  <label className="block text-xs text-gray-700 mb-1">
                    Website <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="url"
                    value={formData.website}
                    onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                    placeholder="https://example.com"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Head Office Address & Admin User */}
          {currentStep === 3 && (
            <div className="space-y-3">
              <div>
                <h2 className="text-gray-800 mb-1 text-lg">Head Office Address & Admin User</h2>
                <p className="text-xs text-gray-600">
                  Provide head office details and create admin user account
                </p>
              </div>

              {/* Branch Details Section */}
              <div className="p-3 bg-blue-50 rounded-lg">
                <h3 className="text-gray-800 mb-2 text-sm">Branch Details</h3>
                <div className="grid gap-2">
                  <div className="grid md:grid-cols-2 gap-3">
                    {/* Branch Name */}
                    <div>
                      <label className="block text-xs text-gray-700 mb-1">
                        Branch Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={formData.branchName}
                        onChange={(e) => setFormData({ ...formData, branchName: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                        placeholder="Enter branch name"
                      />
                    </div>

                    {/* Branch Code */}
                    <div>
                      <label className="block text-xs text-gray-700 mb-1">
                        Branch Code <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={formData.branchCode}
                        onChange={(e) => setFormData({ ...formData, branchCode: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                        placeholder="Enter branch code"
                      />
                    </div>
                  </div>

                  {/* Branch IFSC Code */}
                  <div>
                    <label className="block text-xs text-gray-700 mb-1">
                      Branch IFSC Code <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.branchIfsc}
                      onChange={(e) => setFormData({ ...formData, branchIfsc: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                      placeholder="Enter IFSC code"
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-3">
                    {/* Address 1 */}
                    <div>
                      <label className="block text-xs text-gray-700 mb-1">
                        Address Line 1 <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={formData.address1}
                        onChange={(e) => setFormData({ ...formData, address1: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                        placeholder="Enter address line 1"
                      />
                    </div>

                    {/* Address 2 */}
                    <div>
                      <label className="block text-xs text-gray-700 mb-1">
                        Address Line 2 <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={formData.address2}
                        onChange={(e) => setFormData({ ...formData, address2: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                        placeholder="Enter address line 2"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-4 gap-3">
                    {/* Country */}
                    <div>
                      <label className="block text-xs text-gray-700 mb-1">
                        Country <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={formData.country}
                        onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                        placeholder="Country"
                      />
                    </div>

                    {/* State */}
                    <div>
                      <label className="block text-xs text-gray-700 mb-1">
                        State <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={formData.state}
                        onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                        placeholder="State"
                      />
                    </div>

                    {/* City */}
                    <div>
                      <label className="block text-xs text-gray-700 mb-1">
                        City <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                        placeholder="City"
                      />
                    </div>

                    {/* Pincode */}
                    <div>
                      <label className="block text-xs text-gray-700 mb-1">
                        Pincode <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={formData.pincode}
                        onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 text-sm"
                        placeholder="Pincode"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Admin User Section */}
              <div className="p-3 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg border-2 border-green-200">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h3 className="text-gray-800 text-sm">Create Admin User</h3>
                    <p className="text-[10px] text-gray-600">Set up the administrator account for system access</p>
                  </div>
                </div>
                
                <div className="grid gap-2">
                  {/* Username */}
                  <div>
                    <label className="block text-xs text-gray-700 mb-1">
                      Username <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.adminUsername}
                      onChange={(e) => setFormData({ ...formData, adminUsername: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-100 bg-white text-sm"
                      placeholder="Choose a username"
                    />
                    <p className="text-[10px] text-gray-500 mt-0.5">This will be used to login to the system</p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-3">
                    {/* Password */}
                    <div>
                      <label className="block text-xs text-gray-700 mb-1">
                        Password <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="password"
                        value={formData.adminPassword}
                        onChange={(e) => setFormData({ ...formData, adminPassword: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-100 bg-white text-sm"
                        placeholder="Create a strong password"
                      />
                      <p className="text-[10px] text-gray-500 mt-0.5">Minimum 8 characters recommended</p>
                    </div>

                    {/* Confirm Password */}
                    <div>
                      <label className="block text-xs text-gray-700 mb-1">
                        Confirm Password <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="password"
                        value={formData.adminConfirmPassword}
                        onChange={(e) => setFormData({ ...formData, adminConfirmPassword: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-100 bg-white text-sm"
                        placeholder="Re-enter password"
                      />
                      {formData.adminPassword && formData.adminConfirmPassword && formData.adminPassword !== formData.adminConfirmPassword && (
                        <p className="text-[10px] text-red-500 mt-0.5 flex items-center gap-1">
                          <X className="w-3 h-3" />
                          Passwords do not match
                        </p>
                      )}
                      {formData.adminPassword && formData.adminConfirmPassword && formData.adminPassword === formData.adminConfirmPassword && (
                        <p className="text-[10px] text-green-600 mt-0.5 flex items-center gap-1">
                          <Check className="w-3 h-3" />
                          Passwords match
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-3">
                    {/* Mobile Number */}
                    <div>
                      <label className="block text-xs text-gray-700 mb-1">
                        Mobile Number <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="tel"
                        value={formData.adminMobile}
                        onChange={(e) => setFormData({ ...formData, adminMobile: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-100 bg-white text-sm"
                        placeholder="+91 XXXXX XXXXX"
                      />
                      <p className="text-[10px] text-gray-500 mt-0.5">For OTP and notifications</p>
                    </div>

                    {/* Admin Email */}
                    <div>
                      <label className="block text-xs text-gray-700 mb-1">
                        Email Address <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        value={formData.adminEmail}
                        onChange={(e) => setFormData({ ...formData, adminEmail: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-100 bg-white text-sm"
                        placeholder="admin@example.com"
                      />
                      <p className="text-[10px] text-gray-500 mt-0.5">For account recovery and updates</p>
                    </div>
                  </div>

                  {/* User creation info box */}
                  <div className="mt-2 p-2 bg-white rounded-lg border border-green-200">
                    <div className="flex items-start gap-2">
                      <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-green-600" />
                      </div>
                      <div className="text-[10px] text-gray-600">
                        <p className="mb-0.5">This admin user will have full access to:</p>
                        <ul className="list-disc list-inside space-y-0.5 text-gray-500">
                          <li>System configuration and settings</li>
                          <li>User management and permissions</li>
                          <li>All banking modules and features</li>
                          <li>Reports and analytics dashboard</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Module Selection */}
          {currentStep === 4 && (
            <div className="space-y-3">
              <div>
                <h2 className="text-gray-800 mb-1 text-lg">Select Required Modules</h2>
                <p className="text-xs text-gray-600">
                  Choose the modules that your bank will use in the application
                </p>
              </div>

              <div className="space-y-2">
                {modules.map(module => (
                  <div key={module.id}>
                    <div 
                      onClick={() => toggleModule(module.id)}
                      className={`border-2 rounded-lg p-3 cursor-pointer transition-all ${
                        selectedModules.includes(module.id)
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-300 bg-white hover:border-blue-300'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="flex items-center pt-0.5">
                          <input
                            type="checkbox"
                            checked={selectedModules.includes(module.id)}
                            onChange={() => toggleModule(module.id)}
                            className="w-4 h-4 border-2 border-gray-300 rounded text-blue-600 focus:ring-1 focus:ring-blue-100"
                          />
                        </div>
                        <div className="flex-1">
                          <h3 className={`mb-0.5 text-sm ${
                            selectedModules.includes(module.id) ? 'text-blue-800' : 'text-gray-800'
                          }`}>
                            {module.name}
                          </h3>
                          <p className="text-xs text-gray-600">{module.description}</p>
                        </div>
                        {module.hasSubmodules && selectedModules.includes(module.id) && (
                          <ChevronDown className="w-4 h-4 text-blue-600" />
                        )}
                      </div>
                    </div>

                    {/* Sub-modules for API EMandate */}
                    {module.id === "api-emandate" && selectedModules.includes(module.id) && (
                      <div className="ml-8 mt-2 space-y-1.5">
                        {apiEmandateSubModules.map(subModule => (
                          <div 
                            key={subModule.id}
                            onClick={() => toggleSubModule(subModule.id)}
                            className={`border rounded-lg p-2 cursor-pointer transition-all ${
                              selectedSubModules.includes(subModule.id)
                                ? 'border-blue-400 bg-blue-50'
                                : 'border-gray-200 bg-white hover:border-blue-200'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <input
                                type="checkbox"
                                checked={selectedSubModules.includes(subModule.id)}
                                onChange={() => toggleSubModule(subModule.id)}
                                className="w-3.5 h-3.5 border-2 border-gray-300 rounded text-blue-600 focus:ring-1 focus:ring-blue-100"
                              />
                              <span className={`text-xs ${
                                selectedSubModules.includes(subModule.id) ? 'text-blue-700' : 'text-gray-700'
                              }`}>
                                {subModule.name}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Selected Modules Summary */}
              {selectedModules.length > 0 && (
                <div className="mt-3 p-3 bg-gradient-to-br from-blue-50 to-white rounded-lg border border-blue-200">
                  <div className="flex items-start gap-2">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h3 className="text-gray-800 mb-0.5 text-sm">
                        {selectedModules.length} Module{selectedModules.length > 1 ? 's' : ''} Selected
                      </h3>
                      <p className="text-xs text-gray-600 mb-1">
                        {modules
                          .filter(m => selectedModules.includes(m.id))
                          .map(m => m.name)
                          .join(', ')}
                      </p>
                      {selectedSubModules.length > 0 && (
                        <p className="text-[10px] text-gray-500">
                          API EMandate Sub-modules: {apiEmandateSubModules
                            .filter(sm => selectedSubModules.includes(sm.id))
                            .map(sm => sm.name)
                            .join(', ')}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Step 5: License Activation */}
          {currentStep === 5 && (
            <div className="space-y-3">
              <div>
                <h2 className="text-gray-800 mb-1 text-lg">License Activation</h2>
                <p className="text-xs text-gray-600">
                  Activate your eNACH license to complete the setup
                </p>
              </div>

              {/* Registration Request Code */}
              <div>
                <label className="block text-xs text-gray-700 mb-1">
                  Registration Request Code <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={registrationCode}
                    readOnly
                    className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg bg-gray-50 text-gray-700 text-sm"
                  />
                </div>
                <p className="text-[10px] text-gray-500 mt-1">
                  Use this Registration Request Code to generate license from CRM panel
                </p>
              </div>

              {/* Automatic License Section */}
              <div className="p-3 bg-blue-50 rounded-lg space-y-2">
                <h3 className="text-gray-800 text-sm">Automatic License Retrieval</h3>
                
                {licenseStatus === "idle" && (
                  <button
                    onClick={handleGetLicense}
                    disabled={isProcessing}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm disabled:opacity-50"
                  >
                    {isProcessing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Processing...</span>
                      </>
                    ) : (
                      <>
                        <Check className="w-4 h-4" />
                        <span>Get License</span>
                      </>
                    )}
                  </button>
                )}

                {licenseStatus === "requested" && (
                  <div className="space-y-2">
                    <div className="p-2 bg-green-100 border border-green-300 rounded-lg">
                      <p className="text-xs text-green-800">
                        License request sent successfully! Click below to validate.
                      </p>
                    </div>
                    <button
                      onClick={handleSubmitForValidation}
                      disabled={isProcessing}
                      className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors text-sm disabled:opacity-50"
                    >
                      {isProcessing ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          <span>Validating...</span>
                        </>
                      ) : (
                        <>
                          <Check className="w-4 h-4" />
                          <span>Submit for Online Validation</span>
                        </>
                      )}
                    </button>
                  </div>
                )}

                {licenseStatus === "validated" && (
                  <div className="p-2 bg-green-100 border border-green-300 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-green-600" />
                      <p className="text-xs text-green-800">
                        License validated successfully! Redirecting to login...
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Divider */}
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="px-3 bg-white text-gray-500">OR</span>
                </div>
              </div>

              {/* Manual License Section */}
              <div className="p-3 bg-orange-50 rounded-lg space-y-2">
                <h3 className="text-gray-800 text-sm">Manual License Validation</h3>
                <div>
                  <label className="block text-xs text-gray-700 mb-1">
                    Enter License Key <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    value={manualLicenseKey}
                    onChange={(e) => setManualLicenseKey(e.target.value)}
                    placeholder="Paste your license key here from CRM panel..."
                    rows={3}
                    disabled={licenseStatus === "validated"}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-100 resize-none text-xs"
                  />
                </div>
                <button
                  onClick={handleValidateLicense}
                  disabled={isProcessing || licenseStatus === "validated" || !manualLicenseKey.trim()}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg transition-colors text-sm disabled:opacity-50"
                >
                  {isProcessing ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Validating...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Validate License</span>
                    </>
                  )}
                </button>
              </div>

              {/* Instructions */}
              <div className="p-3 bg-gray-50 rounded-lg">
                <h3 className="text-xs text-gray-800 mb-2">Instructions:</h3>
                <ol className="text-[10px] text-gray-600 space-y-1 list-decimal list-inside">
                  <li>Copy the Registration Request Code displayed above</li>
                  <li>For automatic license, click "Get License" to raise a request</li>
                  <li>Once approved from CRM panel, click "Submit for Online Validation"</li>
                  <li>Alternatively, access your CRM panel at <span className="text-blue-600">https://crm.soft-techsolutions.com</span></li>
                  <li>Generate a license key using the Registration Request Code</li>
                  <li>Paste the generated license key in the manual validation field</li>
                  <li>Click "Validate License" to complete activation</li>
                </ol>
              </div>
            </div>
          )}
        </div>

        {/* Navigation Buttons - Fixed at Bottom */}
        <div className="bg-white rounded-xl shadow-xl border border-gray-100 p-3">
          <div className="flex items-center justify-between">
            <button
              onClick={handlePrevious}
              disabled={currentStep === 1}
              className="flex items-center gap-1 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-transparent text-sm"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <div className="text-xs text-gray-500">
              Step {currentStep} of {steps.length}
            </div>

            {currentStep < 5 ? (
              <button
                onClick={handleNext}
                className="flex items-center gap-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm"
              >
                <span>Next</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <div className="w-24"></div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-1 text-[10px] text-gray-500">
          <p>eNach Version 25.11.18 • Designed & Developed By SOFT-TECH SOLUTIONS</p>
        </div>
      </div>
    </div>
  );
}