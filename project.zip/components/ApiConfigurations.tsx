import { useState } from "react";
import {
  Plus,
  Edit,
  Play,
  X,
  Trash2,
  ChevronDown,
  ChevronRight,
  Code,
  Key,
  Settings,
  Globe,
  ArrowRight,
  CheckCircle,
  AlertCircle,
  Copy,
  ChevronUp,
} from "lucide-react";

interface ApiStep {
  id: string;
  stepNumber: number;
  apiUrl: string;
  requestMethod: string;
  requestContentType: string;
  responseContentType: string;
  authType: string;
  apiKeyConfig: {
    type: "basic" | "bearer" | "none";
    username?: string;
    password?: string;
    bearerToken?: string;
  };
  additionalHeaders: {
    mode: "json" | "keyValue";
    jsonValue: string;
    keyValuePairs: Array<{ key: string; value: string; valueType: string }>;
  };
  requestPayload: {
    mode: "json" | "keyValue" | "default";
    jsonValue: string;
    keyValuePairs: Array<{ key: string; value: string; valueType: string }>;
    defaultPayloadId?: string;
  };
  responseMapping: {
    mode: "json" | "keyValue" | "default";
    jsonValue: string;
    keyValuePairs: Array<{ key: string; value: string; valueType: string }>;
    defaultPayloadId?: string;
  };
}

interface ApiService {
  id: string;
  name: string;
  description: string;
  steps: ApiStep[];
  createdAt: string;
}

const REQUEST_METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"];
const CONTENT_TYPES = [
  "application/json",
  "application/xml",
  "application/x-www-form-urlencoded",
  "multipart/form-data",
  "text/plain",
  "text/html",
  "text/xml",
];
const AUTH_TYPES = ["None", "Basic", "Bearer"];
const VALUE_TYPES = ["String", "Number", "Boolean", "Object", "Array", "Variable"];

const DEFAULT_PAYLOADS = [
  { id: "mandate-request", name: "Mandate Request", payload: { mandateType: "CREATE", customerName: "", accountNumber: "" } },
  { id: "payment-request", name: "Payment Request", payload: { amount: 0, currency: "INR", reference: "" } },
  { id: "customer-info", name: "Customer Info", payload: { customerId: "", name: "", email: "" } },
];

function VariablePickerSidebar({ 
  steps, 
  currentStepIndex,
  onSelectVariable 
}: { 
  steps: ApiStep[];
  currentStepIndex: number;
  onSelectVariable: (variable: string) => void;
}) {
  const [expandedStep, setExpandedStep] = useState<string | null>("app");
  const [copiedVariable, setCopiedVariable] = useState<string | null>(null);

  const handleVariableClick = (variable: string) => {
    onSelectVariable(variable);
    setCopiedVariable(variable);
    setTimeout(() => setCopiedVariable(null), 2000);
  };

  const previousSteps = steps.slice(0, currentStepIndex);

  return (
    <div className="w-80 bg-gray-50 border-l border-gray-200 flex flex-col">
      <div className="p-4 bg-gradient-to-r from-purple-600 to-purple-700 text-white">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold flex items-center gap-2">
            <Key className="w-5 h-5" />
            Available Variables
          </h3>
          <div className="px-2 py-0.5 bg-white/30 rounded-full text-xs font-medium">
            Step {currentStepIndex + 1}
          </div>
        </div>
        <p className="text-xs text-purple-100 mt-1">Click to copy to clipboard</p>
        {currentStepIndex > 0 && (
          <div className="mt-2 px-2 py-1 bg-white/20 rounded text-xs flex items-center gap-1">
            <CheckCircle className="w-3 h-3" />
            <span>{previousSteps.length} previous step{previousSteps.length > 1 ? 's' : ''} available</span>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-auto p-4 space-y-2">
        {/* Application Level Variables */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <button
            onClick={() => setExpandedStep(expandedStep === "app" ? null : "app")}
            className="w-full px-3 py-2 flex items-center justify-between hover:bg-gray-50 transition-colors"
          >
            <span className="text-sm font-medium text-gray-700">App Level Variables</span>
            {expandedStep === "app" ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
          </button>
          {expandedStep === "app" && (
            <div className="px-3 pb-3 space-y-1">
              {["userId", "bankCode", "branchId", "timestamp"].map((variable) => {
                const fullVariable = `{{app.${variable}}}`;
                return (
                  <button
                    key={variable}
                    onClick={() => handleVariableClick(fullVariable)}
                    className="w-full text-left px-3 py-2 text-xs bg-blue-50 text-blue-700 rounded hover:bg-blue-100 transition-colors flex items-center justify-between group"
                  >
                    <span className="font-mono">{fullVariable}</span>
                    {copiedVariable === fullVariable ? (
                      <CheckCircle className="w-3 h-3 text-green-600" />
                    ) : (
                      <Copy className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Previous Steps - Only show if there are previous steps */}
        {previousSteps.length > 0 ? (
          previousSteps.map((step) => (
            <div key={step.id} className="bg-white rounded-lg border border-purple-200 shadow-sm">
              <button
                onClick={() => setExpandedStep(expandedStep === step.id ? null : step.id)}
                className="w-full px-3 py-2 flex items-center justify-between hover:bg-purple-50 transition-colors"
              >
                <span className="text-sm font-medium text-gray-700">
                  Step {step.stepNumber} Response
                </span>
                {expandedStep === step.id ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
              </button>
              {expandedStep === step.id && (
                <div className="px-3 pb-3 space-y-1">
                  {["token", "status", "data", "message", "id", "response"].map((variable) => {
                    const fullVariable = `{{step${step.stepNumber}.${variable}}}`;
                    return (
                      <button
                        key={variable}
                        onClick={() => handleVariableClick(fullVariable)}
                        className="w-full text-left px-3 py-2 text-xs bg-purple-50 text-purple-700 rounded hover:bg-purple-100 transition-colors flex items-center justify-between group"
                      >
                        <span className="font-mono">{fullVariable}</span>
                        {copiedVariable === fullVariable ? (
                          <CheckCircle className="w-3 h-3 text-green-600" />
                        ) : (
                          <Copy className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          ))
        ) : (
          <div className="bg-white rounded-lg border border-gray-200 p-4 text-center">
            <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <AlertCircle className="w-6 h-6 text-gray-400" />
            </div>
            <p className="text-xs text-gray-500">
              No previous steps available
            </p>
            <p className="text-xs text-gray-400 mt-1">
              Variables from previous steps will appear here
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function ApiStepForm({ 
  step, 
  stepIndex,
  totalSteps,
  allSteps,
  onUpdate, 
  onDelete 
}: { 
  step: ApiStep;
  stepIndex: number;
  totalSteps: number;
  allSteps: ApiStep[];
  onUpdate: (updated: ApiStep) => void;
  onDelete: () => void;
}) {
  const [expandedSections, setExpandedSections] = useState({
    auth: true,
    headers: false,
    request: true,
    response: false,
  });

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const handleVariableSelect = (variable: string) => {
    // Copy to clipboard when variable is clicked
    navigator.clipboard.writeText(variable).then(() => {
      console.log("Copied variable:", variable);
    });
  };

  return (
    <div className="flex gap-4">
      <div className="flex-1 space-y-4">
        {/* Step Header */}
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-4 rounded-lg flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
              <span className="font-bold">{step.stepNumber}</span>
            </div>
            <div>
              <h3 className="font-semibold">Step {step.stepNumber}</h3>
              <p className="text-xs text-blue-100">
                {stepIndex === 0 
                  ? "First step - Use app-level variables" 
                  : `Can use variables from Step ${stepIndex === 1 ? '1' : `1-${stepIndex}`}`
                }
              </p>
            </div>
          </div>
          {totalSteps > 1 && (
            <button
              onClick={onDelete}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Basic Configuration */}
        <div className="bg-white rounded-lg border border-gray-200 p-4 space-y-4">
          <h4 className="font-medium text-gray-900 flex items-center gap-2">
            <Globe className="w-4 h-4" />
            Basic Configuration
          </h4>

          {/* API URL */}
          <div>
            <label className="block text-sm text-gray-700 mb-2">
              API URL <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={step.apiUrl}
              onChange={(e) => onUpdate({ ...step, apiUrl: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              placeholder="https://api.example.com/endpoint"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Request Method */}
            <div>
              <label className="block text-sm text-gray-700 mb-2">
                Request Method <span className="text-red-500">*</span>
              </label>
              <select
                value={step.requestMethod}
                onChange={(e) => onUpdate({ ...step, requestMethod: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              >
                {REQUEST_METHODS.map((method) => (
                  <option key={method} value={method}>{method}</option>
                ))}
              </select>
            </div>

            {/* Request Content-Type */}
            <div>
              <label className="block text-sm text-gray-700 mb-2">
                Request Content-Type
              </label>
              <select
                value={step.requestContentType}
                onChange={(e) => onUpdate({ ...step, requestContentType: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              >
                {CONTENT_TYPES.map((type) => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Response Content-Type */}
            <div>
              <label className="block text-sm text-gray-700 mb-2">
                Response Content-Type
              </label>
              <select
                value={step.responseContentType}
                onChange={(e) => onUpdate({ ...step, responseContentType: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              >
                {CONTENT_TYPES.map((type) => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            {/* Auth Type */}
            <div>
              <label className="block text-sm text-gray-700 mb-2">
                Auth Type
              </label>
              <select
                value={step.authType}
                onChange={(e) => onUpdate({ ...step, authType: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              >
                {AUTH_TYPES.map((type) => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Authentication Section */}
        <div className="bg-white rounded-lg border border-gray-200">
          <button
            onClick={() => toggleSection("auth")}
            className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50"
          >
            <span className="font-medium text-gray-900 flex items-center gap-2">
              <Key className="w-4 h-4" />
              Authentication Configuration
            </span>
            {expandedSections.auth ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </button>

          {expandedSections.auth && (
            <div className="px-4 pb-4 space-y-3">
              {step.authType === "Basic" && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">Username</label>
                    <input
                      type="text"
                      value={step.apiKeyConfig.username || ""}
                      onChange={(e) => onUpdate({
                        ...step,
                        apiKeyConfig: { ...step.apiKeyConfig, username: e.target.value }
                      })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Enter username"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">Password</label>
                    <input
                      type="password"
                      value={step.apiKeyConfig.password || ""}
                      onChange={(e) => onUpdate({
                        ...step,
                        apiKeyConfig: { ...step.apiKeyConfig, password: e.target.value }
                      })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Enter password"
                    />
                  </div>
                </div>
              )}

              {step.authType === "Bearer" && (
                <div>
                  <label className="block text-sm text-gray-700 mb-2">Bearer Token</label>
                  <input
                    type="text"
                    value={step.apiKeyConfig.bearerToken || ""}
                    onChange={(e) => onUpdate({
                      ...step,
                      apiKeyConfig: { ...step.apiKeyConfig, bearerToken: e.target.value }
                    })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder={stepIndex === 0 ? "Enter token or use {{app.userId}}" : `Enter token or use {{step${stepIndex}.token}}`}
                  />
                  <div className="flex items-center gap-1 mt-1">
                    <Key className="w-3 h-3 text-purple-600" />
                    <p className="text-xs text-purple-600">
                      Copy variables from the right sidebar and paste here
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Additional Headers Section */}
        <div className="bg-white rounded-lg border border-gray-200">
          <button
            onClick={() => toggleSection("headers")}
            className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50"
          >
            <span className="font-medium text-gray-900 flex items-center gap-2">
              <Settings className="w-4 h-4" />
              Additional Headers (Optional)
            </span>
            {expandedSections.headers ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </button>

          {expandedSections.headers && (
            <div className="px-4 pb-4 space-y-3">
              <div className="flex gap-2">
                <button
                  onClick={() => onUpdate({
                    ...step,
                    additionalHeaders: { ...step.additionalHeaders, mode: "json" }
                  })}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    step.additionalHeaders.mode === "json"
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  JSON
                </button>
                <button
                  onClick={() => onUpdate({
                    ...step,
                    additionalHeaders: { ...step.additionalHeaders, mode: "keyValue" }
                  })}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    step.additionalHeaders.mode === "keyValue"
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  Key-Value
                </button>
              </div>

              {step.additionalHeaders.mode === "json" ? (
                <textarea
                  value={step.additionalHeaders.jsonValue}
                  onChange={(e) => onUpdate({
                    ...step,
                    additionalHeaders: { ...step.additionalHeaders, jsonValue: e.target.value }
                  })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm"
                  rows={4}
                  placeholder='{\n  "X-Custom-Header": "value"\n}'
                />
              ) : (
                <div className="space-y-2">
                  {step.additionalHeaders.keyValuePairs.map((pair, index) => (
                    <div key={index} className="flex gap-2">
                      <input
                        type="text"
                        value={pair.key}
                        onChange={(e) => {
                          const updated = [...step.additionalHeaders.keyValuePairs];
                          updated[index].key = e.target.value;
                          onUpdate({
                            ...step,
                            additionalHeaders: { ...step.additionalHeaders, keyValuePairs: updated }
                          });
                        }}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Header name"
                      />
                      <input
                        type="text"
                        value={pair.value}
                        onChange={(e) => {
                          const updated = [...step.additionalHeaders.keyValuePairs];
                          updated[index].value = e.target.value;
                          onUpdate({
                            ...step,
                            additionalHeaders: { ...step.additionalHeaders, keyValuePairs: updated }
                          });
                        }}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Value"
                      />
                      <button
                        onClick={() => {
                          const updated = step.additionalHeaders.keyValuePairs.filter((_, i) => i !== index);
                          onUpdate({
                            ...step,
                            additionalHeaders: { ...step.additionalHeaders, keyValuePairs: updated }
                          });
                        }}
                        className="px-3 py-2 text-red-600 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  <button
                    onClick={() => {
                      const updated = [...step.additionalHeaders.keyValuePairs, { key: "", value: "", valueType: "String" }];
                      onUpdate({
                        ...step,
                        additionalHeaders: { ...step.additionalHeaders, keyValuePairs: updated }
                      });
                    }}
                    className="w-full px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-blue-400 hover:text-blue-600 transition-colors"
                  >
                    + Add Header
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Request Payload Section */}
        <div className="bg-white rounded-lg border border-gray-200">
          <button
            onClick={() => toggleSection("request")}
            className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50"
          >
            <span className="font-medium text-gray-900 flex items-center gap-2">
              <Code className="w-4 h-4" />
              Request Payload
            </span>
            {expandedSections.request ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </button>

          {expandedSections.request && (
            <div className="px-4 pb-4 space-y-3">
              <div className="flex gap-2">
                <button
                  onClick={() => onUpdate({
                    ...step,
                    requestPayload: { ...step.requestPayload, mode: "json" }
                  })}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    step.requestPayload.mode === "json"
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  JSON
                </button>
                <button
                  onClick={() => onUpdate({
                    ...step,
                    requestPayload: { ...step.requestPayload, mode: "keyValue" }
                  })}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    step.requestPayload.mode === "keyValue"
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  Key-Value
                </button>
                <button
                  onClick={() => onUpdate({
                    ...step,
                    requestPayload: { ...step.requestPayload, mode: "default" }
                  })}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    step.requestPayload.mode === "default"
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  Default
                </button>
              </div>

              {step.requestPayload.mode === "json" && (
                <div>
                  <textarea
                    value={step.requestPayload.jsonValue}
                    onChange={(e) => onUpdate({
                      ...step,
                      requestPayload: { ...step.requestPayload, jsonValue: e.target.value }
                    })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm"
                    rows={6}
                    placeholder={stepIndex === 0 
                      ? '{\n  "key": "value",\n  "userId": "{{app.userId}}"\n}'
                      : `{\n  "key": "value",\n  "token": "{{step${stepIndex}.token}}"\n}`
                    }
                  />
                  <div className="flex items-center gap-1 mt-1">
                    <Key className="w-3 h-3 text-purple-600" />
                    <p className="text-xs text-purple-600">
                      Use variables like {`{{step${stepIndex > 0 ? stepIndex : '1'}.token}}`} or {`{{app.userId}}`}
                    </p>
                  </div>
                </div>
              )}

              {step.requestPayload.mode === "keyValue" && (
                <div className="space-y-2">
                  {step.requestPayload.keyValuePairs.map((pair, index) => (
                    <div key={index} className="flex gap-2">
                      <input
                        type="text"
                        value={pair.key}
                        onChange={(e) => {
                          const updated = [...step.requestPayload.keyValuePairs];
                          updated[index].key = e.target.value;
                          onUpdate({
                            ...step,
                            requestPayload: { ...step.requestPayload, keyValuePairs: updated }
                          });
                        }}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Key"
                      />
                      <input
                        type="text"
                        value={pair.value}
                        onChange={(e) => {
                          const updated = [...step.requestPayload.keyValuePairs];
                          updated[index].value = e.target.value;
                          onUpdate({
                            ...step,
                            requestPayload: { ...step.requestPayload, keyValuePairs: updated }
                          });
                        }}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Value or {{variable}}"
                      />
                      <select
                        value={pair.valueType}
                        onChange={(e) => {
                          const updated = [...step.requestPayload.keyValuePairs];
                          updated[index].valueType = e.target.value;
                          onUpdate({
                            ...step,
                            requestPayload: { ...step.requestPayload, keyValuePairs: updated }
                          });
                        }}
                        className="px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        {VALUE_TYPES.map(type => (
                          <option key={type} value={type}>{type}</option>
                        ))}
                      </select>
                      <button
                        onClick={() => {
                          const updated = step.requestPayload.keyValuePairs.filter((_, i) => i !== index);
                          onUpdate({
                            ...step,
                            requestPayload: { ...step.requestPayload, keyValuePairs: updated }
                          });
                        }}
                        className="px-3 py-2 text-red-600 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  <button
                    onClick={() => {
                      const updated = [...step.requestPayload.keyValuePairs, { key: "", value: "", valueType: "String" }];
                      onUpdate({
                        ...step,
                        requestPayload: { ...step.requestPayload, keyValuePairs: updated }
                      });
                    }}
                    className="w-full px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-blue-400 hover:text-blue-600 transition-colors"
                  >
                    + Add Field
                  </button>
                </div>
              )}

              {step.requestPayload.mode === "default" && (
                <div className="space-y-2">
                  <label className="block text-sm text-gray-700">Select Default Payload</label>
                  <select
                    value={step.requestPayload.defaultPayloadId || ""}
                    onChange={(e) => onUpdate({
                      ...step,
                      requestPayload: { ...step.requestPayload, defaultPayloadId: e.target.value }
                    })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    <option value="">-- Select Payload --</option>
                    {DEFAULT_PAYLOADS.map(payload => (
                      <option key={payload.id} value={payload.id}>{payload.name}</option>
                    ))}
                  </select>
                  {step.requestPayload.defaultPayloadId && (
                    <div className="bg-gray-50 p-3 rounded border border-gray-200">
                      <pre className="text-xs text-gray-700">
                        {JSON.stringify(
                          DEFAULT_PAYLOADS.find(p => p.id === step.requestPayload.defaultPayloadId)?.payload,
                          null,
                          2
                        )}
                      </pre>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Response Mapping Section */}
        <div className="bg-white rounded-lg border border-gray-200">
          <button
            onClick={() => toggleSection("response")}
            className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50"
          >
            <span className="font-medium text-gray-900 flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              Response Mapping
            </span>
            {expandedSections.response ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </button>

          {expandedSections.response && (
            <div className="px-4 pb-4 space-y-3">
              <div className="flex gap-2">
                <button
                  onClick={() => onUpdate({
                    ...step,
                    responseMapping: { ...step.responseMapping, mode: "json" }
                  })}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    step.responseMapping.mode === "json"
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  JSON
                </button>
                <button
                  onClick={() => onUpdate({
                    ...step,
                    responseMapping: { ...step.responseMapping, mode: "keyValue" }
                  })}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    step.responseMapping.mode === "keyValue"
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  Key-Value
                </button>
                <button
                  onClick={() => onUpdate({
                    ...step,
                    responseMapping: { ...step.responseMapping, mode: "default" }
                  })}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    step.responseMapping.mode === "default"
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  Default
                </button>
              </div>

              {step.responseMapping.mode === "json" && (
                <textarea
                  value={step.responseMapping.jsonValue}
                  onChange={(e) => onUpdate({
                    ...step,
                    responseMapping: { ...step.responseMapping, jsonValue: e.target.value }
                  })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm"
                  rows={4}
                  placeholder='Map response fields...'
                />
              )}

              {step.responseMapping.mode === "default" && (
                <select
                  value={step.responseMapping.defaultPayloadId || ""}
                  onChange={(e) => onUpdate({
                    ...step,
                    responseMapping: { ...step.responseMapping, defaultPayloadId: e.target.value }
                  })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="">-- Select Default Response --</option>
                  {DEFAULT_PAYLOADS.map(payload => (
                    <option key={payload.id} value={payload.id}>{payload.name}</option>
                  ))}
                </select>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Variable Picker Sidebar - Always Visible */}
      <VariablePickerSidebar
        steps={allSteps}
        currentStepIndex={stepIndex}
        onSelectVariable={handleVariableSelect}
      />
    </div>
  );
}

function TestApiModal({ 
  service, 
  onClose 
}: { 
  service: ApiService;
  onClose: () => void;
}) {
  const [testing, setTesting] = useState(false);
  const [testResults, setTestResults] = useState<any[]>([]);
  const [appParamValues, setAppParamValues] = useState<Record<string, string>>({});
  const [showParamForm, setShowParamForm] = useState(true);

  // Extract all app-level variables used in the API flow
  const extractAppVariables = (): string[] => {
    const variableSet = new Set<string>();
    const appVarRegex = /\{\{app\.(\w+)\}\}/g;

    service.steps.forEach(step => {
      // Check API URL
      let matches = step.apiUrl.matchAll(appVarRegex);
      for (const match of matches) {
        variableSet.add(match[1]);
      }

      // Check auth config
      if (step.apiKeyConfig.username) {
        matches = step.apiKeyConfig.username.matchAll(appVarRegex);
        for (const match of matches) {
          variableSet.add(match[1]);
        }
      }
      if (step.apiKeyConfig.password) {
        matches = step.apiKeyConfig.password.matchAll(appVarRegex);
        for (const match of matches) {
          variableSet.add(match[1]);
        }
      }
      if (step.apiKeyConfig.bearerToken) {
        matches = step.apiKeyConfig.bearerToken.matchAll(appVarRegex);
        for (const match of matches) {
          variableSet.add(match[1]);
        }
      }

      // Check additional headers
      if (step.additionalHeaders.mode === 'json') {
        matches = step.additionalHeaders.jsonValue.matchAll(appVarRegex);
        for (const match of matches) {
          variableSet.add(match[1]);
        }
      } else {
        step.additionalHeaders.keyValuePairs.forEach(pair => {
          const keyMatches = pair.key.matchAll(appVarRegex);
          for (const match of keyMatches) {
            variableSet.add(match[1]);
          }
          const valueMatches = pair.value.matchAll(appVarRegex);
          for (const match of valueMatches) {
            variableSet.add(match[1]);
          }
        });
      }

      // Check request payload
      if (step.requestPayload.mode === 'json') {
        matches = step.requestPayload.jsonValue.matchAll(appVarRegex);
        for (const match of matches) {
          variableSet.add(match[1]);
        }
      } else if (step.requestPayload.mode === 'keyValue') {
        step.requestPayload.keyValuePairs.forEach(pair => {
          const keyMatches = pair.key.matchAll(appVarRegex);
          for (const match of keyMatches) {
            variableSet.add(match[1]);
          }
          const valueMatches = pair.value.matchAll(appVarRegex);
          for (const match of valueMatches) {
            variableSet.add(match[1]);
          }
        });
      }

      // Check response mapping
      if (step.responseMapping.mode === 'json') {
        matches = step.responseMapping.jsonValue.matchAll(appVarRegex);
        for (const match of matches) {
          variableSet.add(match[1]);
        }
      } else if (step.responseMapping.mode === 'keyValue') {
        step.responseMapping.keyValuePairs.forEach(pair => {
          const keyMatches = pair.key.matchAll(appVarRegex);
          for (const match of keyMatches) {
            variableSet.add(match[1]);
          }
          const valueMatches = pair.value.matchAll(appVarRegex);
          for (const match of valueMatches) {
            variableSet.add(match[1]);
          }
        });
      }
    });

    return Array.from(variableSet);
  };

  const usedAppVariables = extractAppVariables();

  // Replace variables in a string with actual values
  const replaceVariables = (text: string, stepResults: any[]): string => {
    let result = text;
    
    // Replace app-level variables
    Object.keys(appParamValues).forEach(key => {
      const regex = new RegExp(`\\{\\{app\\.${key}\\}\\}`, 'g');
      result = result.replace(regex, appParamValues[key]);
    });

    // Replace step variables
    stepResults.forEach((stepResult, index) => {
      const stepNumber = index + 1;
      if (stepResult.response && stepResult.response.data) {
        Object.keys(stepResult.response.data).forEach(key => {
          const regex = new RegExp(`\\{\\{step${stepNumber}\\.${key}\\}\\}`, 'g');
          result = result.replace(regex, stepResult.response.data[key]);
        });
      }
    });

    return result;
  };

  const handleTest = async () => {
    setTesting(true);
    setTestResults([]);
    setShowParamForm(false);

    // Simulate API testing with variable replacement
    const results: any[] = [];
    
    for (let i = 0; i < service.steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const step = service.steps[i];
      
      // Replace variables in URL
      const processedUrl = replaceVariables(step.apiUrl, results);
      
      // Process request payload
      let processedPayload = "{}";
      if (step.requestPayload.mode === 'json' && step.requestPayload.jsonValue.trim() !== "") {
        processedPayload = replaceVariables(step.requestPayload.jsonValue, results);
      } else if (step.requestPayload.mode === 'keyValue') {
        const payloadObj: any = {};
        step.requestPayload.keyValuePairs.forEach(pair => {
          if (pair.key) {
            const processedKey = replaceVariables(pair.key, results);
            const processedValue = replaceVariables(pair.value, results);
            payloadObj[processedKey] = processedValue;
          }
        });
        processedPayload = JSON.stringify(payloadObj, null, 2);
      }
      
      // Process headers
      const headers: any = { "Content-Type": step.requestContentType };
      if (step.additionalHeaders.mode === 'json' && step.additionalHeaders.jsonValue.trim() !== "") {
        try {
          const processedHeadersJson = replaceVariables(step.additionalHeaders.jsonValue, results);
          const additionalHeaders = JSON.parse(processedHeadersJson);
          Object.assign(headers, additionalHeaders);
        } catch (e) {
          // Skip invalid JSON
        }
      } else if (step.additionalHeaders.mode === 'keyValue') {
        step.additionalHeaders.keyValuePairs.forEach(pair => {
          if (pair.key) {
            const processedKey = replaceVariables(pair.key, results);
            const processedValue = replaceVariables(pair.value, results);
            headers[processedKey] = processedValue;
          }
        });
      }
      
      // Process auth
      if (step.authType === 'Basic' && step.apiKeyConfig.username && step.apiKeyConfig.password) {
        const username = replaceVariables(step.apiKeyConfig.username, results);
        const password = replaceVariables(step.apiKeyConfig.password, results);
        headers['Authorization'] = `Basic ${btoa(`${username}:${password}`)}`;
      } else if (step.authType === 'Bearer' && step.apiKeyConfig.bearerToken) {
        const token = replaceVariables(step.apiKeyConfig.bearerToken, results);
        headers['Authorization'] = `Bearer ${token}`;
      }
      
      const mockResult = {
        stepNumber: i + 1,
        success: true,
        request: {
          url: processedUrl,
          method: step.requestMethod,
          headers: headers,
          body: processedPayload,
        },
        response: {
          status: 200,
          statusText: "OK",
          data: i === 0 
            ? { token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...", status: "success" }
            : { data: { id: "12345", message: "Success" }, status: "completed" }
        },
        duration: Math.floor(Math.random() * 500) + 200,
      };

      results.push(mockResult);
      setTestResults([...results]);
    }

    setTesting(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
        <div className="bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
              <Play className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg">Test API Service</h2>
              <p className="text-xs text-green-100">{service.name}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-auto p-6 space-y-4">
          {/* App Parameter Input Form */}
          {showParamForm && usedAppVariables.length > 0 && (
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200 rounded-lg p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Key className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-medium text-blue-900">Application Parameters Required</h3>
                  <p className="text-sm text-blue-700">
                    This API flow uses {usedAppVariables.length} app-level variable{usedAppVariables.length > 1 ? 's' : ''}. Please provide values to test.
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {usedAppVariables.map((variable) => (
                  <div key={variable}>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {`{{app.${variable}}}`}
                      <span className="text-red-500 ml-1">*</span>
                    </label>
                    <input
                      type="text"
                      value={appParamValues[variable] || ""}
                      onChange={(e) => setAppParamValues(prev => ({ ...prev, [variable]: e.target.value }))}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder={`Enter value for ${variable}`}
                    />
                  </div>
                ))}
              </div>
              <div className="mt-4 flex items-start gap-2 bg-blue-100 rounded p-3">
                <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                <p className="text-xs text-blue-800">
                  These values will replace the corresponding variables throughout the API flow during testing.
                </p>
              </div>
            </div>
          )}

          {showParamForm && usedAppVariables.length === 0 && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-sm font-medium text-green-900">No Parameters Required</p>
                <p className="text-xs text-green-700">This API flow doesn't use any app-level variables. Ready to test!</p>
              </div>
            </div>
          )}

          {/* Test Results */}
          {testResults.map((result, index) => (
            <div key={index} className="bg-white border border-gray-200 rounded-lg overflow-hidden">
              <div className={`px-4 py-3 flex items-center justify-between ${
                result.success ? "bg-green-50 border-b border-green-200" : "bg-red-50 border-b border-red-200"
              }`}>
                <div className="flex items-center gap-3">
                  {result.success ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-red-600" />
                  )}
                  <span className="font-medium text-gray-900">Step {result.stepNumber}</span>
                  <span className="text-xs text-gray-500">{result.duration}ms</span>
                </div>
                <span className={`px-2 py-1 rounded text-xs ${
                  result.success ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                }`}>
                  {result.response.status} {result.response.statusText}
                </span>
              </div>

              <div className="p-4 space-y-3">
                <div>
                  <div className="text-xs font-medium text-gray-600 mb-2">Request</div>
                  <div className="bg-gray-50 rounded p-3 border border-gray-200">
                    <div className="text-xs space-y-1">
                      <div><span className="text-gray-600">URL:</span> <span className="text-blue-600">{result.request.url}</span></div>
                      <div><span className="text-gray-600">Method:</span> <span className="font-medium">{result.request.method}</span></div>
                    </div>
                    <pre className="text-xs text-gray-700 mt-2 overflow-auto">
                      {(() => {
                        try {
                          return JSON.stringify(JSON.parse(result.request.body), null, 2);
                        } catch (e) {
                          return result.request.body || "No request body";
                        }
                      })()}
                    </pre>
                  </div>
                </div>

                <div>
                  <div className="text-xs font-medium text-gray-600 mb-2">Response</div>
                  <div className="bg-gray-50 rounded p-3 border border-gray-200">
                    <pre className="text-xs text-gray-700 overflow-auto">
                      {JSON.stringify(result.response.data, null, 2)}
                    </pre>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {testing && (
            <div className="flex items-center justify-center py-8">
              <div className="text-center">
                <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
                <p className="text-gray-600">Testing API...</p>
              </div>
            </div>
          )}
        </div>

        <div className="bg-gray-50 px-6 py-4 border-t border-gray-200 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-6 py-2 text-gray-700 hover:bg-gray-200 rounded-lg transition-colors"
          >
            Close
          </button>
          <button
            onClick={handleTest}
            disabled={testing || (usedAppVariables.length > 0 && Object.keys(appParamValues).length < usedAppVariables.length)}
            className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 transition-colors flex items-center gap-2"
          >
            <Play className="w-4 h-4" />
            {testing ? "Testing..." : "Run Test"}
          </button>
        </div>
      </div>
    </div>
  );
}

export function ApiConfigurations() {
  const [apiServices, setApiServices] = useState<ApiService[]>([
    {
      id: "1",
      name: "JWT Authentication Flow",
      description: "Multi-step authentication with JWT token generation and API call",
      createdAt: "2025-11-20",
      steps: [
        {
          id: "s1",
          stepNumber: 1,
          apiUrl: "https://api.example.com/auth/token",
          requestMethod: "POST",
          requestContentType: "application/json",
          responseContentType: "application/json",
          authType: "Basic",
          apiKeyConfig: {
            type: "basic",
            username: "admin",
            password: "password123",
          },
          additionalHeaders: {
            mode: "json",
            jsonValue: "",
            keyValuePairs: [],
          },
          requestPayload: {
            mode: "json",
            jsonValue: '{\n  "grant_type": "client_credentials"\n}',
            keyValuePairs: [],
          },
          responseMapping: {
            mode: "json",
            jsonValue: "",
            keyValuePairs: [],
          },
        },
      ],
    },
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showTestModal, setShowTestModal] = useState(false);
  const [selectedService, setSelectedService] = useState<ApiService | null>(null);

  const [serviceName, setServiceName] = useState("");
  const [serviceDescription, setServiceDescription] = useState("");
  const [steps, setSteps] = useState<ApiStep[]>([]);

  const createEmptyStep = (stepNumber: number): ApiStep => ({
    id: `step-${Date.now()}-${stepNumber}`,
    stepNumber,
    apiUrl: "",
    requestMethod: "POST",
    requestContentType: "application/json",
    responseContentType: "application/json",
    authType: "None",
    apiKeyConfig: { type: "none" },
    additionalHeaders: {
      mode: "json",
      jsonValue: "",
      keyValuePairs: [],
    },
    requestPayload: {
      mode: "json",
      jsonValue: "",
      keyValuePairs: [],
    },
    responseMapping: {
      mode: "json",
      jsonValue: "",
      keyValuePairs: [],
    },
  });

  const handleAddService = () => {
    setServiceName("");
    setServiceDescription("");
    setSteps([createEmptyStep(1)]);
    setShowAddModal(true);
  };

  const handleEditService = (service: ApiService) => {
    setSelectedService(service);
    setServiceName(service.name);
    setServiceDescription(service.description);
    setSteps(service.steps);
    setShowEditModal(true);
  };

  const handleTestService = (service: ApiService) => {
    setSelectedService(service);
    setShowTestModal(true);
  };

  const handleSaveService = () => {
    const newService: ApiService = {
      id: selectedService?.id || Date.now().toString(),
      name: serviceName,
      description: serviceDescription,
      steps,
      createdAt: selectedService?.createdAt || new Date().toISOString().split('T')[0],
    };

    if (showEditModal && selectedService) {
      setApiServices(apiServices.map(s => s.id === selectedService.id ? newService : s));
    } else {
      setApiServices([...apiServices, newService]);
    }

    handleCloseModal();
  };

  const handleCloseModal = () => {
    setShowAddModal(false);
    setShowEditModal(false);
    setSelectedService(null);
    setServiceName("");
    setServiceDescription("");
    setSteps([]);
  };

  const handleAddStep = () => {
    setSteps([...steps, createEmptyStep(steps.length + 1)]);
  };

  const handleUpdateStep = (index: number, updatedStep: ApiStep) => {
    const updated = [...steps];
    updated[index] = updatedStep;
    setSteps(updated);
  };

  const handleDeleteStep = (index: number) => {
    const updated = steps.filter((_, i) => i !== index);
    // Renumber steps
    const renumbered = updated.map((step, i) => ({ ...step, stepNumber: i + 1 }));
    setSteps(renumbered);
  };

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-gray-900 text-xl">API Configurations</h1>
            <p className="text-sm text-gray-600 mt-1">
              Manage multi-step API service configurations
            </p>
          </div>
          <button
            onClick={handleAddService}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add New API
          </button>
        </div>
      </div>

      {/* API Services List */}
      <div className="flex-1 overflow-auto p-6">
        <div className="grid gap-4">
          {apiServices.map((service) => (
            <div
              key={service.id}
              className="bg-white rounded-lg border border-gray-200 hover:border-blue-300 transition-colors"
            >
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                        <Globe className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-gray-900">{service.name}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="inline-block px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs">
                            {service.steps.length} Step{service.steps.length > 1 ? 's' : ''}
                          </span>
                          <span className="text-xs text-gray-500">{service.createdAt}</span>
                        </div>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mt-3">{service.description}</p>
                    
                    {/* Steps Preview */}
                    <div className="mt-4 flex items-center gap-2">
                      {service.steps.map((step, index) => (
                        <div key={step.id} className="flex items-center">
                          <div className="px-3 py-1 bg-gray-100 rounded text-xs text-gray-700">
                            Step {step.stepNumber}: {step.requestMethod}
                          </div>
                          {index < service.steps.length - 1 && (
                            <ArrowRight className="w-4 h-4 text-gray-400 mx-1" />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 ml-4">
                    <button
                      onClick={() => handleTestService(service)}
                      className="px-4 py-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors flex items-center gap-2 border border-green-200"
                    >
                      <Play className="w-4 h-4" />
                      Test
                    </button>
                    <button
                      onClick={() => handleEditService(service)}
                      className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors flex items-center gap-2 border border-gray-200"
                    >
                      <Edit className="w-4 h-4" />
                      Edit
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {apiServices.length === 0 && (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-gray-900 mb-2">No API Services Found</h3>
              <p className="text-sm text-gray-600 mb-4">
                Get started by adding your first API service configuration
              </p>
              <button
                onClick={handleAddService}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Add New API
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Add/Edit Modal */}
      {(showAddModal || showEditModal) && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-[95vw] max-h-[95vh] flex flex-col">
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                  <Globe className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg">{showEditModal ? "Edit" : "Add New"} API Service</h2>
                  <p className="text-xs text-blue-100">Configure multi-step API service</p>
                </div>
              </div>
              <button
                onClick={handleCloseModal}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-auto p-6 space-y-6">
              {/* Service Details */}
              <div className="bg-white border border-gray-200 rounded-lg p-4 space-y-4">
                <h3 className="font-medium text-gray-900">Service Details</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Service Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={serviceName}
                      onChange={(e) => setServiceName(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="e.g., JWT Authentication Flow"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Description <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={serviceDescription}
                      onChange={(e) => setServiceDescription(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Brief description of the API service"
                    />
                  </div>
                </div>
              </div>

              {/* API Steps */}
              <div className="space-y-4">
                {steps.map((step, index) => (
                  <ApiStepForm
                    key={step.id}
                    step={step}
                    stepIndex={index}
                    totalSteps={steps.length}
                    allSteps={steps}
                    onUpdate={(updated) => handleUpdateStep(index, updated)}
                    onDelete={() => handleDeleteStep(index)}
                  />
                ))}

                <button
                  onClick={handleAddStep}
                  className="w-full px-6 py-4 border-2 border-dashed border-blue-300 rounded-lg text-blue-600 hover:border-blue-400 hover:bg-blue-50 transition-colors flex items-center justify-center gap-2"
                >
                  <Plus className="w-5 h-5" />
                  Add Next Step
                </button>
              </div>
            </div>

            <div className="bg-gray-50 px-6 py-4 border-t border-gray-200 flex justify-end gap-3">
              <button
                onClick={handleCloseModal}
                className="px-6 py-2 text-gray-700 hover:bg-gray-200 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveService}
                disabled={!serviceName || !serviceDescription || steps.length === 0}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
              >
                <CheckCircle className="w-4 h-4" />
                Save API Service
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Test Modal */}
      {showTestModal && selectedService && (
        <TestApiModal service={selectedService} onClose={() => setShowTestModal(false)} />
      )}
    </div>
  );
}
