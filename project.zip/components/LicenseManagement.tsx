import { useState } from "react";
import { 
  X, 
  Check, 
  ChevronLeft, 
  ChevronRight, 
  RefreshCw,
  Package,
  Plus,
  ChevronDown
} from "lucide-react";
import { LicenseScreen } from "./LicenseScreen";

interface LicenseManagementProps {
  onClose: () => void;
  onComplete: (data: any) => void;
  currentExpiryDate: string;
  currentModules: string;
}

type Step = 1 | 2 | 3;
type Action = 'renewal' | 'add-module' | null;

export function LicenseManagement({ onClose, onComplete, currentExpiryDate, currentModules }: LicenseManagementProps) {
  const [currentStep, setCurrentStep] = useState<Step>(1);
  const [selectedAction, setSelectedAction] = useState<Action>(null);
  const [registrationCode] = useState<string>("LIC-" + Math.random().toString(36).substring(2, 15).toUpperCase());

  const [selectedModules, setSelectedModules] = useState<string[]>([]);
  const [selectedSubModules, setSelectedSubModules] = useState<string[]>([]);

  const availableModules = [
    { 
      id: 'base', 
      name: 'BASE', 
      description: 'Bharat Aadhaar Seeding Enabler',
      hasSubmodules: false
    },
    { 
      id: 'itr', 
      name: 'ITR VALIDATION', 
      description: 'Income Tax Return validation module',
      hasSubmodules: false
    },
    { 
      id: 'payment-gateway', 
      name: 'Payment Gateway', 
      description: 'Integrated payment processing',
      hasSubmodules: false
    },
    { 
      id: 'api-emandate', 
      name: 'API EMandate Destination', 
      description: 'Electronic mandate management through APIs',
      hasSubmodules: true
    },
    { 
      id: 'mandate-mgmt', 
      name: 'Mandate Management', 
      description: 'Complete mandate lifecycle management',
      hasSubmodules: false
    },
  ];

  const apiEmandateSubModules = [
    { id: 'aadhar-mandate', name: 'Aadhar Mandate' },
    { id: 'debit-mandate', name: 'Debit Mandate' },
    { id: 'netbanking-mandate', name: 'Netbanking Mandate' },
    { id: 'pan-mandate', name: 'Pan Mandate' },
    { id: 'cust-id', name: 'Cust Id' },
    { id: 'aadhar-simplified', name: 'Aadhar Simplified' },
    { id: 'casr-destination', name: 'CASR Destination' },
  ];

  // Get current active modules as array
  const currentModulesList = currentModules.split(',').map(m => m.trim()).filter(m => m);

  // Filter out already active modules
  const availableNewModules = availableModules.filter(module => {
    return !currentModulesList.some(active => 
      active.toLowerCase().includes(module.name.toLowerCase()) || 
      module.name.toLowerCase().includes(active.toLowerCase())
    );
  });

  const getSteps = () => {
    if (selectedAction === 'renewal') {
      return [
        { number: 1 as Step, title: 'Action' },
        { number: 2 as Step, title: 'License' },
        { number: 3 as Step, title: 'Complete' }
      ];
    } else if (selectedAction === 'add-module') {
      return [
        { number: 1 as Step, title: 'Action' },
        { number: 2 as Step, title: 'Modules' },
        { number: 3 as Step, title: 'License' }
      ];
    }
    return [
      { number: 1 as Step, title: 'Action' },
      { number: 2 as Step, title: 'Details' },
      { number: 3 as Step, title: 'Complete' }
    ];
  };

  const steps = getSteps();

  const handleNext = () => {
    if (selectedAction === 'renewal' && currentStep === 1) {
      setCurrentStep(2 as Step);
    } else if (selectedAction === 'add-module' && currentStep === 1) {
      setCurrentStep(2 as Step);
    } else if (selectedAction === 'add-module' && currentStep === 2) {
      setCurrentStep(3 as Step);
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      setCurrentStep((currentStep - 1) as Step);
    }
  };

  const handleLicenseValidated = () => {
    // Prepare completion data based on action
    const completionData = {
      action: selectedAction,
      modules: selectedAction === 'add-module' ? selectedModules : [],
      duration: 12 // Default 12 months for renewal
    };
    onComplete(completionData);
  };

  const toggleModule = (moduleId: string) => {
    setSelectedModules(prev => {
      const newModules = prev.includes(moduleId)
        ? prev.filter(id => id !== moduleId)
        : [...prev, moduleId];
      
      // If unchecking API EMandate, clear its sub-modules
      if (!newModules.includes("api-emandate")) {
        setSelectedSubModules([]);
      }
      
      return newModules;
    });
  };

  const toggleSubModule = (subModuleId: string) => {
    setSelectedSubModules(prev => 
      prev.includes(subModuleId) 
        ? prev.filter(id => id !== subModuleId)
        : [...prev, subModuleId]
    );
  };

  const canProceed = () => {
    if (currentStep === 1) return selectedAction !== null;
    if (currentStep === 2 && selectedAction === 'add-module') return selectedModules.length > 0;
    return true;
  };

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center z-50 p-2">
      <div className="w-full max-w-5xl h-full flex flex-col py-2">
        {/* Header */}
        <div className="text-center mb-3">
          <div className="flex items-center justify-center gap-2 mb-1">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-600 to-teal-700 rounded-xl flex items-center justify-center shadow-lg">
              <Package className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-gray-800 text-xl">License Management</h1>
              <p className="text-xs text-gray-600">
                {selectedAction === 'renewal' && 'Renew your license to continue using the platform'}
                {selectedAction === 'add-module' && 'Add new modules to expand your capabilities'}
                {!selectedAction && 'Choose an action to proceed'}
              </p>
            </div>
            <button
              onClick={onClose}
              className="ml-auto p-2 text-gray-400 hover:text-gray-600 hover:bg-white/50 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Progress Steps */}
        <div className="mb-3">
          <div className="flex items-center justify-center gap-1">
            {steps.map((step, index) => (
              <div key={step.number} className="flex items-center">
                <div className="flex flex-col items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-all text-xs ${
                      currentStep === step.number
                        ? "bg-emerald-600 text-white shadow-lg shadow-emerald-300"
                        : currentStep > step.number
                        ? "bg-green-500 text-white"
                        : "bg-gray-200 text-gray-500"
                    }`}
                  >
                    {currentStep > step.number ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      <span>{step.number}</span>
                    )}
                  </div>
                  <div className="mt-1 text-center">
                    <div
                      className={`text-xs ${
                        currentStep === step.number ? "text-emerald-600" : "text-gray-600"
                      }`}
                    >
                      {step.title}
                    </div>
                  </div>
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`w-12 h-0.5 mx-1 mb-6 transition-all ${
                      currentStep > step.number ? "bg-green-500" : "bg-gray-200"
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content Card - Scrollable Area */}
        <div className="bg-white rounded-xl shadow-xl border border-gray-100 p-4 flex-1 overflow-y-auto mb-3">
          {/* Step 1: Choose Action */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div>
                <h2 className="text-gray-800 mb-1 text-lg">What would you like to do?</h2>
                <p className="text-xs text-gray-600">
                  Choose to renew your existing license or add new modules
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                {/* Renewal Option */}
                <button
                  onClick={() => setSelectedAction('renewal')}
                  className={`p-6 border-2 rounded-xl transition-all text-left ${
                    selectedAction === 'renewal'
                      ? 'border-emerald-500 bg-emerald-50 shadow-lg'
                      : 'border-gray-200 hover:border-emerald-300 bg-white'
                  }`}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      selectedAction === 'renewal' ? 'bg-emerald-500' : 'bg-emerald-100'
                    }`}>
                      <RefreshCw className={`w-6 h-6 ${
                        selectedAction === 'renewal' ? 'text-white' : 'text-emerald-600'
                      }`} />
                    </div>
                    {selectedAction === 'renewal' && (
                      <div className="w-6 h-6 bg-emerald-500 rounded-full flex items-center justify-center">
                        <Check className="w-4 h-4 text-white" />
                      </div>
                    )}
                  </div>
                  <h3 className="text-base text-gray-800 mb-2">License Renewal</h3>
                  <p className="text-xs text-gray-600 mb-4">
                    Extend your current license and continue using all active modules
                  </p>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs text-gray-700">
                      <Check className="w-3 h-3 text-green-600" />
                      <span>Extend license duration</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-700">
                      <Check className="w-3 h-3 text-green-600" />
                      <span>Automatic validation</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-700">
                      <Check className="w-3 h-3 text-green-600" />
                      <span>Instant activation</span>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-600">Current Expiry:</span>
                      <span className="text-gray-800">{currentExpiryDate}</span>
                    </div>
                  </div>
                </button>

                {/* Add Module Option */}
                <button
                  onClick={() => setSelectedAction('add-module')}
                  className={`p-6 border-2 rounded-xl transition-all text-left ${
                    selectedAction === 'add-module'
                      ? 'border-blue-500 bg-blue-50 shadow-lg'
                      : 'border-gray-200 hover:border-blue-300 bg-white'
                  }`}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      selectedAction === 'add-module' ? 'bg-blue-500' : 'bg-blue-100'
                    }`}>
                      <Plus className={`w-6 h-6 ${
                        selectedAction === 'add-module' ? 'text-white' : 'text-blue-600'
                      }`} />
                    </div>
                    {selectedAction === 'add-module' && (
                      <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                        <Check className="w-4 h-4 text-white" />
                      </div>
                    )}
                  </div>
                  <h3 className="text-base text-gray-800 mb-2">Add New Modules</h3>
                  <p className="text-xs text-gray-600 mb-4">
                    Expand your platform capabilities by adding new modules
                  </p>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs text-gray-700">
                      <Check className="w-3 h-3 text-green-600" />
                      <span>Multiple module selection</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-700">
                      <Check className="w-3 h-3 text-green-600" />
                      <span>Instant activation</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-700">
                      <Check className="w-3 h-3 text-green-600" />
                      <span>License validation included</span>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-600">Active Modules:</span>
                      <span className="text-gray-800">{currentModulesList.length}</span>
                    </div>
                  </div>
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Module Selection (for Add Module only) */}
          {currentStep === 2 && selectedAction === 'add-module' && (
            <div className="space-y-4">
              <div>
                <h2 className="text-gray-800 mb-1 text-lg">Select Modules to Add</h2>
                <p className="text-xs text-gray-600">
                  Choose one or more modules to expand your platform capabilities
                </p>
              </div>

              {availableNewModules.length === 0 ? (
                <div className="p-6 bg-gray-50 border border-gray-200 rounded-xl text-center">
                  <p className="text-sm text-gray-600">All available modules are already active.</p>
                </div>
              ) : (
                <>
                  <div className="space-y-3">
                    {availableNewModules.map((module) => (
                      <div key={module.id}>
                        <button
                          onClick={() => toggleModule(module.id)}
                          className={`w-full p-4 border-2 rounded-xl transition-all text-left ${
                            selectedModules.includes(module.id)
                              ? 'border-blue-500 bg-blue-50 shadow-md'
                              : 'border-gray-200 hover:border-blue-300 bg-white'
                          }`}
                        >
                          <div className="flex items-start gap-4">
                            <div className={`w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 mt-0.5 ${
                              selectedModules.includes(module.id)
                                ? 'bg-blue-500 border-blue-500'
                                : 'border-gray-300'
                            }`}>
                              {selectedModules.includes(module.id) && (
                                <Check className="w-3 h-3 text-white" />
                              )}
                            </div>
                            <div className="flex-1">
                              <h3 className="text-sm text-gray-800 mb-1">{module.name}</h3>
                              <p className="text-xs text-gray-600">{module.description}</p>
                            </div>
                            {module.hasSubmodules && selectedModules.includes(module.id) && (
                              <ChevronDown className="w-4 h-4 text-blue-600 flex-shrink-0" />
                            )}
                          </div>
                        </button>

                        {/* Sub-modules for API EMandate */}
                        {module.id === "api-emandate" && selectedModules.includes(module.id) && (
                          <div className="ml-8 mt-2 space-y-2">
                            {apiEmandateSubModules.map(subModule => (
                              <button 
                                key={subModule.id}
                                onClick={() => toggleSubModule(subModule.id)}
                                className={`w-full p-3 border rounded-lg cursor-pointer transition-all text-left ${
                                  selectedSubModules.includes(subModule.id)
                                    ? 'border-blue-400 bg-blue-50'
                                    : 'border-gray-200 bg-white hover:border-blue-200'
                                }`}
                              >
                                <div className="flex items-center gap-3">
                                  <div className={`w-4 h-4 rounded border-2 flex items-center justify-center ${
                                    selectedSubModules.includes(subModule.id)
                                      ? 'bg-blue-500 border-blue-500'
                                      : 'border-gray-300'
                                  }`}>
                                    {selectedSubModules.includes(subModule.id) && (
                                      <Check className="w-2.5 h-2.5 text-white" />
                                    )}
                                  </div>
                                  <span className={`text-xs ${
                                    selectedSubModules.includes(subModule.id) ? 'text-blue-700' : 'text-gray-700'
                                  }`}>
                                    {subModule.name}
                                  </span>
                                </div>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  {selectedModules.length > 0 && (
                    <div className="p-4 bg-gradient-to-br from-blue-50 to-white rounded-xl border border-blue-200">
                      <div className="flex items-start gap-2">
                        <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <Check className="w-4 h-4 text-white" />
                        </div>
                        <div>
                          <h3 className="text-gray-800 mb-0.5 text-sm">
                            {selectedModules.length} Module{selectedModules.length > 1 ? 's' : ''} Selected
                          </h3>
                          <p className="text-xs text-gray-600 mb-1">
                            {availableNewModules
                              .filter(m => selectedModules.includes(m.id))
                              .map(m => m.name)
                              .join(', ')}
                          </p>
                          {selectedSubModules.length > 0 && (
                            <p className="text-xs text-gray-500">
                              API EMandate Sub-modules: {apiEmandateSubModules
                                .filter(sm => selectedSubModules.includes(sm.id))
                                .map(sm => sm.name)
                                .join(', ')}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {/* License Screen - Step 2 for Renewal, Step 3 for Add Module */}
          {((currentStep === 2 && selectedAction === 'renewal') || 
            (currentStep === 3 && selectedAction === 'add-module')) && (
            <LicenseScreen
              registrationCode={registrationCode}
              onLicenseValidated={handleLicenseValidated}
            />
          )}
        </div>

        {/* Footer Navigation */}
        <div className="flex items-center justify-between bg-white rounded-xl shadow-lg border border-gray-100 px-4 py-3">
          <button
            onClick={currentStep === 1 ? onClose : handlePrev}
            className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors text-sm"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>{currentStep === 1 ? 'Cancel' : 'Previous'}</span>
          </button>

          <div className="text-xs text-gray-500">
            Step {currentStep} of {steps.length}
          </div>

          {/* Only show Next button on step 1 and step 2 (for add-module) */}
          {((currentStep === 1) || (currentStep === 2 && selectedAction === 'add-module')) && (
            <button
              onClick={handleNext}
              disabled={!canProceed()}
              className={`flex items-center gap-2 px-6 py-2 rounded-lg transition-all text-sm ${
                canProceed()
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-lg shadow-emerald-200'
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              }`}
            >
              <span>Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
          
          {/* Show empty div on license screen to maintain spacing */}
          {((currentStep === 2 && selectedAction === 'renewal') || 
            (currentStep === 3 && selectedAction === 'add-module')) && (
            <div className="w-20"></div>
          )}
        </div>
      </div>
    </div>
  );
}
