import { useState } from "react";
import { User, Lock, RefreshCw, LogIn } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

type UserType = "normal" | "superadmin" | null;

interface LoginPageProps {
  onLoginSuccess: (userType: UserType) => void;
}

export function LoginPage({ onLoginSuccess }: LoginPageProps) {
  const [username, setUsername] = useState("superadmin");
  const [password, setPassword] = useState("••••••••");
  const [captcha, setCaptcha] = useState("");
  const [captchaCode, setCaptchaCode] = useState("EcfZgAe");
  const [showPassword, setShowPassword] = useState(false);

  const refreshCaptcha = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
    let newCaptcha = "";
    for (let i = 0; i < 7; i++) {
      newCaptcha += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setCaptchaCode(newCaptcha);
    setCaptcha("");
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Determine user type based on username
    if (username.toLowerCase() === "superadmin") {
      onLoginSuccess("superadmin");
    } else {
      onLoginSuccess("normal");
    }
  };

  return (
    <div className="h-screen relative flex items-center justify-center p-6 overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1630283017802-785b7aff9aac?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBvZmZpY2UlMjB3b3Jrc3BhY2V8ZW58MXx8fHwxNzYzOTkxNTg0fDA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Office background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/40 via-slate-900/50 to-blue-900/40 backdrop-blur-[2px]" />
      </div>

      {/* Login Card */}
      <div className="relative z-10 w-full max-w-6xl h-[calc(100vh-3rem)] bg-white rounded-2xl shadow-2xl overflow-hidden">
        <div className="grid md:grid-cols-[1fr_1.5fr] gap-0 h-full">
          {/* Left Side - Branding */}
          <div className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 p-12 flex flex-col items-center justify-center text-white relative overflow-hidden">
            {/* Decorative Circuit Pattern */}
            <div className="absolute inset-0 opacity-10">
              <svg className="w-full h-full" viewBox="0 0 400 400" fill="none">
                <path d="M50 100 L150 100 L150 200 L250 200" stroke="white" strokeWidth="2" />
                <path d="M100 50 L100 150 L200 150 L200 250" stroke="white" strokeWidth="2" />
                <path d="M200 100 L300 100 L300 200 L350 200" stroke="white" strokeWidth="2" />
                <path d="M150 250 L250 250 L250 350" stroke="white" strokeWidth="2" />
                <circle cx="150" cy="100" r="4" fill="white" />
                <circle cx="150" cy="200" r="4" fill="white" />
                <circle cx="100" cy="150" r="4" fill="white" />
                <circle cx="200" cy="150" r="4" fill="white" />
                <circle cx="300" cy="100" r="4" fill="white" />
                <circle cx="250" cy="250" r="4" fill="white" />
              </svg>
            </div>

            {/* Rupee Symbol */}
            <div className="relative z-10 mb-8">
              <div className="w-32 h-32 flex items-center justify-center">
                <svg viewBox="0 0 100 120" fill="none" className="w-full h-full">
                  <path
                    d="M20 20 L80 20 M20 35 L75 35 M30 35 Q40 45 45 60 L45 100 L50 105 L60 95 L85 50 M45 60 Q50 75 65 85"
                    stroke="white"
                    strokeWidth="6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
            </div>

            {/* Info Text */}
            <div className="text-center space-y-4 relative z-10">
              <div className="space-y-1">
                <div className="text-sm tracking-wider opacity-90">WELCOME TO</div>
                <div className="tracking-wide">eNACH Services</div>
              </div>
              <p className="text-sm leading-relaxed opacity-80 px-4">
                NPCI has launched Bharat Aadhaar Seeding Enabler (BASE) platform to facilitate
                Aadhaar Seeding and De-seeding activities in self-service mode for Direct Benefit
                Transfer for enabling the citizens to verify our Million Activities in Digital mode.
              </p>
            </div>
          </div>

          {/* Right Side - Login Form */}
          <div className="p-8 flex flex-col justify-center overflow-y-auto">
            {/* Logos */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <span className="text-white">eN</span>
                </div>
                <div>
                  <div className="text-blue-600 tracking-tight">eNACH</div>
                  <div className="text-orange-500 text-xs tracking-tight">Services</div>
                </div>
              </div>
              <div className="flex items-center gap-2 border-2 border-gray-200 px-3 py-1 rounded-lg">
                <span className="text-blue-900 tracking-wide">NPCI</span>
                <div className="w-px h-6 bg-gray-300" />
                <span className="text-orange-500 text-xs">Enach</span>
              </div>
            </div>

            {/* Login Header */}
            <div className="mb-6">
              <h1 className="text-gray-800 mb-2">Login</h1>
              <div className="w-16 h-1 bg-gradient-to-r from-blue-600 to-blue-400 rounded-full" />
            </div>

            {/* Login Form */}
            <form onSubmit={handleLogin} className="space-y-5">
              {/* Username */}
              <div>
                <label className="block text-gray-600 text-sm mb-2">
                  Username <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full pl-11 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                    placeholder="Enter username"
                  />
                </div>
                {username && (
                  <div className="mt-2 text-xs text-blue-600 bg-blue-50 px-3 py-2 rounded-lg">
                    {username.toLowerCase() === "superadmin" ? (
                      <span>🔐 Superadmin: Login → TOTP → Dashboard</span>
                    ) : (
                      <span>👤 Normal User: Login → {!localStorage.getItem("user_setup_complete") ? "Google Auth Setup → Password Change → " : ""}Google Auth → Dashboard</span>
                    )}
                  </div>
                )}
              </div>

              {/* Password */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-gray-600 text-sm">
                    Password <span className="text-red-500">*</span>
                  </label>
                  <button
                    type="button"
                    className="text-blue-600 text-sm hover:text-blue-700 hover:underline transition-colors"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-11 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                    placeholder="Enter password"
                  />
                </div>
              </div>

              {/* Captcha */}
              <div>
                <label className="block text-gray-600 text-sm mb-2">
                  Captcha <span className="text-red-500">*</span>
                </label>
                <div className="flex gap-3">
                  <input
                    type="text"
                    value={captcha}
                    onChange={(e) => setCaptcha(e.target.value)}
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                    placeholder="Enter captcha"
                  />
                  <div className="flex items-center gap-2 px-4 py-3 bg-gray-100 border border-gray-300 rounded-lg">
                    <span className="select-none tracking-wider line-through decoration-gray-400" style={{ textDecorationStyle: 'wavy' }}>
                      {captchaCode}
                    </span>
                    <button
                      type="button"
                      onClick={refreshCaptcha}
                      className="text-gray-600 hover:text-blue-600 transition-colors"
                      aria-label="Refresh captcha"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Login Button */}
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white py-3 rounded-lg transition-all duration-300 flex items-center justify-center gap-2 shadow-lg shadow-blue-200 hover:shadow-xl hover:shadow-blue-300"
              >
                <LogIn className="w-5 h-5" />
                <span>Login</span>
              </button>
            </form>

            {/* Footer */}
            <div className="mt-8 pt-6 border-t border-gray-200 text-center">
              <div className="text-sm text-gray-600 mb-1">
                <span className="text-blue-600">eNach</span> Version <span className="text-gray-800">25.11.18</span>
              </div>
              <div className="text-xs text-gray-500">
                Designed & Developed By <span className="text-gray-700">SOFT-TECH SOLUTIONS</span>
              </div>
              <div className="text-xs text-gray-500 mt-1">
                Copyright © 2014 - 2025 | All Right Reserved
              </div>
              {/* Developer Mode - Reset First-Time Setup */}
              <button
                type="button"
                onClick={() => {
                  localStorage.removeItem("user_setup_complete");
                  alert("First-time setup flag cleared. Next normal user login will show Google Auth setup.");
                }}
                className="mt-3 text-xs text-gray-400 hover:text-blue-600 underline"
              >
                [Dev] Reset First-Time Setup
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}