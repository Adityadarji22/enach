import { useState, useRef, useEffect } from "react";
import { 
  Mail, 
  MessageSquare, 
  FileText, 
  Send, 
  Save, 
  Plus,
  Edit,
  Trash2,
  Search,
  Info,
  Check,
  Workflow,
  X,
  Copy,
  Bold,
  Italic,
  Link,
  List,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Code,
  ChevronDown,
  Server,
  Key,
  Settings,
  ExternalLink
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface Template {
  id: number;
  templateName: string;
  eventName: string;
  mailContent: string;
  mailStatus: "Active" | "Inactive";
  smsContent: string;
  smsStatus: "Active" | "Inactive";
  entryBy: string;
  entryDate: string;
  modifyBy: string;
  modifyDate: string;
}

// Advanced Rich Text Editor Component with Visual and Code Mode
function RichTextEditor({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  const [isCodeMode, setIsCodeMode] = useState(false);
  const [showColorPalette, setShowColorPalette] = useState(false);
  const [showBgColorPalette, setShowBgColorPalette] = useState(false);
  const [showFontSizeDropdown, setShowFontSizeDropdown] = useState(false);
  const editorRef = useRef<HTMLDivElement>(null);
  const colorPaletteRef = useRef<HTMLDivElement>(null);
  const bgColorPaletteRef = useRef<HTMLDivElement>(null);
  const fontSizeRef = useRef<HTMLDivElement>(null);

  const colorPalette = [
    '#000000', '#434343', '#666666', '#999999', '#B7B7B7', '#CCCCCC', '#D9D9D9', '#EFEFEF', '#F3F3F3', '#FFFFFF',
    '#980000', '#FF0000', '#FF9900', '#FFFF00', '#00FF00', '#00FFFF', '#4A86E8', '#0000FF', '#9900FF', '#FF00FF',
    '#E6B8AF', '#F4CCCC', '#FCE5CD', '#FFF2CC', '#D9EAD3', '#D0E0E3', '#C9DAF8', '#CFE2F3', '#D9D2E9', '#EAD1DC',
    '#DD7E6B', '#EA9999', '#F9CB9C', '#FFE599', '#B6D7A8', '#A2C4C9', '#A4C2F4', '#9FC5E8', '#B4A7D6', '#D5A6BD',
    '#CC4125', '#E06666', '#F6B26B', '#FFD966', '#93C47D', '#76A5AF', '#6D9EEB', '#6FA8DC', '#8E7CC3', '#C27BA0',
    '#A61C00', '#CC0000', '#E69138', '#F1C232', '#6AA84F', '#45818E', '#3C78D8', '#3D85C6', '#674EA7', '#A64D79',
    '#85200C', '#990000', '#B45F06', '#BF9000', '#38761D', '#134F5C', '#1155CC', '#0B5394', '#351C75', '#741B47',
    '#5B0F00', '#660000', '#783F04', '#7F6000', '#274E13', '#0C343D', '#1C4587', '#073763', '#20124D', '#4C1130'
  ];

  const fontSizes = [
    { label: '8', value: '8px' },
    { label: '9', value: '9px' },
    { label: '10', value: '10px' },
    { label: '11', value: '11px' },
    { label: '12', value: '12px' },
    { label: '14', value: '14px' },
    { label: '16', value: '16px' },
    { label: '18', value: '18px' },
    { label: '20', value: '20px' },
    { label: '22', value: '22px' },
    { label: '24', value: '24px' },
    { label: '26', value: '26px' },
    { label: '28', value: '28px' },
    { label: '36', value: '36px' },
    { label: '48', value: '48px' },
    { label: '72', value: '72px' },
  ];

  useEffect(() => {
    if (!isCodeMode && editorRef.current && editorRef.current.innerHTML !== value) {
      editorRef.current.innerHTML = value;
    }
  }, [value, isCodeMode]);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (colorPaletteRef.current && !colorPaletteRef.current.contains(event.target as Node)) {
        setShowColorPalette(false);
      }
      if (bgColorPaletteRef.current && !bgColorPaletteRef.current.contains(event.target as Node)) {
        setShowBgColorPalette(false);
      }
      if (fontSizeRef.current && !fontSizeRef.current.contains(event.target as Node)) {
        setShowFontSizeDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleVisualEditorChange = () => {
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const execCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    handleVisualEditorChange();
  };

  const insertHTML = (html: string) => {
    document.execCommand('insertHTML', false, html);
    handleVisualEditorChange();
  };

  const changeTextColor = (color: string) => {
    execCommand('foreColor', color);
    setShowColorPalette(false);
  };

  const changeBackgroundColor = (color: string) => {
    execCommand('backColor', color);
    setShowBgColorPalette(false);
  };

  const changeFontSize = (size: string) => {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const span = document.createElement('span');
      span.style.fontSize = size;
      range.surroundContents(span);
      handleVisualEditorChange();
    }
    setShowFontSizeDropdown(false);
  };

  const insertLink = () => {
    const url = prompt('Enter URL:');
    if (url) {
      execCommand('createLink', url);
    }
  };

  const insertTable = () => {
    const rows = prompt('Enter number of rows:', '2');
    const cols = prompt('Enter number of columns:', '2');
    if (rows && cols) {
      let tableHTML = '<table border="1" style="border-collapse: collapse; width: 100%;">';
      for (let i = 0; i < parseInt(rows); i++) {
        tableHTML += '<tr>';
        for (let j = 0; j < parseInt(cols); j++) {
          tableHTML += '<td style="padding: 8px; border: 1px solid #ddd;">Cell</td>';
        }
        tableHTML += '</tr>';
      }
      tableHTML += '</table>';
      insertHTML(tableHTML);
    }
  };

  return (
    <div className="border border-gray-300 rounded-lg overflow-hidden">
      {/* Toolbar */}
      <div className="bg-gray-50 border-b border-gray-300 px-3 py-2">
        <div className="flex items-center gap-1 flex-wrap mb-2">
          {/* Text Formatting */}
          {!isCodeMode && (
            <>
              <button
                type="button"
                onClick={() => execCommand('bold')}
                className="p-2 hover:bg-gray-200 rounded transition-colors"
                title="Bold (Ctrl+B)"
              >
                <Bold className="w-4 h-4 text-gray-700" />
              </button>
              <button
                type="button"
                onClick={() => execCommand('italic')}
                className="p-2 hover:bg-gray-200 rounded transition-colors"
                title="Italic (Ctrl+I)"
              >
                <Italic className="w-4 h-4 text-gray-700" />
              </button>
              <button
                type="button"
                onClick={() => execCommand('underline')}
                className="p-2 hover:bg-gray-200 rounded transition-colors"
                title="Underline (Ctrl+U)"
              >
                <span className="text-sm underline">U</span>
              </button>
              <button
                type="button"
                onClick={() => execCommand('strikeThrough')}
                className="p-2 hover:bg-gray-200 rounded transition-colors"
                title="Strikethrough"
              >
                <span className="text-sm line-through">S</span>
              </button>

              <div className="w-px h-6 bg-gray-300 mx-1" />

              {/* Font Size Dropdown */}
              <div className="relative" ref={fontSizeRef}>
                <button
                  type="button"
                  onClick={() => setShowFontSizeDropdown(!showFontSizeDropdown)}
                  className="px-3 py-1 hover:bg-gray-200 rounded transition-colors text-xs flex items-center gap-1 border border-gray-300"
                  title="Font Size"
                >
                  <span>Size</span>
                  <ChevronDown className="w-3 h-3" />
                </button>
                {showFontSizeDropdown && (
                  <div className="absolute top-full left-0 mt-1 bg-white border border-gray-300 rounded-lg shadow-lg z-50 w-24 max-h-64 overflow-y-auto">
                    {fontSizes.map((size) => (
                      <button
                        key={size.value}
                        type="button"
                        onClick={() => changeFontSize(size.value)}
                        className="w-full px-3 py-1.5 text-left text-sm hover:bg-blue-50 transition-colors"
                        style={{ fontSize: size.value }}
                      >
                        {size.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Text Color Palette */}
              <div className="relative" ref={colorPaletteRef}>
                <button
                  type="button"
                  onClick={() => setShowColorPalette(!showColorPalette)}
                  className="p-2 hover:bg-gray-200 rounded transition-colors relative"
                  title="Text Color"
                >
                  <span className="text-sm font-bold">A</span>
                  <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-1 bg-red-500"></div>
                </button>
                {showColorPalette && (
                  <div className="absolute top-full left-0 mt-1 bg-white border border-gray-300 rounded-lg shadow-lg z-50 p-2">
                    <div className="grid grid-cols-10 gap-1 w-64">
                      {colorPalette.map((color) => (
                        <button
                          key={color}
                          type="button"
                          onClick={() => changeTextColor(color)}
                          className="w-6 h-6 rounded border border-gray-300 hover:scale-110 transition-transform"
                          style={{ backgroundColor: color }}
                          title={color}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Background Color Palette */}
              <div className="relative" ref={bgColorPaletteRef}>
                <button
                  type="button"
                  onClick={() => setShowBgColorPalette(!showBgColorPalette)}
                  className="p-2 hover:bg-gray-200 rounded transition-colors"
                  title="Background Color"
                >
                  <span className="text-sm bg-yellow-200 px-1 font-bold">A</span>
                </button>
                {showBgColorPalette && (
                  <div className="absolute top-full left-0 mt-1 bg-white border border-gray-300 rounded-lg shadow-lg z-50 p-2">
                    <div className="grid grid-cols-10 gap-1 w-64">
                      {colorPalette.map((color) => (
                        <button
                          key={color}
                          type="button"
                          onClick={() => changeBackgroundColor(color)}
                          className="w-6 h-6 rounded border border-gray-300 hover:scale-110 transition-transform"
                          style={{ backgroundColor: color }}
                          title={color}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="w-px h-6 bg-gray-300 mx-1" />

              {/* Alignment */}
              <button
                type="button"
                onClick={() => execCommand('justifyLeft')}
                className="p-2 hover:bg-gray-200 rounded transition-colors"
                title="Align Left"
              >
                <AlignLeft className="w-4 h-4 text-gray-700" />
              </button>
              <button
                type="button"
                onClick={() => execCommand('justifyCenter')}
                className="p-2 hover:bg-gray-200 rounded transition-colors"
                title="Align Center"
              >
                <AlignCenter className="w-4 h-4 text-gray-700" />
              </button>
              <button
                type="button"
                onClick={() => execCommand('justifyRight')}
                className="p-2 hover:bg-gray-200 rounded transition-colors"
                title="Align Right"
              >
                <AlignRight className="w-4 h-4 text-gray-700" />
              </button>

              <div className="w-px h-6 bg-gray-300 mx-1" />

              {/* Lists */}
              <button
                type="button"
                onClick={() => execCommand('insertUnorderedList')}
                className="p-2 hover:bg-gray-200 rounded transition-colors"
                title="Bullet List"
              >
                <List className="w-4 h-4 text-gray-700" />
              </button>
              <button
                type="button"
                onClick={() => execCommand('insertOrderedList')}
                className="p-2 hover:bg-gray-200 rounded transition-colors"
                title="Numbered List"
              >
                <span className="text-sm">1.</span>
              </button>

              <div className="w-px h-6 bg-gray-300 mx-1" />

              {/* Link */}
              <button
                type="button"
                onClick={insertLink}
                className="p-2 hover:bg-gray-200 rounded transition-colors"
                title="Insert Link"
              >
                <Link className="w-4 h-4 text-gray-700" />
              </button>

              {/* Table */}
              <button
                type="button"
                onClick={insertTable}
                className="px-3 py-1 hover:bg-gray-200 rounded transition-colors text-xs"
                title="Insert Table"
              >
                Table
              </button>
            </>
          )}

          {/* Code/Visual Mode Toggle */}
          <div className="ml-auto flex items-center gap-1">
            <button
              type="button"
              onClick={() => setIsCodeMode(!isCodeMode)}
              className={`px-3 py-1 rounded transition-colors text-xs flex items-center gap-1 ${
                isCodeMode ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'
              }`}
            >
              <Code className="w-3 h-3" />
              <span>{isCodeMode ? 'Code' : 'Visual'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Editor Area */}
      {isCodeMode ? (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full h-64 p-3 font-mono text-sm resize-none focus:outline-none"
          placeholder="Enter HTML code..."
        />
      ) : (
        <div
          ref={editorRef}
          contentEditable
          onInput={handleVisualEditorChange}
          className="w-full h-64 p-3 focus:outline-none overflow-y-auto"
          style={{ minHeight: '16rem' }}
          suppressContentEditableWarning
        />
      )}
    </div>
  );
}

export function MailSmsConfigurations() {
  const [activeSection, setActiveSection] = useState<string>("Mail Configuration");
  
  // Configuration Settings
  const [mailMethod, setMailMethod] = useState<"smtp" | "api">("smtp");
  const [smsMethod, setSmsMethod] = useState<"api">("api");
  
  // Mock API Services loaded from API Configurations
  const [availableMailApis] = useState([
    { id: "sendgrid-api", name: "SendGrid Mail API", endpoint: "https://api.sendgrid.com/v3/mail/send" },
    { id: "mailgun-api", name: "Mailgun API", endpoint: "https://api.mailgun.net/v3/" },
    { id: "ses-api", name: "Amazon SES API", endpoint: "https://email.us-east-1.amazonaws.com/" },
  ]);

  const [availableSmsApis] = useState([
    { id: "twilio-api", name: "Twilio SMS API", endpoint: "https://api.twilio.com/2010-04-01/Accounts/" },
    { id: "nexmo-api", name: "Nexmo API", endpoint: "https://rest.nexmo.com/sms/json" },
    { id: "msg91-api", name: "MSG91 API", endpoint: "https://api.msg91.com/api/v5/flow/" },
  ]);

  // SMTP Configuration State
  const [smtpConfig, setSmtpConfig] = useState({
    host: "smtp.gmail.com",
    port: "587",
    username: "notifications@enach.com",
    password: "••••••••",
    encryption: "TLS",
    fromEmail: "notifications@enach.com",
    fromName: "eNACH System"
  });

  // Mail API Configuration State
  const [selectedMailApi, setSelectedMailApi] = useState(availableMailApis[0].id);

  // SMS API Configuration State
  const [selectedSmsApi, setSelectedSmsApi] = useState(availableSmsApis[0].id);

  // Unified Template State - Each template has both mail and SMS configurations
  const [templates, setTemplates] = useState<Template[]>([
    {
      id: 1,
      templateName: "Registration Successful",
      eventName: "Registration Successful",
      mailContent: "<p>Dear <strong>{customer_name}</strong>,</p><p>Your registration has been completed successfully.</p><p>Thank you for choosing our services.</p>",
      mailStatus: "Active",
      smsContent: "Dear {customer_name}, your registration is successful. Thank you!",
      smsStatus: "Active",
      entryBy: "Akash Gupta",
      entryDate: "2024-11-15",
      modifyBy: "Akash Gupta",
      modifyDate: "2024-11-20"
    },
    {
      id: 2,
      templateName: "Mandate Approval",
      eventName: "Mandate Approval",
      mailContent: "<p>Dear <strong>{customer_name}</strong>,</p><p>Your mandate has been approved.</p>",
      mailStatus: "Active",
      smsContent: "Dear {customer_name}, your mandate has been approved.",
      smsStatus: "Active",
      entryBy: "Akash Gupta",
      entryDate: "2024-11-16",
      modifyBy: "System",
      modifyDate: "2024-11-18"
    }
  ]);

  const [showTemplateForm, setShowTemplateForm] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<Template | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const [templateFormData, setTemplateFormData] = useState({
    templateName: "",
    mailContent: "",
    mailStatus: "Active" as "Active" | "Inactive",
    smsContent: "",
    smsStatus: "Active" as "Active" | "Inactive"
  });

  const handleSaveSmtpConfig = () => {
    toast.success("SMTP configuration saved successfully");
  };

  const handleTestSmtpConnection = () => {
    toast.success("Test email sent successfully");
  };

  const handleSaveMailApiConfig = () => {
    toast.success("Mail API configuration saved successfully");
  };

  const handleTestMailApi = () => {
    const selectedApi = availableMailApis.find(api => api.id === selectedMailApi);
    toast.success(`Testing ${selectedApi?.name}...`);
  };

  const handleSaveSmsApiConfig = () => {
    toast.success("SMS API configuration saved successfully");
  };

  const handleTestSmsApi = () => {
    const selectedApi = availableSmsApis.find(api => api.id === selectedSmsApi);
    toast.success(`Testing ${selectedApi?.name}...`);
  };

  const handleAddTemplate = () => {
    setEditingTemplate(null);
    setTemplateFormData({
      templateName: "",
      mailContent: "",
      mailStatus: "Active",
      smsContent: "",
      smsStatus: "Active"
    });
    setShowTemplateForm(true);
  };

  const handleEditTemplate = (template: Template) => {
    setEditingTemplate(template);
    setTemplateFormData({
      templateName: template.templateName,
      mailContent: template.mailContent || "",
      mailStatus: template.mailStatus || "Active",
      smsContent: template.smsContent || "",
      smsStatus: template.smsStatus || "Active"
    });
    setShowTemplateForm(true);
  };

  const handleSaveTemplate = () => {
    if (!templateFormData.templateName.trim()) {
      toast.error("Template name is required");
      return;
    }

    if (editingTemplate) {
      // Update existing template
      setTemplates(templates.map(t =>
        t.id === editingTemplate.id
          ? {
              ...t,
              templateName: templateFormData.templateName,
              eventName: templateFormData.templateName,
              mailContent: templateFormData.mailContent,
              mailStatus: templateFormData.mailStatus,
              smsContent: templateFormData.smsContent,
              smsStatus: templateFormData.smsStatus,
              modifyBy: "Akash Gupta",
              modifyDate: new Date().toISOString().split('T')[0]
            }
          : t
      ));
      toast.success("Template updated successfully");
    } else {
      // Add new template
      const newTemplate: Template = {
        id: Math.max(...templates.map(t => t.id), 0) + 1,
        templateName: templateFormData.templateName,
        eventName: templateFormData.templateName,
        mailContent: templateFormData.mailContent,
        mailStatus: templateFormData.mailStatus,
        smsContent: templateFormData.smsContent,
        smsStatus: templateFormData.smsStatus,
        entryBy: "Akash Gupta",
        entryDate: new Date().toISOString().split('T')[0],
        modifyBy: "Akash Gupta",
        modifyDate: new Date().toISOString().split('T')[0]
      };
      setTemplates([...templates, newTemplate]);
      toast.success("Template added successfully");
    }
    setShowTemplateForm(false);
  };

  const handleDeleteTemplate = (id: number) => {
    if (confirm("Are you sure you want to delete this template?")) {
      setTemplates(templates.filter(t => t.id !== id));
      toast.success("Template deleted successfully");
    }
  };

  const filteredTemplates = templates.filter(template =>
    template.templateName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
              <Mail className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-gray-800">Mail and SMS Configurations</h2>
              <p className="text-xs text-gray-600">Manage email and SMS settings, APIs, and templates</p>
            </div>
          </div>
        </div>
      </div>

      {/* Section Tabs */}
      <div className="bg-white border-b border-gray-200 px-6">
        <div className="flex gap-4">
          {["Mail Configuration", "SMS API Configuration", "Templates"].map((section) => (
            <button
              key={section}
              onClick={() => setActiveSection(section)}
              className={`px-4 py-3 text-sm border-b-2 transition-colors whitespace-nowrap ${
                activeSection === section
                  ? "border-purple-600 text-purple-600"
                  : "border-transparent text-gray-600 hover:text-gray-800"
              }`}
            >
              {section}
            </button>
          ))}
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-auto p-6">
        {/* Settings */}
        {activeSection === "Mail Configuration" && (
          <div className="max-w-3xl mx-auto space-y-6">
            {/* Mail Method Selection */}
            <div className="bg-white rounded-lg border border-gray-200 p-6 space-y-6">
              <div className="flex items-center gap-3 pb-4 border-b border-gray-200">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Settings className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <h3 className="text-gray-800">Communication Settings</h3>
                  <p className="text-xs text-gray-600">Configure how emails and SMS will be sent</p>
                </div>
              </div>

              {/* Mail Method Selection */}
              <div>
                <label className="block text-sm text-gray-700 mb-3">
                  Email Sending Method <span className="text-red-500">*</span>
                </label>
                <div className="space-y-3">
                  <label className={`flex items-start gap-3 p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                    mailMethod === "smtp" ? "border-purple-500 bg-purple-50" : "border-gray-200 hover:border-purple-300"
                  }`}>
                    <input
                      type="radio"
                      name="mailMethod"
                      value="smtp"
                      checked={mailMethod === "smtp"}
                      onChange={(e) => setMailMethod(e.target.value as "smtp" | "api")}
                      className="mt-1 w-4 h-4 text-purple-600 border-gray-300 focus:ring-purple-500"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Server className="w-4 h-4 text-blue-600" />
                        <span className="text-gray-800">SMTP Configuration</span>
                      </div>
                      <p className="text-xs text-gray-600">Use traditional SMTP server for sending emails (Gmail, Outlook, etc.)</p>
                    </div>
                  </label>

                  <label className={`flex items-start gap-3 p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                    mailMethod === "api" ? "border-purple-500 bg-purple-50" : "border-gray-200 hover:border-purple-300"
                  }`}>
                    <input
                      type="radio"
                      name="mailMethod"
                      value="api"
                      checked={mailMethod === "api"}
                      onChange={(e) => setMailMethod(e.target.value as "smtp" | "api")}
                      className="mt-1 w-4 h-4 text-purple-600 border-gray-300 focus:ring-purple-500"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Key className="w-4 h-4 text-green-600" />
                        <span className="text-gray-800">Mail API Configuration</span>
                      </div>
                      <p className="text-xs text-gray-600">Use third-party API services like SendGrid, Mailgun, Amazon SES</p>
                    </div>
                  </label>
                </div>
              </div>

              {/* Current Active Method Info */}
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="text-sm text-blue-900 mb-2 flex items-center gap-2">
                  <Info className="w-4 h-4" />
                  Active Configuration
                </h4>
                <p className="text-xs text-gray-700">
                  {mailMethod === "smtp" 
                    ? "Currently using SMTP Configuration. Configure your SMTP server settings below."
                    : "Currently using Mail API. Configure your mail API settings below."}
                </p>
              </div>

              {/* Save Settings */}
              <div className="flex items-center justify-end pt-4 border-t border-gray-200">
                <button
                  onClick={() => toast.success("Settings saved successfully")}
                  className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all shadow-lg shadow-purple-200"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Settings</span>
                </button>
              </div>
            </div>

            {/* Conditional SMTP Configuration Display */}
            {mailMethod === "smtp" && (
              <div className="bg-white rounded-lg border border-gray-200 p-6 space-y-6">
                <div className="flex items-center gap-3 pb-4 border-b border-gray-200">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Server className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-gray-800">SMTP Server Configuration</h3>
                    <p className="text-xs text-gray-600">Configure SMTP server for sending emails</p>
                  </div>
                </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-sm text-gray-700 mb-2">SMTP Host</label>
                  <input
                    type="text"
                    value={smtpConfig.host}
                    onChange={(e) => setSmtpConfig({ ...smtpConfig, host: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">Port</label>
                  <input
                    type="text"
                    value={smtpConfig.port}
                    onChange={(e) => setSmtpConfig({ ...smtpConfig, port: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">Encryption</label>
                  <select
                    value={smtpConfig.encryption}
                    onChange={(e) => setSmtpConfig({ ...smtpConfig, encryption: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    <option>TLS</option>
                    <option>SSL</option>
                    <option>None</option>
                  </select>
                </div>

                <div className="col-span-2">
                  <label className="block text-sm text-gray-700 mb-2">Username</label>
                  <input
                    type="text"
                    value={smtpConfig.username}
                    onChange={(e) => setSmtpConfig({ ...smtpConfig, username: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-sm text-gray-700 mb-2">Password</label>
                  <input
                    type="password"
                    value={smtpConfig.password}
                    onChange={(e) => setSmtpConfig({ ...smtpConfig, password: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">From Email</label>
                  <input
                    type="email"
                    value={smtpConfig.fromEmail}
                    onChange={(e) => setSmtpConfig({ ...smtpConfig, fromEmail: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">From Name</label>
                  <input
                    type="text"
                    value={smtpConfig.fromName}
                    onChange={(e) => setSmtpConfig({ ...smtpConfig, fromName: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
                <button
                  onClick={handleTestSmtpConnection}
                  className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <Send className="w-4 h-4" />
                  <span>Test Connection</span>
                </button>
                <button
                  onClick={handleSaveSmtpConfig}
                  className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all shadow-lg shadow-purple-200"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Configuration</span>
                </button>
              </div>
            </div>
            )}

            {/* Conditional Mail API Configuration Display */}
            {mailMethod === "api" && (
              <div className="bg-white rounded-lg border border-gray-200 p-6 space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-gray-200">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <Key className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <h3 className="text-gray-800">Mail API Configuration</h3>
                      <p className="text-xs text-gray-600">Select and configure mail API from API Configurations</p>
                    </div>
                  </div>
                  <button
                    onClick={() => toast.info("Opening API Configurations...")}
                    className="flex items-center gap-2 px-3 py-1.5 text-xs border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <ExternalLink className="w-3 h-3" />
                    <span>Manage APIs</span>
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">Select Mail API</label>
                    <select
                      value={selectedMailApi}
                      onChange={(e) => setSelectedMailApi(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    >
                      {availableMailApis.map(api => (
                        <option key={api.id} value={api.id}>{api.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Display selected API details */}
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="text-sm text-blue-900 mb-2 flex items-center gap-2">
                      <Info className="w-4 h-4" />
                      API Details
                    </h4>
                    <div className="space-y-2 text-xs text-gray-700">
                      <div>
                        <span className="font-medium">API Name:</span> {availableMailApis.find(a => a.id === selectedMailApi)?.name}
                      </div>
                      <div>
                        <span className="font-medium">Endpoint:</span> {availableMailApis.find(a => a.id === selectedMailApi)?.endpoint}
                      </div>
                      <div className="text-gray-600 mt-2">
                        All API configurations including authentication, headers, and payloads are managed in the API Configurations menu.
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
                  <button
                    onClick={handleTestMailApi}
                    className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <Send className="w-4 h-4" />
                    <span>Test API</span>
                  </button>
                  <button
                    onClick={handleSaveMailApiConfig}
                    className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all shadow-lg shadow-purple-200"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save Configuration</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* SMS API Configuration */}
        {activeSection === "SMS API Configuration" && (
          <div className="max-w-3xl mx-auto">
            <div className="bg-white rounded-lg border border-gray-200 p-6 space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                    <MessageSquare className="w-5 h-5 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="text-gray-800">SMS API Configuration</h3>
                    <p className="text-xs text-gray-600">Select and configure SMS API from API Configurations</p>
                  </div>
                </div>
                <button
                  onClick={() => toast.info("Opening API Configurations...")}
                  className="flex items-center gap-2 px-3 py-1.5 text-xs border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <ExternalLink className="w-3 h-3" />
                  <span>Manage APIs</span>
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">Select SMS API</label>
                  <select
                    value={selectedSmsApi}
                    onChange={(e) => setSelectedSmsApi(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    {availableSmsApis.map(api => (
                      <option key={api.id} value={api.id}>{api.name}</option>
                    ))}
                  </select>
                </div>

                {/* Display selected API details */}
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <h4 className="text-sm text-blue-900 mb-2 flex items-center gap-2">
                    <Info className="w-4 h-4" />
                    API Details
                  </h4>
                  <div className="space-y-2 text-xs text-gray-700">
                    <div>
                      <span className="font-medium">API Name:</span> {availableSmsApis.find(a => a.id === selectedSmsApi)?.name}
                    </div>
                    <div>
                      <span className="font-medium">Endpoint:</span> {availableSmsApis.find(a => a.id === selectedSmsApi)?.endpoint}
                    </div>
                    <div className="text-gray-600 mt-2">
                      All API configurations including authentication, headers, and payloads are managed in the API Configurations menu.
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
                <button
                  onClick={handleTestSmsApi}
                  className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <Send className="w-4 h-4" />
                  <span>Test SMS</span>
                </button>
                <button
                  onClick={handleSaveSmsApiConfig}
                  className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all shadow-lg shadow-purple-200"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Configuration</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Templates Section (Unified Mail & SMS) */}
        {activeSection === "Templates" && (
          <div className="space-y-4">
            {/* Search and Add Button */}
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <div className="flex items-center justify-between gap-4">
                <div className="flex-1 relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search templates..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                  />
                </div>
                
                <button
                  onClick={handleAddTemplate}
                  className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all shadow-lg shadow-purple-200"
                >
                  <Plus className="w-4 h-4" />
                  <span className="text-sm">Add Template</span>
                </button>
              </div>
            </div>

            {/* Templates Grid */}
            <div className="grid gap-4">
              {filteredTemplates.map((template) => (
                <div key={template.id} className="bg-white rounded-lg border border-gray-200 p-5 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-gray-800">{template.templateName}</h3>
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1">
                            <Mail className="w-3 h-3 text-purple-600" />
                            <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                              template.mailStatus === "Active"
                                ? "bg-green-100 text-green-700"
                                : "bg-gray-100 text-gray-700"
                            }`}>
                              {template.mailStatus}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MessageSquare className="w-3 h-3 text-orange-600" />
                            <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                              template.smsStatus === "Active"
                                ? "bg-green-100 text-green-700"
                                : "bg-gray-100 text-gray-700"
                            }`}>
                              {template.smsStatus}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="text-xs text-gray-600 space-y-1">
                        <p>Created by <span className="text-gray-800">{template.entryBy}</span> on {template.entryDate}</p>
                        <p>Modified by <span className="text-gray-800">{template.modifyBy}</span> on {template.modifyDate}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleEditTemplate(template)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Edit"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteTemplate(template.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                      <div className="flex items-center gap-2 mb-2">
                        <Mail className="w-4 h-4 text-purple-600" />
                        <span className="text-xs text-purple-900">Mail Content</span>
                      </div>
                      <div className="text-xs text-gray-600 line-clamp-2" dangerouslySetInnerHTML={{ __html: template.mailContent || 'Not configured' }} />
                    </div>
                    <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                      <div className="flex items-center gap-2 mb-2">
                        <MessageSquare className="w-4 h-4 text-orange-600" />
                        <span className="text-xs text-orange-900">SMS Content</span>
                      </div>
                      <p className="text-xs text-gray-700 line-clamp-2">{template.smsContent || 'Not configured'}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Template Form Modal */}
      {showTemplateForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h3 className="text-gray-800">
                {editingTemplate ? "Edit Template" : "Add Template"}
              </h3>
              <button
                onClick={() => setShowTemplateForm(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* Template Name */}
              <div>
                <label className="block text-sm text-gray-700 mb-2">
                  Template Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={templateFormData.templateName}
                  onChange={(e) => setTemplateFormData({ ...templateFormData, templateName: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Enter template name (used for product mapping)"
                />
                <p className="text-xs text-gray-500 mt-1">This name will be used to map the template to products</p>
              </div>

              {/* Mail Configuration */}
              <div className="border border-purple-200 rounded-lg p-4 bg-purple-50">
                <div className="flex items-center gap-2 mb-4">
                  <Mail className="w-5 h-5 text-purple-600" />
                  <h4 className="text-purple-900">Mail Configuration</h4>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Mail Content
                    </label>
                    <RichTextEditor
                      value={templateFormData.mailContent}
                      onChange={(content) => setTemplateFormData({ ...templateFormData, mailContent: content })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-gray-700 mb-2">Mail Status</label>
                    <select
                      value={templateFormData.mailStatus}
                      onChange={(e) => setTemplateFormData({ ...templateFormData, mailStatus: e.target.value as "Active" | "Inactive" })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    >
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* SMS Configuration */}
              <div className="border border-orange-200 rounded-lg p-4 bg-orange-50">
                <div className="flex items-center gap-2 mb-4">
                  <MessageSquare className="w-5 h-5 text-orange-600" />
                  <h4 className="text-orange-900">SMS Configuration</h4>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      SMS Content
                    </label>
                    <textarea
                      value={templateFormData.smsContent}
                      onChange={(e) => setTemplateFormData({ ...templateFormData, smsContent: e.target.value })}
                      rows={4}
                      maxLength={160}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                      placeholder="Enter SMS content (max 160 characters)"
                    />
                    <div className="flex items-center justify-between mt-1">
                      <p className="text-xs text-gray-500">Maximum 160 characters</p>
                      <p className="text-xs text-gray-500">{templateFormData.smsContent.length}/160</p>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm text-gray-700 mb-2">SMS Status</label>
                    <select
                      value={templateFormData.smsStatus}
                      onChange={(e) => setTemplateFormData({ ...templateFormData, smsStatus: e.target.value as "Active" | "Inactive" })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    >
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Available Placeholders */}
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="text-sm text-blue-900 mb-2 flex items-center gap-2">
                  <Info className="w-4 h-4" />
                  Available Placeholders
                </h4>
                <div className="flex flex-wrap gap-2">
                  {['{customer_name}', '{bank_name}', '{account_number}', '{mandate_id}', '{amount}', '{date}'].map(placeholder => (
                    <button
                      key={placeholder}
                      onClick={() => {
                        navigator.clipboard.writeText(placeholder);
                        toast.success(`Copied ${placeholder}`);
                      }}
                      className="px-2 py-1 bg-white border border-blue-300 rounded text-xs text-blue-700 hover:bg-blue-100 transition-colors flex items-center gap-1"
                    >
                      {placeholder}
                      <Copy className="w-3 h-3" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
                <button
                  onClick={() => setShowTemplateForm(false)}
                  className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveTemplate}
                  className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all shadow-lg shadow-purple-200"
                >
                  <Save className="w-4 h-4" />
                  <span>{editingTemplate ? "Update" : "Save"}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}