import { useState } from "react";
import { Check, Shield } from "lucide-react";

interface LicenseScreenProps {
  registrationCode: string;
  onLicenseValidated: () => void;
}

export function LicenseScreen({ registrationCode, onLicenseValidated }: LicenseScreenProps) {
  const [licenseStatus, setLicenseStatus] = useState<"idle" | "requested" | "validated">("idle");
  const [isProcessing, setIsProcessing] = useState(false);
  const [manualLicenseKey, setManualLicenseKey] = useState<string>("");

  const handleGetLicense = () => {
    setIsProcessing(true);
    // Simulate API call
    setTimeout(() => {
      setLicenseStatus("requested");
      setIsProcessing(false);
    }, 1500);
  };

  const handleSubmitForValidation = () => {
    setIsProcessing(true);
    // Simulate API call
    setTimeout(() => {
      setLicenseStatus("validated");
      setIsProcessing(false);
      // Call parent callback after a short delay
      setTimeout(() => {
        onLicenseValidated();
      }, 1000);
    }, 2000);
  };

  const handleValidateLicense = () => {
    setIsProcessing(true);
    // Simulate API call
    setTimeout(() => {
      setLicenseStatus("validated");
      setIsProcessing(false);
      // Call parent callback after a short delay
      setTimeout(() => {
        onLicenseValidated();
      }, 1000);
    }, 2000);
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-gray-800 mb-1 text-lg">License Activation</h2>
        <p className="text-xs text-gray-600">
          Activate your eNACH license to complete the process
        </p>
      </div>

      {/* Registration Request Code */}
      <div>
        <label className="block text-xs text-gray-700 mb-1.5">
          Registration Request Code <span className="text-red-500">*</span>
        </label>
        <div className="relative">
          <input
            type="text"
            value={registrationCode}
            readOnly
            className="w-full px-3 py-2.5 pr-10 border border-gray-300 rounded-lg bg-gray-50 text-gray-700 text-sm"
          />
        </div>
        <p className="text-xs text-gray-500 mt-1.5">
          Use this Registration Request Code to generate license from CRM panel
        </p>
      </div>

      {/* Automatic License Section */}
      <div className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-200 space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
            <Shield className="w-4 h-4 text-white" />
          </div>
          <h3 className="text-gray-800 text-sm">Automatic License Retrieval</h3>
        </div>
        
        {licenseStatus === "idle" && (
          <button
            onClick={handleGetLicense}
            disabled={isProcessing}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm disabled:opacity-50 shadow-lg shadow-blue-200"
          >
            {isProcessing ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Processing...</span>
              </>
            ) : (
              <>
                <Check className="w-4 h-4" />
                <span>Get License</span>
              </>
            )}
          </button>
        )}

        {licenseStatus === "requested" && (
          <div className="space-y-3">
            <div className="p-3 bg-green-100 border border-green-300 rounded-lg">
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-600" />
                <p className="text-xs text-green-800">
                  License request sent successfully! Click below to validate.
                </p>
              </div>
            </div>
            <button
              onClick={handleSubmitForValidation}
              disabled={isProcessing}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors text-sm disabled:opacity-50 shadow-lg shadow-green-200"
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Validating...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Submit for Online Validation</span>
                </>
              )}
            </button>
          </div>
        )}

        {licenseStatus === "validated" && (
          <div className="p-3 bg-green-100 border border-green-300 rounded-lg">
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-600" />
              <p className="text-xs text-green-800">
                License validated successfully! Completing process...
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Divider */}
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-gray-300"></div>
        </div>
        <div className="relative flex justify-center text-xs">
          <span className="px-3 bg-white text-gray-500">OR</span>
        </div>
      </div>

      {/* Manual License Section */}
      <div className="p-4 bg-gradient-to-br from-orange-50 to-amber-50 rounded-xl border border-orange-200 space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
            <Shield className="w-4 h-4 text-white" />
          </div>
          <h3 className="text-gray-800 text-sm">Manual License Validation</h3>
        </div>
        <div>
          <label className="block text-xs text-gray-700 mb-1.5">
            Enter License Key <span className="text-red-500">*</span>
          </label>
          <textarea
            value={manualLicenseKey}
            onChange={(e) => setManualLicenseKey(e.target.value)}
            placeholder="Paste your license key here from CRM panel..."
            rows={4}
            disabled={licenseStatus === "validated"}
            className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-100 resize-none text-xs"
          />
        </div>
        <button
          onClick={handleValidateLicense}
          disabled={isProcessing || licenseStatus === "validated" || !manualLicenseKey.trim()}
          className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-orange-600 hover:bg-orange-700 text-white rounded-lg transition-colors text-sm disabled:opacity-50 shadow-lg shadow-orange-200"
        >
          {isProcessing ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              <span>Validating...</span>
            </>
          ) : (
            <>
              <Check className="w-4 h-4" />
              <span>Validate License</span>
            </>
          )}
        </button>
      </div>

      {/* Instructions */}
      <div className="p-4 bg-gray-50 rounded-xl border border-gray-200">
        <h3 className="text-xs text-gray-800 mb-2 flex items-center gap-2">
          <div className="w-5 h-5 bg-gray-600 rounded-full flex items-center justify-center text-white text-xs">
            i
          </div>
          Instructions:
        </h3>
        <ol className="text-xs text-gray-600 space-y-1.5 list-decimal list-inside">
          <li>Copy the Registration Request Code displayed above</li>
          <li>For automatic license, click "Get License" to raise a request</li>
          <li>Once approved from CRM panel, click "Submit for Online Validation"</li>
          <li>Alternatively, access your CRM panel at <span className="text-blue-600">https://crm.soft-techsolutions.com</span></li>
          <li>Generate a license key using the Registration Request Code</li>
          <li>Paste the generated license key in the manual validation field</li>
          <li>Click "Validate License" to complete activation</li>
        </ol>
      </div>
    </div>
  );
}
