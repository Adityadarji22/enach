import { useState } from "react";
import { 
  Search,
  Plus,
  Edit,
  Trash2,
  Upload,
  Download,
  X,
  ChevronLeft,
  ChevronRight,
  Building2
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface Branch {
  id: number;
  branchCode: string;
  branchName: string;
  branchIFSC: string;
  contactNo: string;
  emailId: string;
  entryBy: string;
  entryDate: string;
  modifyBy: string;
  modifyDate: string;
}

export function BranchMaster() {
  const [branches, setBranches] = useState<Branch[]>([
    {
      id: 1,
      branchCode: "0000",
      branchName: "Head Office",
      branchIFSC: "ABCD0000001",
      contactNo: "9999999999",
      emailId: "headoffice@sft.com",
      entryBy: "Akash Gupta",
      entryDate: "2024-11-15",
      modifyBy: "Akash Gupta",
      modifyDate: "2024-11-20"
    }
  ]);

  const [searchTerm, setSearchTerm] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [editingBranch, setEditingBranch] = useState<Branch | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const [formData, setFormData] = useState({
    branchCode: "",
    branchName: "",
    branchIFSC: "",
    contactNo: "",
    emailId: ""
  });

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const filteredBranches = branches.filter(branch =>
    branch.branchCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
    branch.branchName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    branch.branchIFSC.toLowerCase().includes(searchTerm.toLowerCase()) ||
    branch.contactNo.includes(searchTerm) ||
    branch.emailId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalPages = Math.ceil(filteredBranches.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentBranches = filteredBranches.slice(startIndex, endIndex);

  const handleAddBranch = () => {
    setEditingBranch(null);
    setFormData({
      branchCode: "",
      branchName: "",
      branchIFSC: "",
      contactNo: "",
      emailId: ""
    });
    setShowAddModal(true);
  };

  const handleEditBranch = (branch: Branch) => {
    setEditingBranch(branch);
    setFormData({
      branchCode: branch.branchCode,
      branchName: branch.branchName,
      branchIFSC: branch.branchIFSC,
      contactNo: branch.contactNo,
      emailId: branch.emailId
    });
    setShowAddModal(true);
  };

  const handleDeleteBranch = (id: number) => {
    if (confirm("Are you sure you want to delete this branch?")) {
      setBranches(branches.filter(b => b.id !== id));
      toast.success("Branch deleted successfully");
    }
  };

  const handleSubmit = () => {
    // Validation
    if (!formData.branchCode.trim()) {
      toast.error("Branch Code is required");
      return;
    }
    if (!formData.branchName.trim()) {
      toast.error("Branch Name is required");
      return;
    }
    if (!formData.branchIFSC.trim()) {
      toast.error("Branch IFSC is required");
      return;
    }
    if (!formData.contactNo.trim()) {
      toast.error("Contact No. is required");
      return;
    }
    if (!formData.emailId.trim()) {
      toast.error("Email Id is required");
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.emailId)) {
      toast.error("Please enter a valid email address");
      return;
    }

    // Phone validation
    const phoneRegex = /^[0-9]{10}$/;
    if (!phoneRegex.test(formData.contactNo)) {
      toast.error("Please enter a valid 10-digit contact number");
      return;
    }

    if (editingBranch) {
      // Update existing branch
      setBranches(branches.map(b =>
        b.id === editingBranch.id
          ? {
              ...b,
              ...formData,
              modifyBy: "Akash Gupta",
              modifyDate: new Date().toISOString().split('T')[0]
            }
          : b
      ));
      toast.success("Branch updated successfully");
    } else {
      // Add new branch
      const newBranch: Branch = {
        id: Math.max(...branches.map(b => b.id), 0) + 1,
        ...formData,
        entryBy: "Akash Gupta",
        entryDate: new Date().toISOString().split('T')[0],
        modifyBy: "Akash Gupta",
        modifyDate: new Date().toISOString().split('T')[0]
      };
      setBranches([...branches, newBranch]);
      toast.success("Branch added successfully");
    }

    setShowAddModal(false);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleImportSubmit = () => {
    if (!selectedFile) {
      toast.error("Please select a file to import");
      return;
    }

    // Mock import process
    toast.success(`Importing branches from ${selectedFile.name}...`);
    setShowImportModal(false);
    setSelectedFile(null);
  };

  const handleDownloadSample = () => {
    toast.success("Downloading sample file...");
    // In a real application, this would download a CSV/Excel template
  };

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-lg flex items-center justify-center">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs text-gray-600 mb-1">
                <span>Master</span>
                <span>/</span>
                <span className="text-blue-600">Branch</span>
              </div>
              <h2 className="text-gray-800">Branch Master</h2>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowImportModal(true)}
              className="flex items-center gap-2 px-4 py-2 border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
            >
              <Upload className="w-4 h-4" />
              <span className="text-sm">Import Branch</span>
            </button>
            <button
              onClick={handleAddBranch}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span className="text-sm">Add Branch</span>
            </button>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-white border-b border-gray-200 px-6 py-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
          />
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto p-6">
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-100 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Branch Code</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Branch Name</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Contact Details</th>
                <th className="px-6 py-3 text-left text-xs text-gray-600">Branch IFSC Code</th>
                <th className="px-6 py-3 text-center text-xs text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {currentBranches.map((branch) => (
                <tr key={branch.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm text-gray-800">{branch.branchCode}</td>
                  <td className="px-6 py-4 text-sm text-gray-800">{branch.branchName}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    <div className="space-y-0.5">
                      <div>{branch.contactNo}</div>
                      <div className="text-xs">{branch.emailId}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-800">{branch.branchIFSC}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        onClick={() => handleEditBranch(branch)}
                        className="p-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                        title="Edit"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteBranch(branch.id)}
                        className="p-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      <div className="bg-white border-t border-gray-200 px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <select
              value={itemsPerPage}
              onChange={(e) => {
                setItemsPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="px-3 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
            <span className="text-sm text-gray-600">
              Showing {startIndex + 1} to {Math.min(endIndex, filteredBranches.length)} of {filteredBranches.length} entries
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
              className="px-3 py-1 border border-gray-300 rounded text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
            >
              Previous
            </button>
            <button
              className="px-3 py-1 bg-blue-600 text-white rounded text-sm"
            >
              {currentPage}
            </button>
            <button
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
              className="px-3 py-1 border border-gray-300 rounded text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {/* Add/Edit Branch Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
            <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h3 className="text-gray-800">{editingBranch ? "Edit" : "Add"} Branch</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Branch Code<span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.branchCode}
                    onChange={(e) => setFormData({ ...formData, branchCode: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    placeholder="Enter branch code"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Branch Name<span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.branchName}
                    onChange={(e) => setFormData({ ...formData, branchName: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    placeholder="Enter branch name"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Branch IFSC<span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.branchIFSC}
                    onChange={(e) => setFormData({ ...formData, branchIFSC: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    placeholder="Enter IFSC code"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Contact No.<span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.contactNo}
                    onChange={(e) => setFormData({ ...formData, contactNo: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    placeholder="Enter contact number"
                    maxLength={10}
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-sm text-gray-700 mb-2">
                    Email Id<span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    value={formData.emailId}
                    onChange={(e) => setFormData({ ...formData, emailId: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    placeholder="Enter email address"
                  />
                </div>
              </div>
            </div>

            <div className="border-t border-gray-200 px-6 py-4 flex justify-end">
              <button
                onClick={handleSubmit}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Import Branch Modal */}
      {showImportModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
            <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h3 className="text-gray-800">Import Branch</h3>
              <button
                onClick={() => {
                  setShowImportModal(false);
                  setSelectedFile(null);
                }}
                className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm text-gray-700 mb-2">Browse:</label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <input
                    type="file"
                    id="fileUpload"
                    accept=".csv,.xlsx,.xls"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                  <label
                    htmlFor="fileUpload"
                    className="cursor-pointer"
                  >
                    <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-600">
                      {selectedFile ? selectedFile.name : "No file selected"}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">Click to select file</p>
                  </label>
                </div>
              </div>

              <div className="text-center">
                <button
                  onClick={handleDownloadSample}
                  className="text-sm text-blue-600 hover:underline flex items-center gap-1 mx-auto"
                >
                  <Download className="w-4 h-4" />
                  <span>Download sample file</span>
                </button>
              </div>
            </div>

            <div className="border-t border-gray-200 px-6 py-4 flex justify-end">
              <button
                onClick={handleImportSubmit}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
