import { useState } from "react";
import {
  Plus,
  Eye,
  EyeOff,
  Edit,
  X,
  Upload,
  Shield,
  CheckCircle,
  AlertCircle,
  FileKey,
  Lock,
} from "lucide-react";

interface Certificate {
  id: string;
  name: string;
  description: string;
  type: "Public Key" | "Private Key";
  fileName: string;
  password?: string;
  issuedTo: string;
  issuedBy: string;
  validFrom: string;
  validTill: string;
  serialNumber: string;
}

interface FormData {
  name: string;
  description: string;
  type: "Public Key" | "Private Key";
  certificateFile: File | null;
  publicCertFile: File | null;
  password: string;
}

interface CertificateModalProps {
  isEdit: boolean;
  formData: FormData;
  setFormData: React.Dispatch<React.SetStateAction<FormData>>;
  isChecked: boolean;
  setIsChecked: React.Dispatch<React.SetStateAction<boolean>>;
  checkStatus: "success" | "error" | null;
  setCheckStatus: React.Dispatch<React.SetStateAction<"success" | "error" | null>>;
  checkMessage: string;
  setCheckMessage: React.Dispatch<React.SetStateAction<string>>;
  showPassword: boolean;
  setShowPassword: React.Dispatch<React.SetStateAction<boolean>>;
  onClose: () => void;
  onSave: () => void;
  onCheckNow: () => void;
}

function CertificateModal({
  isEdit,
  formData,
  setFormData,
  isChecked,
  checkStatus,
  setCheckStatus,
  checkMessage,
  showPassword,
  setShowPassword,
  onClose,
  onSave,
  onCheckNow,
}: CertificateModalProps) {
  const handleFileUpload = (type: "certificate" | "publicCert", e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const expectedExtension = type === "certificate" 
        ? (formData.type === "Public Key" ? ".cer" : ".pfx")
        : ".cer";
      
      const fileExtension = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
      
      if (fileExtension !== expectedExtension) {
        alert(`Please upload a ${expectedExtension} file`);
        e.target.value = "";
        return;
      }

      if (type === "certificate") {
        setFormData(prev => ({ ...prev, certificateFile: file }));
      } else {
        setFormData(prev => ({ ...prev, publicCertFile: file }));
      }
      setCheckStatus(null);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg">{isEdit ? "Edit Certificate" : "Add New Certificate"}</h2>
              <p className="text-xs text-blue-100">Configure certificate settings</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Certificate Name */}
          <div>
            <label className="block text-sm text-gray-700 mb-2">
              Certificate Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              placeholder="Enter certificate name"
            />
          </div>

          {/* Certificate Description */}
          <div>
            <label className="block text-sm text-gray-700 mb-2">
              Certificate Description <span className="text-red-500">*</span>
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none"
              rows={3}
              placeholder="Enter certificate description"
            />
          </div>

          {/* Certificate Type */}
          <div>
            <label className="block text-sm text-gray-700 mb-2">
              Certificate Type <span className="text-red-500">*</span>
            </label>
            <select
              value={formData.type}
              onChange={(e) => {
                setFormData(prev => ({ 
                  ...prev, 
                  type: e.target.value as "Public Key" | "Private Key",
                  certificateFile: null,
                  publicCertFile: null,
                  password: "",
                }));
                setCheckStatus(null);
              }}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            >
              <option value="Public Key">Public Key (.cer)</option>
              <option value="Private Key">Private Key (.pfx)</option>
            </select>
          </div>

          {/* Upload Certificate */}
          <div>
            <label className="block text-sm text-gray-700 mb-2">
              Upload Certificate <span className="text-red-500">*</span>
            </label>
            <div className="border-2 border-dashed border-blue-300 rounded-lg p-4 bg-blue-50/50 hover:border-blue-400 transition-colors">
              {!formData.certificateFile ? (
                <label className="cursor-pointer flex flex-col items-center justify-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-2">
                    <Upload className="w-6 h-6 text-blue-600" />
                  </div>
                  <span className="text-sm text-gray-700 mb-1">
                    Click to upload {formData.type === "Public Key" ? ".cer" : ".pfx"} file
                  </span>
                  <span className="text-xs text-gray-500">Maximum file size: 5MB</span>
                  <input
                    type="file"
                    accept={formData.type === "Public Key" ? ".cer" : ".pfx"}
                    onChange={(e) => handleFileUpload("certificate", e)}
                    className="hidden"
                  />
                </label>
              ) : (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <FileKey className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-800">{formData.certificateFile.name}</div>
                      <div className="text-xs text-gray-500">
                        {(formData.certificateFile.size / 1024).toFixed(2)} KB
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, certificateFile: null }))}
                    className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Private Key Additional Fields */}
          {formData.type === "Private Key" && (
            <>
              {/* Password */}
              <div>
                <label className="block text-sm text-gray-700 mb-2">
                  Private Key Password <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type={showPassword ? "text" : "password"}
                    value={formData.password}
                    onChange={(e) => {
                      setFormData(prev => ({ ...prev, password: e.target.value }));
                      setCheckStatus(null);
                    }}
                    className="w-full pl-10 pr-12 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    placeholder="Enter private key password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    {showPassword ? (
                      <EyeOff className="w-5 h-5" />
                    ) : (
                      <Eye className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Upload Public Certificate */}
              <div>
                <label className="block text-sm text-gray-700 mb-2">
                  Upload Public Certificate <span className="text-red-500">*</span>
                </label>
                <div className="border-2 border-dashed border-purple-300 rounded-lg p-4 bg-purple-50/50 hover:border-purple-400 transition-colors">
                  {!formData.publicCertFile ? (
                    <label className="cursor-pointer flex flex-col items-center justify-center">
                      <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-2">
                        <Upload className="w-6 h-6 text-purple-600" />
                      </div>
                      <span className="text-sm text-gray-700 mb-1">Click to upload .cer file</span>
                      <span className="text-xs text-gray-500">Public certificate pair</span>
                      <input
                        type="file"
                        accept=".cer"
                        onChange={(e) => handleFileUpload("publicCert", e)}
                        className="hidden"
                      />
                    </label>
                  ) : (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                          <FileKey className="w-5 h-5 text-green-600" />
                        </div>
                        <div>
                          <div className="text-sm text-gray-800">{formData.publicCertFile.name}</div>
                          <div className="text-xs text-gray-500">
                            {(formData.publicCertFile.size / 1024).toFixed(2)} KB
                          </div>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, publicCertFile: null }))}
                        className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Check Status */}
              {checkStatus && (
                <div
                  className={`p-4 rounded-lg border ${
                    checkStatus === "success"
                      ? "bg-green-50 border-green-200"
                      : "bg-red-50 border-red-200"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {checkStatus === "success" ? (
                      <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1">
                      <div
                        className={`text-sm ${
                          checkStatus === "success" ? "text-green-800" : "text-red-800"
                        }`}
                      >
                        {checkMessage}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer Actions */}
        <div className="sticky bottom-0 bg-gray-50 px-6 py-4 border-t border-gray-200 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-6 py-2 text-gray-700 hover:bg-gray-200 rounded-lg transition-colors"
          >
            Cancel
          </button>
          
          {formData.type === "Private Key" && (
            <button
              onClick={onCheckNow}
              disabled={!formData.certificateFile || !formData.password || !formData.publicCertFile}
              className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
            >
              <Shield className="w-4 h-4" />
              Check Now
            </button>
          )}
          
          <button
            onClick={onSave}
            disabled={
              !formData.name ||
              !formData.description ||
              !formData.certificateFile ||
              (formData.type === "Private Key" && !isChecked)
            }
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
          >
            <CheckCircle className="w-4 h-4" />
            Save Certificate
          </button>
        </div>
      </div>
    </div>
  );
}

function ViewModal({ certificate, onClose }: { certificate: Certificate; onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl">
        <div className="bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-4 flex items-center justify-between rounded-t-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg">Certificate Details</h2>
              <p className="text-xs text-green-100">View certificate information</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Certificate Name */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg border border-blue-200">
            <div className="text-xs text-gray-600 mb-1">Certificate Name</div>
            <div className="text-gray-900">{certificate.name}</div>
          </div>

          {/* Certificate Type Badge */}
          <div className="flex items-center gap-2">
            <span className={`px-3 py-1 rounded-full text-xs ${
              certificate.type === "Private Key"
                ? "bg-purple-100 text-purple-700"
                : "bg-blue-100 text-blue-700"
            }`}>
              {certificate.type}
            </span>
          </div>

          {/* Certificate Information */}
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <div className="bg-gray-50 px-4 py-2 border-b border-gray-200">
              <div className="flex items-center gap-2">
                <FileKey className="w-4 h-4 text-gray-600" />
                <span className="text-sm text-gray-700">Certificate Information</span>
              </div>
            </div>

            <div className="divide-y divide-gray-200">
              <div className="px-4 py-3 grid grid-cols-3 gap-4">
                <div className="text-xs text-gray-600">Issued to:</div>
                <div className="col-span-2 text-sm text-gray-900">{certificate.issuedTo}</div>
              </div>
              <div className="px-4 py-3 grid grid-cols-3 gap-4">
                <div className="text-xs text-gray-600">Issued By:</div>
                <div className="col-span-2 text-sm text-gray-900">{certificate.issuedBy}</div>
              </div>
              <div className="px-4 py-3 grid grid-cols-3 gap-4">
                <div className="text-xs text-gray-600">Validity From:</div>
                <div className="col-span-2 text-sm text-gray-900">{certificate.validFrom}</div>
              </div>
              <div className="px-4 py-3 grid grid-cols-3 gap-4">
                <div className="text-xs text-gray-600">Valid Till:</div>
                <div className="col-span-2 text-sm text-gray-900">{certificate.validTill}</div>
              </div>
              <div className="px-4 py-3 grid grid-cols-3 gap-4">
                <div className="text-xs text-gray-600">Serial Number:</div>
                <div className="col-span-2 text-sm text-gray-900 font-mono">{certificate.serialNumber}</div>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="text-xs text-gray-600 mb-2">Description</div>
            <div className="text-sm text-gray-900">{certificate.description}</div>
          </div>
        </div>

        <div className="bg-gray-50 px-6 py-4 border-t border-gray-200 flex justify-end rounded-b-lg">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

export function CertificateConfigurations() {
  const [certificates, setCertificates] = useState<Certificate[]>([
    {
      id: "1",
      name: "eNACH Production Certificate",
      description: "Production certificate for eNACH services",
      type: "Private Key",
      fileName: "enach_prod.pfx",
      password: "SecurePass@123",
      issuedTo: "KETAN NAVINCHANDRA ICHCHHAPORIA",
      issuedBy: "e-Mudhra Sub CA for Class 3 Individual 2022",
      validFrom: "01-10-2025",
      validTill: "01-10-2027",
      serialNumber: "01908645",
    },
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedCertificate, setSelectedCertificate] = useState<Certificate | null>(null);

  const [formData, setFormData] = useState<FormData>({
    name: "",
    description: "",
    type: "Public Key",
    certificateFile: null,
    publicCertFile: null,
    password: "",
  });

  const [isChecked, setIsChecked] = useState(false);
  const [checkStatus, setCheckStatus] = useState<"success" | "error" | null>(null);
  const [checkMessage, setCheckMessage] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      type: "Public Key",
      certificateFile: null,
      publicCertFile: null,
      password: "",
    });
    setIsChecked(false);
    setCheckStatus(null);
    setCheckMessage("");
    setShowPassword(false);
  };

  const handleCheckNow = () => {
    // Simulate validation
    if (formData.type === "Private Key") {
      if (!formData.password) {
        setCheckStatus("error");
        setCheckMessage("Please enter the private key password");
        return;
      }
      if (!formData.publicCertFile) {
        setCheckStatus("error");
        setCheckMessage("Please upload the public certificate");
        return;
      }
    }

    // Simulate successful validation
    setTimeout(() => {
      setCheckStatus("success");
      setCheckMessage("Password verified successfully! Key pair matched.");
      setIsChecked(true);
    }, 1000);
  };

  const handleSave = () => {
    if (formData.type === "Private Key" && !isChecked) {
      alert("Please click 'Check Now' to validate the certificate before saving");
      return;
    }

    const newCertificate: Certificate = {
      id: Date.now().toString(),
      name: formData.name,
      description: formData.description,
      type: formData.type,
      fileName: formData.certificateFile?.name || "",
      password: formData.type === "Private Key" ? formData.password : undefined,
      issuedTo: "DEMO USER",
      issuedBy: "Demo Certificate Authority",
      validFrom: new Date().toLocaleDateString("en-GB"),
      validTill: new Date(Date.now() + 365 * 2 * 24 * 60 * 60 * 1000).toLocaleDateString("en-GB"),
      serialNumber: Math.floor(Math.random() * 10000000).toString(),
    };

    if (showEditModal && selectedCertificate) {
      setCertificates(certificates.map(cert => 
        cert.id === selectedCertificate.id ? { ...newCertificate, id: selectedCertificate.id } : cert
      ));
      setShowEditModal(false);
    } else {
      setCertificates([...certificates, newCertificate]);
      setShowAddModal(false);
    }

    resetForm();
  };

  const handleEdit = (cert: Certificate) => {
    setSelectedCertificate(cert);
    setFormData({
      name: cert.name,
      description: cert.description,
      type: cert.type,
      certificateFile: null,
      publicCertFile: null,
      password: cert.password || "",
    });
    setIsChecked(false);
    setCheckStatus(null);
    setCheckMessage("");
    setShowPassword(false);
    setShowEditModal(true);
  };

  const handleView = (cert: Certificate) => {
    setSelectedCertificate(cert);
    setShowViewModal(true);
  };

  const handleCloseModal = () => {
    if (showAddModal) setShowAddModal(false);
    if (showEditModal) setShowEditModal(false);
    resetForm();
  };

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-gray-900 text-xl">Certificate Configurations</h1>
            <p className="text-sm text-gray-600 mt-1">
              Manage public and private key certificates
            </p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Certificate
          </button>
        </div>
      </div>

      {/* Certificates List */}
      <div className="flex-1 overflow-auto p-6">
        <div className="grid gap-4">
          {certificates.map((cert) => (
            <div
              key={cert.id}
              className="bg-white rounded-lg border border-gray-200 hover:border-blue-300 transition-colors"
            >
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                        <Shield className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-gray-900">{cert.name}</h3>
                        <span
                          className={`inline-block px-2 py-1 rounded text-xs mt-1 ${
                            cert.type === "Private Key"
                              ? "bg-purple-100 text-purple-700"
                              : "bg-blue-100 text-blue-700"
                          }`}
                        >
                          {cert.type}
                        </span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mt-3">{cert.description}</p>
                    <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
                      <span>Valid: {cert.validFrom} to {cert.validTill}</span>
                      <span>•</span>
                      <span>Serial: {cert.serialNumber}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 ml-4">
                    <button
                      onClick={() => handleView(cert)}
                      className="px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors flex items-center gap-2 border border-blue-200"
                    >
                      <Eye className="w-4 h-4" />
                      View
                    </button>
                    <button
                      onClick={() => handleEdit(cert)}
                      className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors flex items-center gap-2 border border-gray-200"
                    >
                      <Edit className="w-4 h-4" />
                      Edit
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {certificates.length === 0 && (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-gray-900 mb-2">No Certificates Found</h3>
              <p className="text-sm text-gray-600 mb-4">
                Get started by adding your first certificate
              </p>
              <button
                onClick={() => setShowAddModal(true)}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Add Certificate
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      {(showAddModal || showEditModal) && (
        <CertificateModal
          isEdit={showEditModal}
          formData={formData}
          setFormData={setFormData}
          isChecked={isChecked}
          setIsChecked={setIsChecked}
          checkStatus={checkStatus}
          setCheckStatus={setCheckStatus}
          checkMessage={checkMessage}
          setCheckMessage={setCheckMessage}
          showPassword={showPassword}
          setShowPassword={setShowPassword}
          onClose={handleCloseModal}
          onSave={handleSave}
          onCheckNow={handleCheckNow}
        />
      )}
      {showViewModal && selectedCertificate && (
        <ViewModal certificate={selectedCertificate} onClose={() => setShowViewModal(false)} />
      )}
    </div>
  );
}
