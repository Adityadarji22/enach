import { useState } from "react";
import { Settings, Save, Check } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface ProductConfigurationsProps {
  onBack: () => void;
}

export function ProductConfigurations({ onBack }: ProductConfigurationsProps) {
  const [activeTab, setActiveTab] = useState<'api-mandate' | 'itr' | 'base'>('api-mandate');

  // API Mandate Configuration State
  const [apiMandateConfig, setApiMandateConfig] = useState({
    contextPath: '',
    apiPort: '',
    netBankingPort: '',
    sslCertificate: '',
    bankSigningCert: '',
    npciSigningCert: '',
    netbankingVendorCert: '',
    accountValidationAPI: '',
    mandateInsertAPI: '',
    switchVendorAPI: '',
    netbankingURL: '',
    npciURL: 'UAT',
    mandateVerifyOTPTemplate: '',
    dailyMandateMailAlertsTemplate: '',
    successMandateAlertsTemplate: '',
    licenceExpiryAlertsTemplate: '',
    sslExpiryAlertsTemplate: '',
    class3CertExpiryAlertsTemplate: '',
    exceptionAlertsTemplate: '',
    insertMandateOn: 'Success',
    encryptMandateInsertData: false,
    encodeMandateInsertData: false,
    mandateExceedAmountLimit: '',
    minorAgeLimit: '',
    otpAttemptLimit: '3',
    otpExpiryTime: '5',
    otpTimeInterval: '',
    mandateInsertTimeInterval: '',
    mandateInsertAttempts: '3'
  });

  // ITR Configuration State
  const [itrConfig, setItrConfig] = useState({
    contextPath: '',
    apiPort: '',
    sslCertificate: '',
    bankSigningCert: '',
    bankEncryptionCert: '',
    npciSigningCert: '',
    npciEncryptionCert: '',
    accountValidationAPI: '',
    npciURL: 'UAT'
  });

  // BASE Configuration State
  const [baseConfig, setBaseConfig] = useState({
    contextPath: '',
    apiPort: '',
    sslCertificate: '',
    bankSigningCert: '',
    bankEncryptionCert: '',
    npciSigningCert: '',
    npciEncryptionCert: '',
    accountValidationAPI: '',
    npciURL: 'UAT'
  });

  // Mock data for dropdowns (these would come from the actual configurations)
  const privateCertificates = [
    { id: '1', name: 'SSL Certificate - Bank Server (expires 2026-01-15)', hasPassword: true },
    { id: '2', name: 'Bank Signing Certificate - Production (expires 2025-12-31)', hasPassword: true },
    { id: '3', name: 'Vendor Encryption Key - NetBanking (expires 2026-03-20)', hasPassword: true }
  ];

  const publicCertificates = [
    { id: '1', name: 'NPCI Public Key - Signing (expires 2026-06-30)' },
    { id: '2', name: 'NPCI Public Key - Encryption (expires 2026-06-30)' }
  ];

  const apiServices = [
    { id: '1', name: 'Account Validation Service - v1' },
    { id: '2', name: 'Mandate Insert Service - v2' },
    { id: '3', name: 'Switch Vendor Service - v1' },
    { id: '4', name: 'NetBanking Gateway - v3' }
  ];

  const templates = [
    { id: '1', name: 'Mandate OTP Verification' },
    { id: '2', name: 'Daily Mandate Summary' },
    { id: '3', name: 'Mandate Success Notification' },
    { id: '4', name: 'License Expiry Warning' },
    { id: '5', name: 'SSL Certificate Expiry Alert' },
    { id: '6', name: 'Class-3 Certificate Expiry Alert' },
    { id: '7', name: 'System Exception Alert' }
  ];

  const handleSaveApiMandateConfig = () => {
    // Validation
    if (!apiMandateConfig.contextPath || !apiMandateConfig.apiPort) {
      toast.error('Please fill in all required fields');
      return;
    }

    // Save logic here
    toast.success('API Mandate Configurations saved successfully');
  };

  const handleUpdateApiMandateField = (field: string, value: any) => {
    setApiMandateConfig(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveItrConfig = () => {
    // Validation
    if (!itrConfig.contextPath || !itrConfig.apiPort) {
      toast.error('Please fill in all required fields');
      return;
    }

    // Save logic here
    toast.success('ITR Configurations saved successfully');
  };

  const handleUpdateItrField = (field: string, value: any) => {
    setItrConfig(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveBaseConfig = () => {
    // Validation
    if (!baseConfig.contextPath || !baseConfig.apiPort) {
      toast.error('Please fill in all required fields');
      return;
    }

    // Save logic here
    toast.success('BASE Configurations saved successfully');
  };

  const handleUpdateBaseField = (field: string, value: any) => {
    setBaseConfig(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Settings className="w-6 h-6 text-blue-600" />
            <div>
              <h1 className="text-xl text-gray-900">Product Configurations</h1>
              <p className="text-sm text-gray-600">Configure product-specific settings and parameters</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b border-gray-200 px-6">
        <div className="flex gap-1">
          <button
            onClick={() => setActiveTab('api-mandate')}
            className={`px-6 py-3 text-sm transition-colors relative ${
              activeTab === 'api-mandate'
                ? 'text-blue-600'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            API Mandate Configurations
            {activeTab === 'api-mandate' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('itr')}
            className={`px-6 py-3 text-sm transition-colors relative ${
              activeTab === 'itr'
                ? 'text-blue-600'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            ITR Configurations
            {activeTab === 'itr' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('base')}
            className={`px-6 py-3 text-sm transition-colors relative ${
              activeTab === 'base'
                ? 'text-blue-600'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            BASE Configurations
            {activeTab === 'base' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600" />
            )}
          </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto px-6 py-6">
        {activeTab === 'api-mandate' && (
          <div className="max-w-5xl mx-auto space-y-6">
            {/* Basic Configuration */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">Basic Configuration</h2>
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Context-path <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={apiMandateConfig.contextPath}
                    onChange={(e) => handleUpdateApiMandateField('contextPath', e.target.value)}
                    placeholder="/api/v1/mandate"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <p className="text-xs text-gray-500 mt-1">Application endpoint deployment path</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    API Port <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={apiMandateConfig.apiPort}
                    onChange={(e) => handleUpdateApiMandateField('apiPort', e.target.value)}
                    placeholder="8080"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <p className="text-xs text-gray-500 mt-1">Port on which API is running</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Net Banking Port <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={apiMandateConfig.netBankingPort}
                    onChange={(e) => handleUpdateApiMandateField('netBankingPort', e.target.value)}
                    placeholder="8443"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <p className="text-xs text-gray-500 mt-1">Port on which NetBanking is running</p>
                </div>
              </div>
            </div>

            {/* Certificate Mapping */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">Certificate Mapping</h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    SSL Certificate (Private Key) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={apiMandateConfig.sslCertificate}
                    onChange={(e) => handleUpdateApiMandateField('sslCertificate', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select SSL Certificate</option>
                    {privateCertificates.map(cert => (
                      <option key={cert.id} value={cert.id}>{cert.name}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Private Key + Public Key + Password</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Bank Signing and Encryption Certificate (Private Key) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={apiMandateConfig.bankSigningCert}
                    onChange={(e) => handleUpdateApiMandateField('bankSigningCert', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select Bank Certificate</option>
                    {privateCertificates.map(cert => (
                      <option key={cert.id} value={cert.id}>{cert.name}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Private Key + Public Key + Password</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    NPCI Signing and Encryption Certificate (Public Key) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={apiMandateConfig.npciSigningCert}
                    onChange={(e) => handleUpdateApiMandateField('npciSigningCert', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select NPCI Certificate</option>
                    {publicCertificates.map(cert => (
                      <option key={cert.id} value={cert.id}>{cert.name}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Public Key only</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Netbanking Vendor Encryption Certificate (Private Key) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={apiMandateConfig.netbankingVendorCert}
                    onChange={(e) => handleUpdateApiMandateField('netbankingVendorCert', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select Vendor Certificate</option>
                    {privateCertificates.map(cert => (
                      <option key={cert.id} value={cert.id}>{cert.name}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Private Key pair</p>
                </div>
              </div>
            </div>

            {/* API Service Mapping */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">API Service Mapping</h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Account Validation API <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={apiMandateConfig.accountValidationAPI}
                    onChange={(e) => handleUpdateApiMandateField('accountValidationAPI', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select API Service</option>
                    {apiServices.map(api => (
                      <option key={api.id} value={api.id}>{api.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Mandate Insert API <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={apiMandateConfig.mandateInsertAPI}
                    onChange={(e) => handleUpdateApiMandateField('mandateInsertAPI', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select API Service</option>
                    {apiServices.map(api => (
                      <option key={api.id} value={api.id}>{api.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Switch Vendor API <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={apiMandateConfig.switchVendorAPI}
                    onChange={(e) => handleUpdateApiMandateField('switchVendorAPI', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select API Service</option>
                    {apiServices.map(api => (
                      <option key={api.id} value={api.id}>{api.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Netbanking URL <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={apiMandateConfig.netbankingURL}
                    onChange={(e) => handleUpdateApiMandateField('netbankingURL', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select API Service</option>
                    {apiServices.map(api => (
                      <option key={api.id} value={api.id}>{api.name}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* NPCI Configuration */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">NPCI Configuration</h2>
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    NPCI URLs <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={apiMandateConfig.npciURL}
                    onChange={(e) => handleUpdateApiMandateField('npciURL', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="UAT">UAT</option>
                    <option value="PRODUCTION">PRODUCTION</option>
                    <option value="CUSTOM">CUSTOM</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Alert Templates */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">Alert Templates</h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Mandate Verify OTP Template
                  </label>
                  <select
                    value={apiMandateConfig.mandateVerifyOTPTemplate}
                    onChange={(e) => handleUpdateApiMandateField('mandateVerifyOTPTemplate', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select Template</option>
                    {templates.map(template => (
                      <option key={template.id} value={template.id}>{template.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Daily Mandate Mail Alerts Template
                  </label>
                  <select
                    value={apiMandateConfig.dailyMandateMailAlertsTemplate}
                    onChange={(e) => handleUpdateApiMandateField('dailyMandateMailAlertsTemplate', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select Template</option>
                    {templates.map(template => (
                      <option key={template.id} value={template.id}>{template.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Success Mandate MAIL & SMS Alerts Template
                  </label>
                  <select
                    value={apiMandateConfig.successMandateAlertsTemplate}
                    onChange={(e) => handleUpdateApiMandateField('successMandateAlertsTemplate', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select Template</option>
                    {templates.map(template => (
                      <option key={template.id} value={template.id}>{template.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Licence Expiry Alerts Template
                  </label>
                  <select
                    value={apiMandateConfig.licenceExpiryAlertsTemplate}
                    onChange={(e) => handleUpdateApiMandateField('licenceExpiryAlertsTemplate', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select Template</option>
                    {templates.map(template => (
                      <option key={template.id} value={template.id}>{template.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    SSL Expiry Alerts Template
                  </label>
                  <select
                    value={apiMandateConfig.sslExpiryAlertsTemplate}
                    onChange={(e) => handleUpdateApiMandateField('sslExpiryAlertsTemplate', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select Template</option>
                    {templates.map(template => (
                      <option key={template.id} value={template.id}>{template.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Class-3 Certificates Expiry Alerts Template
                  </label>
                  <select
                    value={apiMandateConfig.class3CertExpiryAlertsTemplate}
                    onChange={(e) => handleUpdateApiMandateField('class3CertExpiryAlertsTemplate', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select Template</option>
                    {templates.map(template => (
                      <option key={template.id} value={template.id}>{template.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Exception Alerts Template
                  </label>
                  <select
                    value={apiMandateConfig.exceptionAlertsTemplate}
                    onChange={(e) => handleUpdateApiMandateField('exceptionAlertsTemplate', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select Template</option>
                    {templates.map(template => (
                      <option key={template.id} value={template.id}>{template.name}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Mandate Insert Configuration */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">Mandate Insert Configuration</h2>
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Insert Mandate On <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={apiMandateConfig.insertMandateOn}
                    onChange={(e) => handleUpdateApiMandateField('insertMandateOn', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="Success">Success</option>
                    <option value="Both">Both</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Encrypt Mandate Insert Data
                  </label>
                  <button
                    type="button"
                    onClick={() => handleUpdateApiMandateField('encryptMandateInsertData', !apiMandateConfig.encryptMandateInsertData)}
                    className={`relative inline-flex h-8 w-14 items-center rounded-full transition-colors ${
                      apiMandateConfig.encryptMandateInsertData ? 'bg-blue-600' : 'bg-gray-300'
                    }`}
                  >
                    <span
                      className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${
                        apiMandateConfig.encryptMandateInsertData ? 'translate-x-7' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Encode Mandate Insert Data
                  </label>
                  <button
                    type="button"
                    onClick={() => handleUpdateApiMandateField('encodeMandateInsertData', !apiMandateConfig.encodeMandateInsertData)}
                    className={`relative inline-flex h-8 w-14 items-center rounded-full transition-colors ${
                      apiMandateConfig.encodeMandateInsertData ? 'bg-blue-600' : 'bg-gray-300'
                    }`}
                  >
                    <span
                      className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${
                        apiMandateConfig.encodeMandateInsertData ? 'translate-x-7' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>

            {/* Business Rules */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">Business Rules</h2>
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Mandate Exceed Amount Limit <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={apiMandateConfig.mandateExceedAmountLimit}
                    onChange={(e) => handleUpdateApiMandateField('mandateExceedAmountLimit', e.target.value)}
                    placeholder="10000"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Minor Age Limit <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={apiMandateConfig.minorAgeLimit}
                    onChange={(e) => handleUpdateApiMandateField('minorAgeLimit', e.target.value)}
                    placeholder="18"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            {/* OTP Configuration */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">OTP Configuration</h2>
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    OTP Attempt Limit <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={apiMandateConfig.otpAttemptLimit}
                    onChange={(e) => handleUpdateApiMandateField('otpAttemptLimit', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    OTP Expiry Time (minutes) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={apiMandateConfig.otpExpiryTime}
                    onChange={(e) => handleUpdateApiMandateField('otpExpiryTime', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    OTP Time Interval (seconds) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={apiMandateConfig.otpTimeInterval}
                    onChange={(e) => handleUpdateApiMandateField('otpTimeInterval', e.target.value)}
                    placeholder="30"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            {/* Mandate Processing Configuration */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">Mandate Processing Configuration</h2>
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Mandate Insert Time Interval (seconds) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={apiMandateConfig.mandateInsertTimeInterval}
                    onChange={(e) => handleUpdateApiMandateField('mandateInsertTimeInterval', e.target.value)}
                    placeholder="60"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Mandate Insert Attempts <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={apiMandateConfig.mandateInsertAttempts}
                    onChange={(e) => handleUpdateApiMandateField('mandateInsertAttempts', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end gap-3 pt-4">
              <button
                type="button"
                onClick={handleSaveApiMandateConfig}
                className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Save Configuration
              </button>
            </div>
          </div>
        )}

        {activeTab === 'itr' && (
          <div className="max-w-5xl mx-auto space-y-6">
            {/* Basic Configuration */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">Basic Configuration</h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Context-path <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={itrConfig.contextPath}
                    onChange={(e) => handleUpdateItrField('contextPath', e.target.value)}
                    placeholder="/api/v1/itr"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <p className="text-xs text-gray-500 mt-1">Application endpoint deployment path</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    API Port <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={itrConfig.apiPort}
                    onChange={(e) => handleUpdateItrField('apiPort', e.target.value)}
                    placeholder="8081"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <p className="text-xs text-gray-500 mt-1">Port on which API is running</p>
                </div>
              </div>
            </div>

            {/* Certificate Mapping */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">Certificate Mapping</h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    SSL Certificate (Private Key) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={itrConfig.sslCertificate}
                    onChange={(e) => handleUpdateItrField('sslCertificate', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select SSL Certificate</option>
                    {privateCertificates.map(cert => (
                      <option key={cert.id} value={cert.id}>{cert.name}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Private Key + Public Key + Password</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Bank Signing Certificate (Private Key) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={itrConfig.bankSigningCert}
                    onChange={(e) => handleUpdateItrField('bankSigningCert', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select Bank Signing Certificate</option>
                    {privateCertificates.map(cert => (
                      <option key={cert.id} value={cert.id}>{cert.name}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Private Key + Public Key + Password</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Bank Encryption Certificate (Private Key) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={itrConfig.bankEncryptionCert}
                    onChange={(e) => handleUpdateItrField('bankEncryptionCert', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select Bank Encryption Certificate</option>
                    {privateCertificates.map(cert => (
                      <option key={cert.id} value={cert.id}>{cert.name}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Private Key + Public Key + Password</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    NPCI Signing Certificate (Public Key) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={itrConfig.npciSigningCert}
                    onChange={(e) => handleUpdateItrField('npciSigningCert', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select NPCI Signing Certificate</option>
                    {publicCertificates.map(cert => (
                      <option key={cert.id} value={cert.id}>{cert.name}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Public Key only</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    NPCI Encryption Certificate (Public Key) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={itrConfig.npciEncryptionCert}
                    onChange={(e) => handleUpdateItrField('npciEncryptionCert', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select NPCI Encryption Certificate</option>
                    {publicCertificates.map(cert => (
                      <option key={cert.id} value={cert.id}>{cert.name}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Public Key only</p>
                </div>
              </div>
            </div>

            {/* API Service Mapping */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">API Service Mapping</h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Account Validation API <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={itrConfig.accountValidationAPI}
                    onChange={(e) => handleUpdateItrField('accountValidationAPI', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select API Service</option>
                    {apiServices.map(api => (
                      <option key={api.id} value={api.id}>{api.name}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* NPCI Configuration */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">NPCI Configuration</h2>
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    NPCI URLs <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={itrConfig.npciURL}
                    onChange={(e) => handleUpdateItrField('npciURL', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="UAT">UAT</option>
                    <option value="PRODUCTION">PRODUCTION</option>
                    <option value="CUSTOM">CUSTOM</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end gap-3 pt-4">
              <button
                type="button"
                onClick={handleSaveItrConfig}
                className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Save Configuration
              </button>
            </div>
          </div>
        )}

        {activeTab === 'base' && (
          <div className="max-w-5xl mx-auto space-y-6">
            {/* Basic Configuration */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">Basic Configuration</h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Context-path <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={baseConfig.contextPath}
                    onChange={(e) => handleUpdateBaseField('contextPath', e.target.value)}
                    placeholder="/api/v1/base"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <p className="text-xs text-gray-500 mt-1">Application endpoint deployment path</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    API Port <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={baseConfig.apiPort}
                    onChange={(e) => handleUpdateBaseField('apiPort', e.target.value)}
                    placeholder="8082"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <p className="text-xs text-gray-500 mt-1">Port on which API is running</p>
                </div>
              </div>
            </div>

            {/* Certificate Mapping */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">Certificate Mapping</h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    SSL Certificate (Private Key) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={baseConfig.sslCertificate}
                    onChange={(e) => handleUpdateBaseField('sslCertificate', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select SSL Certificate</option>
                    {privateCertificates.map(cert => (
                      <option key={cert.id} value={cert.id}>{cert.name}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Private Key + Public Key + Password</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Bank Signing Certificate (Private Key) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={baseConfig.bankSigningCert}
                    onChange={(e) => handleUpdateBaseField('bankSigningCert', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select Bank Signing Certificate</option>
                    {privateCertificates.map(cert => (
                      <option key={cert.id} value={cert.id}>{cert.name}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Private Key + Public Key + Password</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Bank Encryption Certificate (Private Key) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={baseConfig.bankEncryptionCert}
                    onChange={(e) => handleUpdateBaseField('bankEncryptionCert', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select Bank Encryption Certificate</option>
                    {privateCertificates.map(cert => (
                      <option key={cert.id} value={cert.id}>{cert.name}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Private Key + Public Key + Password</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    NPCI Signing Certificate (Public Key) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={baseConfig.npciSigningCert}
                    onChange={(e) => handleUpdateBaseField('npciSigningCert', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select NPCI Signing Certificate</option>
                    {publicCertificates.map(cert => (
                      <option key={cert.id} value={cert.id}>{cert.name}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Public Key only</p>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    NPCI Encryption Certificate (Public Key) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={baseConfig.npciEncryptionCert}
                    onChange={(e) => handleUpdateBaseField('npciEncryptionCert', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select NPCI Encryption Certificate</option>
                    {publicCertificates.map(cert => (
                      <option key={cert.id} value={cert.id}>{cert.name}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">Public Key only</p>
                </div>
              </div>
            </div>

            {/* API Service Mapping */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">API Service Mapping</h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Account Validation API <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={baseConfig.accountValidationAPI}
                    onChange={(e) => handleUpdateBaseField('accountValidationAPI', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="">Select API Service</option>
                    {apiServices.map(api => (
                      <option key={api.id} value={api.id}>{api.name}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* NPCI Configuration */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-base text-gray-900 mb-4">NPCI Configuration</h2>
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    NPCI URLs <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={baseConfig.npciURL}
                    onChange={(e) => handleUpdateBaseField('npciURL', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
                    style={{
                      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E\")",
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 12px center',
                      paddingRight: '32px'
                    }}
                  >
                    <option value="UAT">UAT</option>
                    <option value="PRODUCTION">PRODUCTION</option>
                    <option value="CUSTOM">CUSTOM</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end gap-3 pt-4">
              <button
                type="button"
                onClick={handleSaveBaseConfig}
                className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Save Configuration
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
