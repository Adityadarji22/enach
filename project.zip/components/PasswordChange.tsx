import { useState } from "react";
import { Lock, Eye, EyeOff, Check, X, AlertCircle, KeyRound, CheckCircle, ShieldCheck, Info } from "lucide-react";

interface PasswordChangeProps {
  onComplete: () => void;
}

export function PasswordChange({ onComplete }: PasswordChangeProps) {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isChanging, setIsChanging] = useState(false);
  const [error, setError] = useState("");

  const passwordStrength = (password: string): { strength: number; label: string; color: string } => {
    let strength = 0;
    if (password.length >= 8) strength++;
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
    if (/\d/.test(password)) strength++;
    if (/[^a-zA-Z\d]/.test(password)) strength++;

    if (strength <= 1) return { strength: 25, label: "Weak", color: "bg-red-500" };
    if (strength === 2) return { strength: 50, label: "Fair", color: "bg-yellow-500" };
    if (strength === 3) return { strength: 75, label: "Good", color: "bg-blue-500" };
    return { strength: 100, label: "Strong", color: "bg-green-500" };
  };

  const passwordRules = [
    { met: newPassword.length >= 8, text: "At least 8 characters" },
    { met: /\d/.test(newPassword), text: "At least one number" },
    { met: /[a-z]/.test(newPassword) && /[A-Z]/.test(newPassword), text: "Upper & lowercase letters" },
    { met: /[^a-zA-Z\d]/.test(newPassword), text: "At least one special character" },
  ];

  const handleChangePassword = () => {
    setError("");

    // Validation
    if (!currentPassword) {
      setError("Please enter your current password");
      return;
    }
    if (!newPassword) {
      setError("Please enter a new password");
      return;
    }
    if (newPassword.length < 8) {
      setError("New password must be at least 8 characters long");
      return;
    }
    if (newPassword !== confirmPassword) {
      setError("New passwords do not match");
      return;
    }
    if (currentPassword === newPassword) {
      setError("New password must be different from current password");
      return;
    }

    setIsChanging(true);

    // Simulate password change
    setTimeout(() => {
      // In real app, call API to change password
      alert("Password changed successfully! You will now be logged out. Please login with your new password.");
      setIsChanging(false);
      onComplete();
    }, 2000);
  };

  const strength = passwordStrength(newPassword);

  return (
    <div className="h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 p-6 overflow-hidden">
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-center gap-4 mb-3">
            <div className="w-14 h-14 bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg">
              <KeyRound className="w-7 h-7 text-white" />
            </div>
            <div className="text-left">
              <h1 className="text-2xl text-gray-800">Change Your Password</h1>
              <p className="text-sm text-gray-600">Create a strong password to secure your account</p>
            </div>
          </div>
        </div>

        {/* Main Card */}
        <div className="bg-white rounded-2xl shadow-2xl border border-gray-100 p-8 flex-1 overflow-hidden flex flex-col">
          {/* First-Time Login Flow Indicator */}
          <div className="mb-6 p-4 bg-gradient-to-r from-purple-50 via-pink-50 to-blue-50 rounded-xl border-2 border-purple-200">
            <div className="text-sm text-center text-gray-700 mb-3 font-medium">First-Time Login Process</div>
            <div className="flex items-center justify-center gap-3">
              <div className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg shadow-md">
                <CheckCircle className="w-4 h-4" />
                <span className="text-sm">Login</span>
              </div>
              <div className="text-gray-400">→</div>
              <div className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg shadow-md">
                <CheckCircle className="w-4 h-4" />
                <span className="text-sm">Google Auth</span>
              </div>
              <div className="text-gray-400">→</div>
              <div className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg shadow-lg">
                <KeyRound className="w-4 h-4" />
                <span className="text-sm font-semibold">Password Change</span>
              </div>
              <div className="text-gray-400">→</div>
              <span className="px-4 py-2 bg-gray-200 text-gray-600 rounded-lg text-sm">Re-login</span>
            </div>
          </div>

          {/* Main Content - 2 Column Layout */}
          <div className="flex-1 grid grid-cols-2 gap-10 overflow-y-auto">
            {/* Left Column - Password Form */}
            <div className="space-y-5">
              {/* Info Banner */}
              <div className="p-5 bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-xl shadow-sm">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Info className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-sm text-blue-900">
                    <p className="font-semibold mb-1">First Time Login - Password Change Required</p>
                    <p className="text-blue-800">For security reasons, you must change your password before accessing the system.</p>
                  </div>
                </div>
              </div>

              {/* Current Password */}
              <div>
                <label className="block text-sm text-gray-700 mb-2 font-medium">
                  Current Password <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type={showCurrentPassword ? "text" : "password"}
                    value={currentPassword}
                    onChange={(e) => {
                      setCurrentPassword(e.target.value);
                      setError("");
                    }}
                    className="w-full pl-12 pr-12 py-3.5 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 focus:ring-4 focus:ring-purple-100 transition-all"
                    placeholder="Enter your current password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-colors"
                  >
                    {showCurrentPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* New Password */}
              <div>
                <label className="block text-sm text-gray-700 mb-2 font-medium">
                  New Password <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type={showNewPassword ? "text" : "password"}
                    value={newPassword}
                    onChange={(e) => {
                      setNewPassword(e.target.value);
                      setError("");
                    }}
                    className="w-full pl-12 pr-12 py-3.5 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 focus:ring-4 focus:ring-purple-100 transition-all"
                    placeholder="Create a strong password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-colors"
                  >
                    {showNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>

                {/* Password Strength Indicator */}
                {newPassword && (
                  <div className="mt-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-gray-600 font-medium">Password Strength:</span>
                      <span className={`text-xs font-bold px-2 py-1 rounded ${
                        strength.label === "Weak" ? "bg-red-100 text-red-700" :
                        strength.label === "Fair" ? "bg-yellow-100 text-yellow-700" :
                        strength.label === "Good" ? "bg-blue-100 text-blue-700" :
                        "bg-green-100 text-green-700"
                      }`}>
                        {strength.label}
                      </span>
                    </div>
                    <div className="w-full h-2.5 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-500 ${strength.color}`}
                        style={{ width: `${strength.strength}%` }}
                      ></div>
                    </div>
                  </div>
                )}
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-sm text-gray-700 mb-2 font-medium">
                  Confirm New Password <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type={showConfirmPassword ? "text" : "password"}
                    value={confirmPassword}
                    onChange={(e) => {
                      setConfirmPassword(e.target.value);
                      setError("");
                    }}
                    className="w-full pl-12 pr-12 py-3.5 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 focus:ring-4 focus:ring-purple-100 transition-all"
                    placeholder="Re-enter your new password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-colors"
                  >
                    {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>

                {/* Password Match Indicator */}
                {newPassword && confirmPassword && (
                  <div className="mt-2">
                    {newPassword === confirmPassword ? (
                      <div className="flex items-center gap-2 text-green-600 bg-green-50 px-3 py-2 rounded-lg">
                        <Check className="w-4 h-4" />
                        <p className="text-xs font-medium">Passwords match</p>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-red-600 bg-red-50 px-3 py-2 rounded-lg">
                        <X className="w-4 h-4" />
                        <p className="text-xs font-medium">Passwords do not match</p>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Error Message */}
              {error && (
                <div className="p-4 bg-red-50 border-2 border-red-200 rounded-xl shadow-sm">
                  <div className="flex items-center gap-2 text-red-600">
                    <AlertCircle className="w-5 h-5" />
                    <span className="text-sm font-medium">{error}</span>
                  </div>
                </div>
              )}

              {/* Submit Button */}
              <button
                onClick={handleChangePassword}
                disabled={isChanging}
                className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-xl transition-all shadow-xl shadow-purple-200 disabled:opacity-50 disabled:cursor-not-allowed text-base font-semibold"
              >
                {isChanging ? (
                  <>
                    <div className="w-5 h-5 border-3 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Changing Password...</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-5 h-5" />
                    <span>Change Password</span>
                  </>
                )}
              </button>
            </div>

            {/* Right Column - Requirements & Tips */}
            <div className="flex flex-col justify-center space-y-5">
              {/* Password Requirements */}
              <div className="p-6 bg-gradient-to-br from-gray-50 to-slate-50 rounded-xl border-2 border-gray-200 shadow-sm">
                <p className="text-sm text-gray-800 font-semibold mb-4 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-gray-700" />
                  Password Requirements:
                </p>
                <div className="grid grid-cols-1 gap-3">
                  {passwordRules.map((rule, index) => (
                    <div key={index} className="flex items-center gap-3 p-2.5 bg-white rounded-lg border border-gray-200">
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                        rule.met ? "bg-green-500 shadow-md shadow-green-200" : "bg-gray-300"
                      }`}>
                        {rule.met && <Check className="w-4 h-4 text-white" />}
                      </div>
                      <span className={`text-sm ${rule.met ? "text-green-700 font-medium" : "text-gray-600"}`}>
                        {rule.text}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Security Tip */}
              <div className="p-6 bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-300 rounded-xl shadow-md">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 bg-green-600 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Check className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-sm text-green-900">
                    <p className="font-semibold mb-2.5">Security Tips</p>
                    <ul className="space-y-2 text-green-800">
                      <li className="flex items-start gap-2">
                        <span className="text-green-600 mt-0.5">•</span>
                        <span>Use a unique password that you don't use elsewhere</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-green-600 mt-0.5">•</span>
                        <span>Avoid using personal information in your password</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-green-600 mt-0.5">•</span>
                        <span>Consider using a password manager</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-green-600 mt-0.5">•</span>
                        <span>Never share your password with anyone</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Info Box */}
              <div className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-300 rounded-xl shadow-md">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 bg-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
                    <KeyRound className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-sm text-purple-900">
                    <p className="font-semibold mb-2">What happens next?</p>
                    <p className="text-purple-800">After changing your password, you'll be automatically logged out and redirected to the login page. Use your new credentials along with Google Authenticator to log back in.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center mt-6 text-sm text-gray-500 border-t border-gray-200 pt-5">
            <p>eNach Version 25.11.18 • Designed & Developed By SOFT-TECH SOLUTIONS</p>
          </div>
        </div>
      </div>
    </div>
  );
}
