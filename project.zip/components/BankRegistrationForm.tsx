import { Shield, ChevronDown } from "lucide-react";
import { useState } from "react";

export function BankRegistrationForm() {
  const [formData, setFormData] = useState({
    bankName: "",
    bankCode: "",
    address: "",
    mobileNo: "",
    emailId: "",
    base: false,
    itrValidation: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
  };

  const handleCancel = () => {
    setFormData({
      bankName: "",
      bankCode: "",
      address: "",
      mobileNo: "",
      emailId: "",
      base: false,
      itrValidation: false,
    });
  };

  return (
    <div className="w-full max-w-2xl bg-[#f0f1f3] rounded-3xl shadow-2xl p-12">
      {/* Header */}
      <div className="flex flex-col items-center mb-8">
        <div className="w-24 h-24 bg-[#2c4a62] rounded-full flex items-center justify-center mb-4">
          <Shield className="w-12 h-12 text-white" strokeWidth={2} />
        </div>
        <h1 className="text-[#2a2a2a] tracking-wide">BANK REGISTRATION</h1>
      </div>

      <form onSubmit={handleSubmit}>
        {/* Form Fields */}
        <div className="space-y-4 mb-6">
          {/* Bank Name */}
          <div className="grid grid-cols-[140px_1fr] gap-4 items-center">
            <label className="text-[#5a5a5a]">Bank Name</label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Text Input"
                value={formData.bankName}
                onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                className="flex-1 px-4 py-3 border border-[#d0d0d0] rounded-lg bg-white placeholder:text-[#c0c0c0] focus:outline-none focus:border-[#2c4a62]"
              />
              <input
                type="text"
                placeholder="Text Input"
                className="flex-1 px-4 py-3 border border-[#d0d0d0] rounded-lg bg-white placeholder:text-[#c0c0c0] focus:outline-none focus:border-[#2c4a62]"
              />
            </div>
          </div>

          {/* Bank Code */}
          <div className="grid grid-cols-[140px_1fr] gap-4 items-center">
            <label className="text-[#5a5a5a]">Bank Code</label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="IIN Number"
                value={formData.bankCode}
                onChange={(e) => setFormData({ ...formData, bankCode: e.target.value })}
                className="flex-1 px-4 py-3 border border-[#d0d0d0] rounded-lg bg-white placeholder:text-[#c0c0c0] focus:outline-none focus:border-[#2c4a62]"
              />
              <input
                type="text"
                placeholder="Text Input"
                className="flex-1 px-4 py-3 border border-[#d0d0d0] rounded-lg bg-white placeholder:text-[#c0c0c0] focus:outline-none focus:border-[#2c4a62]"
              />
            </div>
          </div>

          {/* Address */}
          <div className="grid grid-cols-[140px_1fr] gap-4 items-center">
            <label className="text-[#5a5a5a]">Address</label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="IIN Area"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="flex-1 px-4 py-3 border border-[#d0d0d0] rounded-lg bg-white placeholder:text-[#c0c0c0] focus:outline-none focus:border-[#2c4a62]"
              />
              <input
                type="text"
                placeholder="Text Input"
                className="flex-1 px-4 py-3 border border-[#d0d0d0] rounded-lg bg-white placeholder:text-[#c0c0c0] focus:outline-none focus:border-[#2c4a62]"
              />
            </div>
          </div>

          {/* Mobile No */}
          <div className="grid grid-cols-[140px_1fr] gap-4 items-center">
            <label className="text-[#5a5a5a]">Mobile No</label>
            <div className="relative">
              <select
                value={formData.mobileNo}
                onChange={(e) => setFormData({ ...formData, mobileNo: e.target.value })}
                className="w-full px-4 py-3 border border-[#d0d0d0] rounded-lg bg-white text-[#c0c0c0] appearance-none focus:outline-none focus:border-[#2c4a62]"
              >
                <option value="">Textarea</option>
                <option value="mobile1">Mobile 1</option>
                <option value="mobile2">Mobile 2</option>
              </select>
              <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#a0a0a0] pointer-events-none" />
            </div>
          </div>

          {/* Email Id */}
          <div className="grid grid-cols-[140px_1fr] gap-4 items-center">
            <label className="text-[#5a5a5a]">Email Id</label>
            <div className="relative">
              <select
                value={formData.emailId}
                onChange={(e) => setFormData({ ...formData, emailId: e.target.value })}
                className="w-full px-4 py-3 border border-[#d0d0d0] rounded-lg bg-white text-[#c0c0c0] appearance-none focus:outline-none focus:border-[#2c4a62]"
              >
                <option value="">Terail Input</option>
                <option value="email1">Email 1</option>
                <option value="email2">Email 2</option>
              </select>
              <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#a0a0a0] pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Required Modules */}
        <div className="mb-8">
          <div className="grid grid-cols-[140px_1fr] gap-4">
            <div className="text-[#4a4a4a] pt-3">REQUIRED MODULES</div>
            <div className="flex items-center gap-8">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.base}
                  onChange={(e) => setFormData({ ...formData, base: e.target.checked })}
                  className="w-6 h-6 border-2 border-[#d0d0d0] rounded-full appearance-none checked:border-[#2c4a62] checked:border-8 cursor-pointer"
                />
                <span className="text-[#5a5a5a]">Base</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.itrValidation}
                  onChange={(e) => setFormData({ ...formData, itrValidation: e.target.checked })}
                  className="w-6 h-6 border-2 border-[#d0d0d0] rounded-full appearance-none checked:border-[#2c4a62] checked:border-8 cursor-pointer"
                />
                <span className="text-[#5a5a5a]">ITR Validation</span>
              </label>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-4">
          <button
            type="button"
            onClick={handleCancel}
            className="px-12 py-3 border-2 border-[#d0d0d0] rounded-lg text-[#4a4a4a] bg-white hover:bg-gray-50 transition-colors"
          >
            CANCEL
          </button>
          <button
            type="submit"
            className="px-12 py-3 bg-[#2c4a62] text-white rounded-lg hover:bg-[#233847] transition-colors"
          >
            REGISTER
          </button>
        </div>
      </form>
    </div>
  );
}