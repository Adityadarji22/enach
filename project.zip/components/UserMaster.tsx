import { useState } from "react";
import { 
  Users, 
  Search, 
  Plus, 
  Upload, 
  Edit, 
  Trash2, 
  X, 
  Eye, 
  EyeOff,
  RotateCcw,
  Lock,
  Unlock,
  QrCode,
  AlertTriangle
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface User {
  id: number;
  username: string;
  personName: string;
  role: string;
  contactNo: string;
  email: string;
  branch: string;
  lastLogin: string;
  status: "Active" | "Inactive";
  lockStatus: "Locked" | "Unlocked";
  googleAuth: boolean;
  entryBy: string;
  entryDate: string;
}

export function UserMaster() {
  const [users, setUsers] = useState<User[]>([
    {
      id: 1,
      username: "Aditya",
      personName: "Aditya Darji",
      role: "User",
      contactNo: "7359015381",
      email: "Aditya@soft-techsolutions.com",
      branch: "Head Office",
      lastLogin: "2024-11-15 10:30 AM",
      status: "Active",
      lockStatus: "Unlocked",
      googleAuth: true,
      entryBy: "Admin",
      entryDate: "2024-11-10"
    }
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [confirmAction, setConfirmAction] = useState<{
    type: "lock" | "unlock" | "reset" | "regenerate" | "delete";
    user: User | null;
    message: string;
  } | null>(null);
  
  const [formData, setFormData] = useState({
    branch: "",
    username: "",
    userRole: "",
    password: "",
    confirmPassword: "",
    personName: "",
    contactNo: "",
    email: ""
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // Mock data for dropdowns
  const branches = ["Head Office", "Mumbai Branch", "Delhi Branch", "Bangalore Branch"];
  const roles = ["Admin", "User", "Manager", "Auditor"];

  const handleAddUser = () => {
    setEditingUser(null);
    setFormData({
      branch: "",
      username: "",
      userRole: "",
      password: "",
      confirmPassword: "",
      personName: "",
      contactNo: "",
      email: ""
    });
    setShowAddModal(true);
  };

  const handleEditUser = (user: User) => {
    setEditingUser(user);
    setFormData({
      branch: user.branch,
      username: user.username,
      userRole: user.role,
      password: "",
      confirmPassword: "",
      personName: user.personName,
      contactNo: user.contactNo,
      email: user.email
    });
    setShowAddModal(true);
  };

  const handleSaveUser = () => {
    // Validation
    if (!formData.branch || !formData.username || !formData.userRole || !formData.personName || !formData.contactNo || !formData.email) {
      toast.error("Please fill all required fields");
      return;
    }

    if (!editingUser && (!formData.password || !formData.confirmPassword)) {
      toast.error("Password is required");
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      toast.error("Please enter a valid email address");
      return;
    }

    // Contact number validation
    const contactRegex = /^\d{10}$/;
    if (!contactRegex.test(formData.contactNo)) {
      toast.error("Please enter a valid 10-digit contact number");
      return;
    }

    if (editingUser) {
      // Update existing user
      setUsers(users.map(u =>
        u.id === editingUser.id
          ? {
              ...u,
              branch: formData.branch,
              username: formData.username,
              role: formData.userRole,
              personName: formData.personName,
              contactNo: formData.contactNo,
              email: formData.email
            }
          : u
      ));
      toast.success("User updated successfully");
    } else {
      // Add new user
      const newUser: User = {
        id: Math.max(...users.map(u => u.id), 0) + 1,
        username: formData.username,
        personName: formData.personName,
        role: formData.userRole,
        contactNo: formData.contactNo,
        email: formData.email,
        branch: formData.branch,
        lastLogin: "-",
        status: "Active",
        lockStatus: "Unlocked",
        googleAuth: false,
        entryBy: "Admin",
        entryDate: new Date().toISOString().split('T')[0]
      };
      setUsers([...users, newUser]);
      toast.success("User added successfully");
    }
    setShowAddModal(false);
  };

  const showConfirmation = (type: "lock" | "unlock" | "reset" | "regenerate" | "delete", user: User) => {
    let message = "";
    switch (type) {
      case "lock":
        message = `Are you sure you want to lock user "${user.username}"? This will prevent them from logging in.`;
        break;
      case "unlock":
        message = `Are you sure you want to unlock user "${user.username}"? They will be able to log in again.`;
        break;
      case "reset":
        message = `Are you sure you want to reset the password for user "${user.username}"? A reset email will be sent to ${user.email}.`;
        break;
      case "regenerate":
        message = `Are you sure you want to regenerate the QR code for user "${user.username}"? This will invalidate the current Google Authenticator setup.`;
        break;
      case "delete":
        message = `Are you sure you want to delete user "${user.username}"? This action cannot be undone.`;
        break;
    }
    
    setConfirmAction({ type, user, message });
    setShowConfirmDialog(true);
  };

  const executeConfirmedAction = () => {
    if (!confirmAction || !confirmAction.user) return;

    const { type, user } = confirmAction;

    switch (type) {
      case "lock":
      case "unlock":
        setUsers(users.map(u =>
          u.id === user.id
            ? { ...u, lockStatus: type === "lock" ? "Locked" : "Unlocked" }
            : u
        ));
        toast.success(`User ${type === "lock" ? "locked" : "unlocked"} successfully`);
        break;
      
      case "reset":
        toast.success(`Password reset email sent to ${user.email}`);
        break;
      
      case "regenerate":
        toast.success(`QR code regenerated for ${user.username}. Please ask the user to re-configure Google Authenticator.`);
        break;
      
      case "delete":
        setUsers(users.filter(u => u.id !== user.id));
        toast.success("User deleted successfully");
        break;
    }

    setShowConfirmDialog(false);
    setConfirmAction(null);
  };

  const handleImport = () => {
    if (!selectedFile) {
      toast.error("Please select a file to import");
      return;
    }
    toast.success("Users imported successfully");
    setShowImportModal(false);
    setSelectedFile(null);
  };

  const handleDownloadSample = () => {
    toast.info("Downloading sample file...");
    // In a real application, this would download a sample CSV/Excel file
  };

  const filteredUsers = users.filter(user =>
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.personName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Pagination calculations
  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentUsers = filteredUsers.slice(startIndex, endIndex);

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-gray-800">User Master</h2>
              <p className="text-xs text-gray-600">Manage system users and their access</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowImportModal(true)}
              className="flex items-center gap-2 px-4 py-2 border border-orange-500 text-orange-600 rounded-lg hover:bg-orange-50 transition-colors"
            >
              <Upload className="w-4 h-4" />
              <span className="text-sm">Import User</span>
            </button>
            <button
              onClick={handleAddUser}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-lg hover:from-orange-600 hover:to-orange-700 transition-all shadow-lg shadow-orange-200"
            >
              <Plus className="w-4 h-4" />
              <span className="text-sm">Add User</span>
            </button>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center gap-4">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search by username, name, or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
            />
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto px-6 py-4">
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-left text-xs text-gray-600">Username</th>
                <th className="px-4 py-3 text-left text-xs text-gray-600">Person Name</th>
                <th className="px-4 py-3 text-left text-xs text-gray-600">Contact Details</th>
                <th className="px-4 py-3 text-left text-xs text-gray-600">Last Login</th>
                <th className="px-4 py-3 text-left text-xs text-gray-600">Status</th>
                <th className="px-4 py-3 text-left text-xs text-gray-600">Lock Status</th>
                <th className="px-4 py-3 text-left text-xs text-gray-600">Google Auth</th>
                <th className="px-4 py-3 text-left text-xs text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {currentUsers.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="text-sm text-gray-800">{user.username}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-sm text-gray-800">{user.personName}</div>
                    <div className="text-xs text-gray-500">{user.role}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-sm text-gray-800">{user.contactNo}</div>
                    <div className="text-xs text-gray-500">{user.email}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-sm text-gray-600">{user.lastLogin}</div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs ${
                      user.status === "Active"
                        ? "bg-green-100 text-green-700"
                        : "bg-gray-100 text-gray-700"
                    }`}>
                      {user.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => showConfirmation(user.lockStatus === "Locked" ? "unlock" : "lock", user)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition-colors ${
                        user.lockStatus === "Locked"
                          ? "bg-red-100 text-red-700 hover:bg-red-200"
                          : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    >
                      {user.lockStatus === "Locked" ? (
                        <Lock className="w-3 h-3" />
                      ) : (
                        <Unlock className="w-3 h-3" />
                      )}
                      <span>{user.lockStatus}</span>
                    </button>
                  </td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => showConfirmation("regenerate", user)}
                      className="inline-flex items-center gap-2 px-3 py-1.5 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors text-xs"
                      title="Regenerate QR Code"
                    >
                      <QrCode className="w-3.5 h-3.5" />
                      <span>Regenerate QR</span>
                    </button>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => showConfirmation("reset", user)}
                        className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                        title="Reset Password"
                      >
                        <RotateCcw className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleEditUser(user)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Edit"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => showConfirmation("delete", user)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filteredUsers.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <Users className="w-12 h-12 mx-auto mb-3 text-gray-400" />
              <p>No users found</p>
            </div>
          )}
        </div>
      </div>

      {/* Pagination */}
      <div className="bg-white border-t border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <select
              value={itemsPerPage}
              onChange={(e) => {
                setItemsPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="px-3 py-1.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm"
            >
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
            <span className="text-sm text-gray-600">
              Showing {startIndex + 1} to {Math.min(endIndex, filteredUsers.length)} of {filteredUsers.length} entries
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Previous
            </button>
            
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <button
                key={page}
                onClick={() => setCurrentPage(page)}
                className={`px-3 py-1.5 rounded-lg text-sm transition-colors ${
                  currentPage === page
                    ? "bg-orange-500 text-white"
                    : "border border-gray-300 text-gray-700 hover:bg-gray-50"
                }`}
              >
                {page}
              </button>
            ))}

            <button
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
              className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {/* Confirmation Dialog */}
      {showConfirmDialog && confirmAction && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
            <div className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                  confirmAction.type === "delete" ? "bg-red-100" :
                  confirmAction.type === "lock" ? "bg-orange-100" :
                  confirmAction.type === "unlock" ? "bg-green-100" :
                  "bg-blue-100"
                }`}>
                  <AlertTriangle className={`w-6 h-6 ${
                    confirmAction.type === "delete" ? "text-red-600" :
                    confirmAction.type === "lock" ? "text-orange-600" :
                    confirmAction.type === "unlock" ? "text-green-600" :
                    "text-blue-600"
                  }`} />
                </div>
                <div className="flex-1">
                  <h3 className="text-gray-800">
                    {confirmAction.type === "delete" ? "Delete User" :
                     confirmAction.type === "lock" ? "Lock User" :
                     confirmAction.type === "unlock" ? "Unlock User" :
                     confirmAction.type === "reset" ? "Reset Password" :
                     "Regenerate QR Code"}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {confirmAction.message}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 mt-6">
                <button
                  onClick={() => {
                    setShowConfirmDialog(false);
                    setConfirmAction(null);
                  }}
                  className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={executeConfirmedAction}
                  className={`px-6 py-2 rounded-lg transition-all shadow-lg ${
                    confirmAction.type === "delete"
                      ? "bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 shadow-red-200"
                      : confirmAction.type === "lock"
                      ? "bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-orange-200"
                      : "bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 shadow-blue-200"
                  } text-white`}
                >
                  Confirm
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit User Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h3 className="text-gray-800">
                {editingUser ? "Edit User" : "Add User"}
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* User Details */}
              <div>
                <h4 className="text-sm text-gray-700 mb-4">User Details</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className="block text-sm text-gray-700 mb-2">
                      Branch <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.branch}
                      onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    >
                      <option value="">Select Branch</option>
                      {branches.map(branch => (
                        <option key={branch} value={branch}>{branch}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Username <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.username}
                      onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="Enter username"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      User Role <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.userRole}
                      onChange={(e) => setFormData({ ...formData, userRole: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    >
                      <option value="">Select Role</option>
                      {roles.map(role => (
                        <option key={role} value={role}>{role}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Password {!editingUser && <span className="text-red-500">*</span>}
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? "text" : "password"}
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        className="w-full px-4 py-2 pr-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        placeholder="Enter password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Confirm Password {!editingUser && <span className="text-red-500">*</span>}
                    </label>
                    <div className="relative">
                      <input
                        type={showConfirmPassword ? "text" : "password"}
                        value={formData.confirmPassword}
                        onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                        className="w-full px-4 py-2 pr-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        placeholder="Confirm password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact Details */}
              <div>
                <h4 className="text-sm text-gray-700 mb-4">Contact Details</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className="block text-sm text-gray-700 mb-2">
                      Person Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.personName}
                      onChange={(e) => setFormData({ ...formData, personName: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="Enter person name"
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Contact No. <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.contactNo}
                      onChange={(e) => setFormData({ ...formData, contactNo: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="Enter contact number"
                      maxLength={10}
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Email Id <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="Enter email address"
                    />
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
                <button
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveUser}
                  className="px-6 py-2 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-lg hover:from-orange-600 hover:to-orange-700 transition-all shadow-lg shadow-orange-200"
                >
                  Submit
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Import User Modal */}
      {showImportModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
            <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h3 className="text-gray-800">Import User</h3>
              <button
                onClick={() => {
                  setShowImportModal(false);
                  setSelectedFile(null);
                }}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm text-gray-700 mb-2">Browse</label>
                <div className="flex items-center gap-3">
                  <input
                    type="file"
                    accept=".csv,.xlsx,.xls"
                    onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                    className="flex-1 text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:bg-orange-50 file:text-orange-600 hover:file:bg-orange-100"
                  />
                </div>
                {selectedFile && (
                  <p className="text-xs text-gray-600 mt-2">Selected: {selectedFile.name}</p>
                )}
              </div>

              <div className="text-center">
                <button
                  onClick={handleDownloadSample}
                  className="text-sm text-blue-600 hover:text-blue-700 hover:underline"
                >
                  Download sample file
                </button>
              </div>

              <button
                onClick={handleImport}
                className="w-full px-6 py-2 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-lg hover:from-orange-600 hover:to-orange-700 transition-all shadow-lg shadow-orange-200"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
