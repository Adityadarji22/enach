import { useState } from "react";
import { Shield, Smartphone, Check, AlertCircle, Download, Scan, CheckCircle } from "lucide-react";

interface GoogleAuthSetupProps {
  onComplete: () => void;
}

export function GoogleAuthSetup({ onComplete }: GoogleAuthSetupProps) {
  const [currentStep, setCurrentStep] = useState(1); // 1: Scan QR, 2: Verify
  const [verificationCode, setVerificationCode] = useState<string[]>(["", "", "", "", "", ""]);
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState("");

  // Generate a mock QR code URL (in real app, this would come from backend)
  const secretKey = "JBSWY3DPEHPK3PXP"; // Mock secret
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=otpauth://totp/eNACH:admin@bank?secret=${secretKey}&issuer=eNACH`;

  const handleVerify = () => {
    const code = verificationCode.join("");
    if (!code || code.length !== 6) {
      setError("Please enter a valid 6-digit code");
      return;
    }

    setIsVerifying(true);
    setError("");

    // Simulate verification
    setTimeout(() => {
      // In real app, verify the code with backend
      if (code === "123456" || code.length === 6) {
        onComplete();
      } else {
        setError("Invalid verification code. Please try again.");
      }
      setIsVerifying(false);
    }, 1500);
  };

  const handleCodeChange = (index: number, value: string) => {
    // Only allow numbers
    const numericValue = value.replace(/\D/g, "");
    if (numericValue.length > 1) return;

    const newCode = [...verificationCode];
    newCode[index] = numericValue;
    setVerificationCode(newCode);
    setError("");

    // Auto-focus next input
    if (numericValue && index < 5) {
      const nextInput = document.getElementById(`code-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !verificationCode[index] && index > 0) {
      const prevInput = document.getElementById(`code-${index - 1}`);
      prevInput?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
    const newCode = pastedData.split("").concat(Array(6).fill("")).slice(0, 6);
    setVerificationCode(newCode);
  };

  return (
    <div className="h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-6 overflow-hidden">
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-center gap-4 mb-3">
            <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Shield className="w-7 h-7 text-white" />
            </div>
            <div className="text-left">
              <h1 className="text-2xl text-gray-800">Enable Two-Factor Authentication</h1>
              <p className="text-sm text-gray-600">Secure your account with Google Authenticator</p>
            </div>
          </div>
        </div>

        {/* Main Card */}
        <div className="bg-white rounded-2xl shadow-2xl border border-gray-100 p-8 flex-1 overflow-hidden flex flex-col">
          {/* First-Time Login Flow Indicator */}
          <div className="mb-6 p-4 bg-gradient-to-r from-blue-50 via-indigo-50 to-purple-50 rounded-xl border-2 border-blue-200">
            <div className="text-sm text-center text-gray-700 mb-3 font-medium">First-Time Login Process</div>
            <div className="flex items-center justify-center gap-3">
              <div className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg shadow-md">
                <CheckCircle className="w-4 h-4" />
                <span className="text-sm">Login</span>
              </div>
              <div className="text-gray-400">→</div>
              <div className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg shadow-lg">
                <Shield className="w-4 h-4" />
                <span className="text-sm font-semibold">Google Auth Setup</span>
              </div>
              <div className="text-gray-400">→</div>
              <span className="px-4 py-2 bg-gray-200 text-gray-600 rounded-lg text-sm">Password Change</span>
              <div className="text-gray-400">→</div>
              <span className="px-4 py-2 bg-gray-200 text-gray-600 rounded-lg text-sm">Re-login</span>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 overflow-y-auto">
            {currentStep === 1 ? (
              /* Step 1: Scan QR Code */
              <div className="grid grid-cols-2 gap-10 h-full">
                {/* Left Column - QR Code & Continue Button */}
                <div className="flex flex-col justify-center items-center space-y-6">
                  {/* QR Code Section */}
                  <div className="flex flex-col items-center">
                    <div className="p-8 bg-white rounded-2xl border-4 border-blue-200 shadow-xl mb-4 hover:border-blue-400 transition-all">
                      <img 
                        src={qrCodeUrl} 
                        alt="Google Authenticator QR Code" 
                        className="w-64 h-64"
                      />
                    </div>
                    
                    {/* Secret Key */}
                    <div className="w-full max-w-md">
                      <p className="text-xs text-gray-600 mb-2 text-center font-medium">
                        Can't scan? Enter this key manually:
                      </p>
                      <div className="flex items-center justify-center gap-3 p-4 bg-gradient-to-r from-gray-100 to-gray-50 rounded-lg border-2 border-gray-300 shadow-sm">
                        <code className="text-sm font-mono text-gray-800 tracking-widest font-semibold">
                          {secretKey}
                        </code>
                      </div>
                    </div>
                  </div>

                  {/* Continue Button */}
                  <button
                    onClick={() => setCurrentStep(2)}
                    className="flex items-center justify-center gap-3 px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl transition-all shadow-xl shadow-blue-200 text-base font-semibold"
                  >
                    <Check className="w-5 h-5" />
                    <span>I've Scanned - Continue to Verify</span>
                  </button>
                </div>

                {/* Right Column - Setup Instructions */}
                <div className="flex flex-col justify-center space-y-6">
                  {/* Step Indicator */}
                  <div className="flex items-center justify-between mb-6">
                <div className="flex flex-col items-center gap-2">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-all ${
                    currentStep >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-300 text-gray-600'
                  }`}>
                    <Download className="w-6 h-6" />
                  </div>
                  <span className={`text-xs font-medium ${currentStep >= 1 ? 'text-gray-700' : 'text-gray-500'}`}>Download App</span>
                </div>
                <div className={`flex-1 h-1 mx-3 rounded transition-all ${
                  currentStep >= 1 ? 'bg-gradient-to-r from-blue-600 to-blue-400' : 'bg-gray-300'
                }`}></div>
                <div className="flex flex-col items-center gap-2">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-all ${
                    currentStep >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-300 text-gray-600'
                  }`}>
                    <Scan className="w-6 h-6" />
                  </div>
                  <span className={`text-xs font-medium ${currentStep >= 1 ? 'text-gray-700' : 'text-gray-500'}`}>Scan QR</span>
                </div>
                <div className={`flex-1 h-1 mx-3 rounded transition-all ${
                  currentStep >= 2 ? 'bg-gradient-to-r from-blue-600 to-blue-400' : 'bg-gray-300'
                }`}></div>
                <div className="flex flex-col items-center gap-2">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                    currentStep >= 2 ? 'bg-blue-600 text-white shadow-lg' : 'bg-gray-300 text-gray-600'
                  }`}>
                    <Check className="w-6 h-6" />
                  </div>
                  <span className={`text-xs font-medium ${currentStep >= 2 ? 'text-gray-700' : 'text-gray-500'}`}>Verify</span>
                </div>
              </div>

              {/* Instructions */}
              <div className="p-6 bg-white rounded-xl border border-gray-200 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Smartphone className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-base text-gray-800 font-semibold">Setup Instructions</h3>
                </div>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-semibold flex-shrink-0 mt-0.5">1</div>
                    <p className="text-sm text-gray-700">Download <span className="font-semibold text-gray-900">Google Authenticator</span> app from your app store</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-semibold flex-shrink-0 mt-0.5">2</div>
                    <p className="text-sm text-gray-700">Open the app and tap the <span className="font-semibold text-gray-900">+</span> button</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-semibold flex-shrink-0 mt-0.5">3</div>
                    <p className="text-sm text-gray-700">Select <span className="font-semibold text-gray-900">"Scan a QR code"</span></p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-semibold flex-shrink-0 mt-0.5">4</div>
                    <p className="text-sm text-gray-700">Scan the QR code shown on the left</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-semibold flex-shrink-0 mt-0.5">5</div>
                    <p className="text-sm text-gray-700">Enter the 6-digit code displayed in the app</p>
                  </div>
                </div>
              </div>

              {/* Security Note */}
              <div className="p-5 bg-gradient-to-br from-yellow-50 to-amber-50 border-2 border-yellow-300 rounded-xl shadow-md">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-yellow-500 rounded-lg flex items-center justify-center flex-shrink-0">
                    <AlertCircle className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-sm text-yellow-900">
                    <p className="font-semibold mb-1.5">Important Security Note</p>
                    <p className="text-yellow-800">Save your secret key in a safe place. You'll need it if you lose access to your device or need to set up 2FA on a new device.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
            ) : (
              /* Step 2: Verify Code */
              <div className="h-full flex items-center justify-center">
                <div className="max-w-2xl w-full space-y-6">
                  <div className="p-8 bg-gradient-to-br from-indigo-50 via-purple-50 to-blue-50 rounded-2xl border-3 border-purple-300 shadow-lg">
                    <label className="block text-gray-800 mb-6 text-center text-lg font-semibold">
                      Enter 6-Digit Verification Code
                    </label>
                    
                    {/* 6-digit OTP input boxes */}
                    <div className="flex justify-center gap-3 mb-6" onPaste={handlePaste}>
                      {verificationCode.map((digit, index) => (
                        <input
                          key={index}
                          id={`code-${index}`}
                          type="text"
                          inputMode="numeric"
                          maxLength={1}
                          value={digit}
                          onChange={(e) => handleCodeChange(index, e.target.value)}
                          onKeyDown={(e) => handleKeyDown(index, e)}
                          className="w-16 h-16 text-center text-2xl font-bold border-3 border-gray-300 rounded-xl focus:outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-100 transition-all shadow-sm"
                        />
                      ))}
                    </div>

                    {error && (
                      <div className="flex items-center justify-center gap-2 text-red-600 text-sm mb-4 bg-red-50 p-3 rounded-lg border border-red-200">
                        <AlertCircle className="w-4 h-4" />
                        <span>{error}</span>
                      </div>
                    )}

                    <div className="flex gap-3">
                      <button
                        onClick={() => setCurrentStep(1)}
                        className="flex-1 flex items-center justify-center gap-2 px-6 py-4 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-xl transition-all text-base font-semibold"
                      >
                        Back to QR Code
                      </button>
                      <button
                        onClick={handleVerify}
                        disabled={isVerifying || verificationCode.join("").length !== 6}
                        className="flex-1 flex items-center justify-center gap-3 px-6 py-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl transition-all shadow-xl shadow-blue-200 disabled:opacity-50 disabled:cursor-not-allowed text-base font-semibold"
                      >
                        {isVerifying ? (
                          <>
                            <div className="w-5 h-5 border-3 border-white border-t-transparent rounded-full animate-spin" />
                            <span>Verifying...</span>
                          </>
                        ) : (
                          <>
                            <Check className="w-5 h-5" />
                            <span>Verify and Continue</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Security Note */}
                  <div className="p-5 bg-gradient-to-br from-yellow-50 to-amber-50 border-2 border-yellow-300 rounded-xl shadow-md">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-yellow-500 rounded-lg flex items-center justify-center flex-shrink-0">
                        <AlertCircle className="w-5 h-5 text-white" />
                      </div>
                      <div className="text-sm text-yellow-900">
                        <p className="font-semibold mb-1.5">Important Security Note</p>
                        <p className="text-yellow-800">Save your secret key in a safe place. You'll need it if you lose access to your device or need to set up 2FA on a new device.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="text-center mt-6 text-sm text-gray-500 border-t border-gray-200 pt-5">
            <p>eNach Version 25.11.18 • Designed & Developed By SOFT-TECH SOLUTIONS</p>
          </div>
        </div>
      </div>
    </div>
  );
}
