import { useState } from "react";
import { 
  Play, 
  Download, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Clock,
  Key,
  Shield,
  Link2,
  Calendar,
  FileText,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  Loader2
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface CheckResult {
  status: 'success' | 'warning' | 'error';
  message: string;
  details?: any;
}

interface ModuleCheck {
  moduleName: string;
  checks: {
    publicKeys: CheckResult[];
    privateKeys: CheckResult[];
    apis: CheckResult[];
    expiry: CheckResult[];
  };
}

export function Troubleshooting() {
  const [isRunning, setIsRunning] = useState(false);
  const [hasResults, setHasResults] = useState(false);
  const [expandedSections, setExpandedSections] = useState<string[]>([]);
  const [results, setResults] = useState<ModuleCheck[]>([]);

  // Mock data for demonstration
  const mockResults: ModuleCheck[] = [
    {
      moduleName: "API Mandate",
      checks: {
        publicKeys: [
          {
            status: 'success',
            message: 'NPCI Signing Certificate',
            details: {
              issuedTo: 'NPCI',
              issuedBy: 'IDRBT Sub CA 2022',
              validFrom: '2024-10-08T10:02:59.000+00:00',
              validTill: '2026-10-08T18:29:59.000+00:00',
              serialNumber: '7F71BB77ZDFADCD06877',
              signatureAlgorithm: 'SHA256withRSA'
            }
          },
          {
            status: 'success',
            message: 'NPCI Encryption Certificate',
            details: {
              issuedTo: 'NPCI',
              issuedBy: 'IDRBT Sub CA 2022',
              validFrom: '2024-10-08T10:06:03.000+00:00',
              validTill: '2026-10-08T18:29:59.000+00:00',
              serialNumber: 'SCAAAA89FC871C7B01FC',
              signatureAlgorithm: 'SHA256withRSA'
            }
          }
        ],
        privateKeys: [
          {
            status: 'success',
            message: 'SSL Certificate',
            details: {
              path: 'E:\\My_Workspace\\Certificates\\ssl.pfx',
              issuedTo: 'BankServer',
              issuedBy: 'IDRBT Sub CA 2022',
              validFrom: '2024-10-08T10:02:59.000+00:00',
              validTill: '2026-01-15T18:29:59.000+00:00',
              serialNumber: '7F71BB77ZDFADCD06877',
              signatureAlgorithm: 'SHA256withRSA',
              keyPairValid: true,
              passwordValid: true
            }
          },
          {
            status: 'warning',
            message: 'Bank Signing Certificate',
            details: {
              path: 'E:\\My_Workspace\\Certificates\\bank_sign.pfx',
              issuedTo: 'BUCB0000001',
              issuedBy: 'IDRBT Sub CA 2022',
              validFrom: '2024-10-08T10:02:59.000+00:00',
              validTill: '2025-10-08T18:29:59.000+00:00',
              serialNumber: '7F71BB77ZDFADCD06877',
              signatureAlgorithm: 'SHA256withRSA',
              keyPairValid: true,
              passwordValid: true,
              warning: 'Certificate expiring in 90 days'
            }
          },
          {
            status: 'success',
            message: 'Bank Encryption Certificate',
            details: {
              path: 'E:\\My_Workspace\\Certificates\\bank_enc.pfx',
              issuedTo: 'BUCB000000SC',
              issuedBy: 'IDRBT Sub CA 2022',
              validFrom: '2024-10-08T10:06:03.000+00:00',
              validTill: '2026-10-08T18:29:59.000+00:00',
              serialNumber: 'SCAAAA89FC871C7B01FC',
              signatureAlgorithm: 'SHA256withRSA',
              keyPairValid: true,
              passwordValid: true
            }
          }
        ],
        apis: [
          {
            status: 'success',
            message: 'Account Validation API',
            details: {
              endpoint: 'https://api.bank.com/validate-account',
              method: 'POST',
              responseTime: '245ms',
              statusCode: 200,
              request: {
                accountNumber: '1234567890',
                ifsc: 'SBIN0001234'
              },
              response: {
                status: 'success',
                accountHolder: 'John Doe',
                accountType: 'Savings'
              }
            }
          },
          {
            status: 'success',
            message: 'Mandate Insert API',
            details: {
              endpoint: 'https://api.npci.com/mandate/insert',
              method: 'POST',
              responseTime: '312ms',
              statusCode: 200,
              request: {
                mandateId: 'MND123456',
                amount: '5000'
              },
              response: {
                status: 'success',
                transactionId: 'TXN789012'
              }
            }
          }
        ],
        expiry: [
          {
            status: 'warning',
            message: 'Bank Signing Certificate expiring soon',
            details: {
              certificateName: 'Bank Signing Certificate',
              expiryDate: '2025-10-08',
              daysRemaining: 90
            }
          },
          {
            status: 'success',
            message: 'API Mandate License valid',
            details: {
              licenseName: 'API Mandate License',
              expiryDate: '2026-12-31',
              daysRemaining: 400
            }
          }
        ]
      }
    },
    {
      moduleName: "ITR",
      checks: {
        publicKeys: [
          {
            status: 'success',
            message: 'NPCI Signing Certificate',
            details: {
              issuedTo: 'NPCI',
              issuedBy: 'IDRBT Sub CA 2022',
              validFrom: '2024-10-08T10:02:59.000+00:00',
              validTill: '2026-10-08T18:29:59.000+00:00',
              serialNumber: '7F71BB77ZDFADCD06877',
              signatureAlgorithm: 'SHA256withRSA'
            }
          }
        ],
        privateKeys: [
          {
            status: 'success',
            message: 'Bank Signing Certificate',
            details: {
              path: 'E:\\My_Workspace\\ITR\\Certificates\\sign.pfx',
              issuedTo: 'BUCB0000001',
              issuedBy: 'IDRBT Sub CA 2022',
              validFrom: '2024-10-08T10:02:59.000+00:00',
              validTill: '2026-10-08T18:29:59.000+00:00',
              serialNumber: '7F71BB77ZDFADCD06877',
              signatureAlgorithm: 'SHA256withRSA',
              keyPairValid: true,
              passwordValid: true
            }
          }
        ],
        apis: [
          {
            status: 'success',
            message: 'Account Validation API',
            details: {
              endpoint: 'https://api.itr.npci.com/validate',
              method: 'POST',
              responseTime: '198ms',
              statusCode: 200,
              request: {
                accountNumber: '1234567890'
              },
              response: {
                status: 'success',
                valid: true
              }
            }
          }
        ],
        expiry: [
          {
            status: 'success',
            message: 'ITR License valid',
            details: {
              licenseName: 'ITR License',
              expiryDate: '2026-12-31',
              daysRemaining: 400
            }
          }
        ]
      }
    },
    {
      moduleName: "BASE",
      checks: {
        publicKeys: [
          {
            status: 'success',
            message: 'NPCI Signing Certificate',
            details: {
              issuedTo: 'NPCI',
              issuedBy: 'IDRBT Sub CA 2022',
              validFrom: '2024-10-08T10:02:59.000+00:00',
              validTill: '2026-10-08T18:29:59.000+00:00',
              serialNumber: '7F71BB77ZDFADCD06877',
              signatureAlgorithm: 'SHA256withRSA'
            }
          }
        ],
        privateKeys: [
          {
            status: 'success',
            message: 'Bank Encryption Certificate',
            details: {
              path: 'E:\\My_Workspace\\BASE\\Certificates\\enc.pfx',
              issuedTo: 'BUCB000000SC',
              issuedBy: 'IDRBT Sub CA 2022',
              validFrom: '2024-10-08T10:06:03.000+00:00',
              validTill: '2026-10-08T18:29:59.000+00:00',
              serialNumber: 'SCAAAA89FC871C7B01FC',
              signatureAlgorithm: 'SHA256withRSA',
              keyPairValid: true,
              passwordValid: true
            }
          }
        ],
        apis: [],
        expiry: [
          {
            status: 'success',
            message: 'BASE License valid',
            details: {
              licenseName: 'BASE License',
              expiryDate: '2026-12-31',
              daysRemaining: 400
            }
          }
        ]
      }
    }
  ];

  const toggleSection = (sectionId: string) => {
    setExpandedSections(prev => 
      prev.includes(sectionId) 
        ? prev.filter(id => id !== sectionId)
        : [...prev, sectionId]
    );
  };

  const runChecklist = async () => {
    setIsRunning(true);
    setHasResults(false);
    
    // Simulate running checks
    await new Promise(resolve => setTimeout(resolve, 2500));
    
    setResults(mockResults);
    setHasResults(true);
    setIsRunning(false);
    
    // Expand all sections by default
    const allSections: string[] = [];
    mockResults.forEach((module, moduleIndex) => {
      allSections.push(`module-${moduleIndex}`);
      allSections.push(`publicKeys-${moduleIndex}`);
      allSections.push(`privateKeys-${moduleIndex}`);
      allSections.push(`apis-${moduleIndex}`);
      allSections.push(`expiry-${moduleIndex}`);
    });
    setExpandedSections(allSections);
    
    toast.success('System checklist completed successfully');
  };

  const exportToPDF = async () => {
    // Import jsPDF dynamically
    const { jsPDF } = await import('jspdf');
    
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.width;
    const pageHeight = doc.internal.pageSize.height;
    let currentPage = 1;
    
    // Helper function to add page number
    const addPageNumber = () => {
      doc.setFontSize(9);
      doc.setTextColor(150, 150, 150);
      doc.text(`Page ${currentPage}`, pageWidth - 20, pageHeight - 10, { align: 'right' });
      currentPage++;
    };
    
    // Helper function to draw a table manually
    const drawTable = (startY: number, headers: string[], rows: string[][], options: any = {}) => {
      const {
        headerBg = [59, 130, 246],
        headerText = [255, 255, 255],
        rowBg1 = [255, 255, 255],
        rowBg2 = [248, 250, 252],
        textColor = [51, 65, 85],
        colWidths = []
      } = options;
      
      let y = startY;
      const rowHeight = 8;
      const padding = 2;
      const startX = 15;
      const totalWidth = pageWidth - 30;
      
      // Calculate column widths
      const columnWidths = colWidths.length > 0 ? colWidths : 
        headers.map(() => totalWidth / headers.length);
      
      // Draw header
      doc.setFillColor(...headerBg);
      doc.rect(startX, y, totalWidth, rowHeight, 'F');
      doc.setTextColor(...headerText);
      doc.setFontSize(9);
      
      let x = startX + padding;
      headers.forEach((header, i) => {
        doc.text(header, x, y + 6);
        x += columnWidths[i];
      });
      
      y += rowHeight;
      
      // Draw rows
      rows.forEach((row, rowIndex) => {
        // Alternate row colors
        if (rowIndex % 2 === 0) {
          doc.setFillColor(...rowBg1);
        } else {
          doc.setFillColor(...rowBg2);
        }
        doc.rect(startX, y, totalWidth, rowHeight, 'F');
        
        // Draw cell borders
        doc.setDrawColor(226, 232, 240);
        doc.rect(startX, y, totalWidth, rowHeight);
        
        doc.setTextColor(...textColor);
        doc.setFontSize(8);
        
        x = startX + padding;
        row.forEach((cell, i) => {
          // Truncate text if too long
          const maxWidth = columnWidths[i] - padding * 2;
          let displayText = cell;
          
          while (doc.getTextWidth(displayText) > maxWidth && displayText.length > 0) {
            displayText = displayText.substring(0, displayText.length - 1);
          }
          
          if (displayText !== cell && displayText.length > 3) {
            displayText = displayText.substring(0, displayText.length - 3) + '...';
          }
          
          doc.text(displayText, x, y + 6);
          x += columnWidths[i];
        });
        
        y += rowHeight;
      });
      
      return y;
    };
    
    // Header with gradient background (simulated with rectangle)
    doc.setFillColor(139, 92, 246); // Purple
    doc.rect(0, 0, pageWidth, 45, 'F');
    
    // Title
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(24);
    doc.text('eNACH System Checklist Report', pageWidth / 2, 20, { align: 'center' });
    
    // Subtitle
    doc.setFontSize(11);
    doc.setTextColor(240, 240, 255);
    doc.text('Comprehensive System Health & Configuration Analysis', pageWidth / 2, 30, { align: 'center' });
    
    // Generation details box
    doc.setFillColor(248, 250, 252);
    doc.rect(15, 50, pageWidth - 30, 25, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.rect(15, 50, pageWidth - 30, 25);
    
    doc.setTextColor(51, 65, 85);
    doc.setFontSize(10);
    doc.text(`Generated: ${new Date().toLocaleString('en-US', { 
      dateStyle: 'full', 
      timeStyle: 'short' 
    })}`, 20, 60);
    
    // Stats summary
    doc.text(`Total Checks: ${stats.total}`, 20, 67);
    doc.setTextColor(34, 197, 94);
    doc.text(`Passed: ${stats.success}`, 70, 67);
    doc.setTextColor(234, 179, 8);
    doc.text(`Warnings: ${stats.warning}`, 115, 67);
    doc.setTextColor(239, 68, 68);
    doc.text(`Errors: ${stats.error}`, 160, 67);
    
    let yPos = 85;
    
    // Process each module
    results.forEach((module, moduleIndex) => {
      // Check if we need a new page
      if (yPos > 250) {
        addPageNumber();
        doc.addPage();
        yPos = 20;
      }
      
      // Module header with colored background
      doc.setFillColor(237, 233, 254); // Light purple
      doc.rect(15, yPos, pageWidth - 30, 12, 'F');
      doc.setDrawColor(139, 92, 246);
      doc.rect(15, yPos, pageWidth - 30, 12);
      
      doc.setFontSize(14);
      doc.setTextColor(109, 40, 217);
      doc.text(`${module.moduleName} Module`, 20, yPos + 8);
      yPos += 20;
      
      // Public Keys Section
      if (module.checks.publicKeys.length > 0) {
        if (yPos > 230) {
          addPageNumber();
          doc.addPage();
          yPos = 20;
        }
        
        doc.setFillColor(219, 234, 254);
        doc.rect(15, yPos, pageWidth - 30, 8, 'F');
        doc.setFontSize(11);
        doc.setTextColor(30, 64, 175);
        doc.text('Public Key Certificates', 20, yPos + 6);
        yPos += 12;
        
        const publicKeyData = module.checks.publicKeys.map(check => [
          check.message,
          check.details?.issuedTo || 'N/A',
          check.details ? new Date(check.details.validTill).toLocaleDateString() : 'N/A',
          check.status === 'success' ? 'Valid' : check.status === 'warning' ? 'Warning' : 'Error'
        ]);
        
        yPos = drawTable(yPos, 
          ['Certificate', 'Issued To', 'Valid Till', 'Status'],
          publicKeyData,
          {
            headerBg: [59, 130, 246],
            colWidths: [60, 45, 40, 35]
          }
        );
        
        yPos += 8;
      }
      
      // Private Keys Section
      if (module.checks.privateKeys.length > 0) {
        if (yPos > 220) {
          addPageNumber();
          doc.addPage();
          yPos = 20;
        }
        
        doc.setFillColor(243, 232, 255);
        doc.rect(15, yPos, pageWidth - 30, 8, 'F');
        doc.setFontSize(11);
        doc.setTextColor(109, 40, 217);
        doc.text('Private Key Certificates', 20, yPos + 6);
        yPos += 12;
        
        const privateKeyData = module.checks.privateKeys.map(check => [
          check.message,
          check.details?.issuedTo || 'N/A',
          check.details ? new Date(check.details.validTill).toLocaleDateString() : 'N/A',
          check.details?.keyPairValid ? 'Yes' : 'No',
          check.details?.passwordValid ? 'Yes' : 'No',
          check.status === 'success' ? 'Valid' : check.status === 'warning' ? 'Warning' : 'Error'
        ]);
        
        yPos = drawTable(yPos, 
          ['Certificate', 'Issued To', 'Valid Till', 'Key Pair', 'Password', 'Status'],
          privateKeyData,
          {
            headerBg: [147, 51, 234],
            colWidths: [45, 30, 30, 20, 20, 25]
          }
        );
        
        yPos += 8;
      }
      
      // API Tests Section
      if (module.checks.apis.length > 0) {
        if (yPos > 220) {
          addPageNumber();
          doc.addPage();
          yPos = 20;
        }
        
        doc.setFillColor(220, 252, 231);
        doc.rect(15, yPos, pageWidth - 30, 8, 'F');
        doc.setFontSize(11);
        doc.setTextColor(22, 163, 74);
        doc.text('API Service Tests', 20, yPos + 6);
        yPos += 12;
        
        const apiData = module.checks.apis.map(check => [
          check.message,
          check.details?.method || 'N/A',
          check.details?.statusCode?.toString() || 'N/A',
          check.details?.responseTime || 'N/A',
          check.status === 'success' ? 'Success' : check.status === 'warning' ? 'Warning' : 'Failed'
        ]);
        
        yPos = drawTable(yPos, 
          ['API Name', 'Method', 'Status', 'Time', 'Result'],
          apiData,
          {
            headerBg: [34, 197, 94],
            colWidths: [55, 25, 25, 25, 30]
          }
        );
        
        yPos += 8;
      }
      
      // Expiry Checks Section
      if (module.checks.expiry.length > 0) {
        if (yPos > 220) {
          addPageNumber();
          doc.addPage();
          yPos = 20;
        }
        
        doc.setFillColor(254, 243, 199);
        doc.rect(15, yPos, pageWidth - 30, 8, 'F');
        doc.setFontSize(11);
        doc.setTextColor(217, 119, 6);
        doc.text('License & Certificate Expiry', 20, yPos + 6);
        yPos += 12;
        
        const expiryData = module.checks.expiry.map(check => [
          check.details?.licenseName || check.details?.certificateName || 'N/A',
          check.details?.expiryDate ? new Date(check.details.expiryDate).toLocaleDateString() : 'N/A',
          check.details?.daysRemaining ? `${check.details.daysRemaining} days` : 'N/A',
          check.status === 'success' ? 'Valid' : check.status === 'warning' ? 'Expiring Soon' : 'Expired'
        ]);
        
        yPos = drawTable(yPos, 
          ['Item Name', 'Expiry Date', 'Days Left', 'Status'],
          expiryData,
          {
            headerBg: [245, 158, 11],
            colWidths: [60, 40, 35, 45]
          }
        );
        
        yPos += 15;
      }
    });
    
    // Footer on last page
    addPageNumber();
    
    // Add footer note
    doc.setFillColor(248, 250, 252);
    doc.rect(0, pageHeight - 25, pageWidth, 25, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.line(0, pageHeight - 25, pageWidth, pageHeight - 25);
    
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text('This report was automatically generated by eNACH Banking Application', pageWidth / 2, pageHeight - 15, { align: 'center' });
    doc.text('For support, contact your system administrator', pageWidth / 2, pageHeight - 10, { align: 'center' });
    
    // Save PDF
    doc.save(`eNACH-System-Report-${new Date().toISOString().split('T')[0]}.pdf`);
    toast.success('Beautiful PDF report exported successfully!');
  };

  const getStatusIcon = (status: 'success' | 'warning' | 'error') => {
    switch (status) {
      case 'success':
        return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-600" />;
      case 'error':
        return <XCircle className="w-5 h-5 text-red-600" />;
    }
  };

  const getStatusBadge = (status: 'success' | 'warning' | 'error') => {
    const styles = {
      success: 'bg-green-100 text-green-800 border-green-300',
      warning: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      error: 'bg-red-100 text-red-800 border-red-300'
    };
    
    const labels = {
      success: 'Configured',
      warning: 'Warning',
      error: 'Error'
    };
    
    return (
      <span className={`px-3 py-1 rounded-full text-xs border ${styles[status]} flex items-center gap-1`}>
        {getStatusIcon(status)}
        {labels[status]}
      </span>
    );
  };

  const getTotalStats = () => {
    if (!hasResults) return { total: 0, success: 0, warning: 0, error: 0 };
    
    let total = 0, success = 0, warning = 0, error = 0;
    
    results.forEach(module => {
      Object.values(module.checks).forEach(checks => {
        checks.forEach(check => {
          total++;
          if (check.status === 'success') success++;
          if (check.status === 'warning') warning++;
          if (check.status === 'error') error++;
        });
      });
    });
    
    return { total, success, warning, error };
  };

  const stats = getTotalStats();

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl text-gray-900">System Troubleshooting</h1>
              <p className="text-sm text-gray-600">Run comprehensive system checks and generate reports</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {hasResults && (
              <button
                onClick={exportToPDF}
                className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Export PDF
              </button>
            )}
            <button
              onClick={runChecklist}
              disabled={isRunning}
              className="px-6 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg hover:from-purple-700 hover:to-blue-700 transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isRunning ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Running Checks...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Run Checklist
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 py-6">
        <div className="max-w-7xl mx-auto">
          {!hasResults && !isRunning && (
            <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-100 to-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-10 h-10 text-purple-600" />
              </div>
              <h3 className="text-lg text-gray-900 mb-2">Ready to Run System Checklist</h3>
              <p className="text-sm text-gray-600 mb-6 max-w-md mx-auto">
                Click the "Run Checklist" button to perform comprehensive system checks including certificates, APIs, and license validation.
              </p>
              <div className="grid grid-cols-4 gap-4 max-w-3xl mx-auto">
                <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg">
                  <Key className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-700">Public Keys</p>
                </div>
                <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-lg">
                  <Shield className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-700">Private Keys</p>
                </div>
                <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-lg">
                  <Link2 className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-700">API Tests</p>
                </div>
                <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-4 rounded-lg">
                  <Calendar className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-700">Expiry Checks</p>
                </div>
              </div>
            </div>
          )}

          {isRunning && (
            <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
              <Loader2 className="w-16 h-16 text-purple-600 mx-auto mb-4 animate-spin" />
              <h3 className="text-lg text-gray-900 mb-2">Running System Checks...</h3>
              <p className="text-sm text-gray-600">Please wait while we validate your system configuration</p>
            </div>
          )}

          {hasResults && (
            <div className="space-y-6">
              {/* Stats Summary */}
              <div className="grid grid-cols-4 gap-4">
                <div className="bg-white rounded-lg border border-gray-200 p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Total Checks</p>
                      <p className="text-2xl text-gray-900 mt-1">{stats.total}</p>
                    </div>
                    <FileText className="w-8 h-8 text-gray-400" />
                  </div>
                </div>
                <div className="bg-white rounded-lg border border-green-200 p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-green-700">Passed</p>
                      <p className="text-2xl text-green-600 mt-1">{stats.success}</p>
                    </div>
                    <CheckCircle2 className="w-8 h-8 text-green-400" />
                  </div>
                </div>
                <div className="bg-white rounded-lg border border-yellow-200 p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-yellow-700">Warnings</p>
                      <p className="text-2xl text-yellow-600 mt-1">{stats.warning}</p>
                    </div>
                    <AlertTriangle className="w-8 h-8 text-yellow-400" />
                  </div>
                </div>
                <div className="bg-white rounded-lg border border-red-200 p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-red-700">Errors</p>
                      <p className="text-2xl text-red-600 mt-1">{stats.error}</p>
                    </div>
                    <XCircle className="w-8 h-8 text-red-400" />
                  </div>
                </div>
              </div>

              {/* Results by Module */}
              {results.map((module, moduleIndex) => (
                <div key={moduleIndex} className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                  {/* Module Header */}
                  <button
                    onClick={() => toggleSection(`module-${moduleIndex}`)}
                    className="w-full px-6 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white flex items-center justify-between hover:from-purple-700 hover:to-blue-700 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <Shield className="w-5 h-5" />
                      <span className="text-lg">{module.moduleName} Configuration</span>
                    </div>
                    {expandedSections.includes(`module-${moduleIndex}`) ? (
                      <ChevronUp className="w-5 h-5" />
                    ) : (
                      <ChevronDown className="w-5 h-5" />
                    )}
                  </button>

                  {expandedSections.includes(`module-${moduleIndex}`) && (
                    <div className="p-6 space-y-6">
                      {/* Public Keys Section */}
                      {module.checks.publicKeys.length > 0 && (
                        <div>
                          <button
                            onClick={() => toggleSection(`publicKeys-${moduleIndex}`)}
                            className="w-full flex items-center justify-between mb-4 group"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                                <Key className="w-5 h-5 text-blue-600" />
                              </div>
                              <div className="text-left">
                                <h3 className="text-base text-gray-900">Public Keys</h3>
                                <p className="text-xs text-gray-600">{module.checks.publicKeys.length} certificate(s)</p>
                              </div>
                            </div>
                            {expandedSections.includes(`publicKeys-${moduleIndex}`) ? (
                              <ChevronUp className="w-5 h-5 text-gray-400" />
                            ) : (
                              <ChevronDown className="w-5 h-5 text-gray-400" />
                            )}
                          </button>

                          {expandedSections.includes(`publicKeys-${moduleIndex}`) && (
                            <div className="space-y-3 ml-13">
                              {module.checks.publicKeys.map((check, idx) => (
                                <div key={idx} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                  <div className="flex items-start justify-between mb-3">
                                    <div className="flex items-center gap-2">
                                      {getStatusIcon(check.status)}
                                      <span className="text-sm text-gray-900">{check.message}</span>
                                    </div>
                                    {getStatusBadge(check.status)}
                                  </div>
                                  {check.details && (
                                    <div className="grid grid-cols-2 gap-3 text-xs">
                                      <div>
                                        <span className="text-gray-600">Issued To:</span>
                                        <span className="text-gray-900 ml-2">{check.details.issuedTo}</span>
                                      </div>
                                      <div>
                                        <span className="text-gray-600">Issued By:</span>
                                        <span className="text-gray-900 ml-2">{check.details.issuedBy}</span>
                                      </div>
                                      <div>
                                        <span className="text-gray-600">Valid From:</span>
                                        <span className="text-gray-900 ml-2">{new Date(check.details.validFrom).toLocaleDateString()}</span>
                                      </div>
                                      <div>
                                        <span className="text-gray-600">Valid Till:</span>
                                        <span className="text-gray-900 ml-2">{new Date(check.details.validTill).toLocaleDateString()}</span>
                                      </div>
                                      <div>
                                        <span className="text-gray-600">Serial Number:</span>
                                        <span className="text-gray-900 ml-2 font-mono">{check.details.serialNumber}</span>
                                      </div>
                                      <div>
                                        <span className="text-gray-600">Algorithm:</span>
                                        <span className="text-gray-900 ml-2">{check.details.signatureAlgorithm}</span>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Private Keys Section */}
                      {module.checks.privateKeys.length > 0 && (
                        <div>
                          <button
                            onClick={() => toggleSection(`privateKeys-${moduleIndex}`)}
                            className="w-full flex items-center justify-between mb-4 group"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center group-hover:bg-purple-200 transition-colors">
                                <Shield className="w-5 h-5 text-purple-600" />
                              </div>
                              <div className="text-left">
                                <h3 className="text-base text-gray-900">Private Keys</h3>
                                <p className="text-xs text-gray-600">{module.checks.privateKeys.length} certificate(s)</p>
                              </div>
                            </div>
                            {expandedSections.includes(`privateKeys-${moduleIndex}`) ? (
                              <ChevronUp className="w-5 h-5 text-gray-400" />
                            ) : (
                              <ChevronDown className="w-5 h-5 text-gray-400" />
                            )}
                          </button>

                          {expandedSections.includes(`privateKeys-${moduleIndex}`) && (
                            <div className="space-y-3 ml-13">
                              {module.checks.privateKeys.map((check, idx) => (
                                <div key={idx} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                  <div className="flex items-start justify-between mb-3">
                                    <div className="flex items-center gap-2">
                                      {getStatusIcon(check.status)}
                                      <span className="text-sm text-gray-900">{check.message}</span>
                                    </div>
                                    {getStatusBadge(check.status)}
                                  </div>
                                  {check.details?.warning && (
                                    <div className="bg-yellow-50 border border-yellow-200 rounded px-3 py-2 mb-3 text-xs text-yellow-800">
                                      {check.details.warning}
                                    </div>
                                  )}
                                  {check.details && (
                                    <div className="space-y-3">
                                      <div className="text-xs">
                                        <span className="text-gray-600">Path:</span>
                                        <span className="text-gray-900 ml-2 font-mono">{check.details.path}</span>
                                      </div>
                                      <div className="grid grid-cols-2 gap-3 text-xs">
                                        <div>
                                          <span className="text-gray-600">Issued To:</span>
                                          <span className="text-gray-900 ml-2">{check.details.issuedTo}</span>
                                        </div>
                                        <div>
                                          <span className="text-gray-600">Issued By:</span>
                                          <span className="text-gray-900 ml-2">{check.details.issuedBy}</span>
                                        </div>
                                        <div>
                                          <span className="text-gray-600">Valid From:</span>
                                          <span className="text-gray-900 ml-2">{new Date(check.details.validFrom).toLocaleDateString()}</span>
                                        </div>
                                        <div>
                                          <span className="text-gray-600">Valid Till:</span>
                                          <span className="text-gray-900 ml-2">{new Date(check.details.validTill).toLocaleDateString()}</span>
                                        </div>
                                        <div>
                                          <span className="text-gray-600">Serial Number:</span>
                                          <span className="text-gray-900 ml-2 font-mono">{check.details.serialNumber}</span>
                                        </div>
                                        <div>
                                          <span className="text-gray-600">Algorithm:</span>
                                          <span className="text-gray-900 ml-2">{check.details.signatureAlgorithm}</span>
                                        </div>
                                      </div>
                                      <div className="flex gap-4 pt-2">
                                        <div className="flex items-center gap-2">
                                          {check.details.keyPairValid ? (
                                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                                          ) : (
                                            <XCircle className="w-4 h-4 text-red-600" />
                                          )}
                                          <span className="text-xs text-gray-700">Key Pair Valid</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                          {check.details.passwordValid ? (
                                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                                          ) : (
                                            <XCircle className="w-4 h-4 text-red-600" />
                                          )}
                                          <span className="text-xs text-gray-700">Password Valid</span>
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}

                      {/* APIs Section */}
                      {module.checks.apis.length > 0 && (
                        <div>
                          <button
                            onClick={() => toggleSection(`apis-${moduleIndex}`)}
                            className="w-full flex items-center justify-between mb-4 group"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center group-hover:bg-green-200 transition-colors">
                                <Link2 className="w-5 h-5 text-green-600" />
                              </div>
                              <div className="text-left">
                                <h3 className="text-base text-gray-900">API Tests</h3>
                                <p className="text-xs text-gray-600">{module.checks.apis.length} endpoint(s)</p>
                              </div>
                            </div>
                            {expandedSections.includes(`apis-${moduleIndex}`) ? (
                              <ChevronUp className="w-5 h-5 text-gray-400" />
                            ) : (
                              <ChevronDown className="w-5 h-5 text-gray-400" />
                            )}
                          </button>

                          {expandedSections.includes(`apis-${moduleIndex}`) && (
                            <div className="space-y-3 ml-13">
                              {module.checks.apis.map((check, idx) => (
                                <div key={idx} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                  <div className="flex items-start justify-between mb-3">
                                    <div className="flex items-center gap-2">
                                      {getStatusIcon(check.status)}
                                      <span className="text-sm text-gray-900">{check.message}</span>
                                    </div>
                                    {getStatusBadge(check.status)}
                                  </div>
                                  {check.details && (
                                    <div className="space-y-3">
                                      <div className="grid grid-cols-3 gap-3 text-xs">
                                        <div className="col-span-3">
                                          <span className="text-gray-600">Endpoint:</span>
                                          <span className="text-gray-900 ml-2 font-mono">{check.details.endpoint}</span>
                                        </div>
                                        <div>
                                          <span className="text-gray-600">Method:</span>
                                          <span className="text-gray-900 ml-2">{check.details.method}</span>
                                        </div>
                                        <div>
                                          <span className="text-gray-600">Status Code:</span>
                                          <span className="text-green-600 ml-2">{check.details.statusCode}</span>
                                        </div>
                                        <div>
                                          <span className="text-gray-600">Response Time:</span>
                                          <span className="text-gray-900 ml-2">{check.details.responseTime}</span>
                                        </div>
                                      </div>
                                      <div className="grid grid-cols-2 gap-3">
                                        <div>
                                          <div className="text-xs text-gray-600 mb-2">Request Payload:</div>
                                          <pre className="bg-gray-900 text-green-400 p-3 rounded text-xs overflow-x-auto">
                                            {JSON.stringify(check.details.request, null, 2)}
                                          </pre>
                                        </div>
                                        <div>
                                          <div className="text-xs text-gray-600 mb-2">Response Payload:</div>
                                          <pre className="bg-gray-900 text-green-400 p-3 rounded text-xs overflow-x-auto">
                                            {JSON.stringify(check.details.response, null, 2)}
                                          </pre>
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Expiry Section */}
                      {module.checks.expiry.length > 0 && (
                        <div>
                          <button
                            onClick={() => toggleSection(`expiry-${moduleIndex}`)}
                            className="w-full flex items-center justify-between mb-4 group"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center group-hover:bg-orange-200 transition-colors">
                                <Calendar className="w-5 h-5 text-orange-600" />
                              </div>
                              <div className="text-left">
                                <h3 className="text-base text-gray-900">Expiry Checks</h3>
                                <p className="text-xs text-gray-600">{module.checks.expiry.length} item(s)</p>
                              </div>
                            </div>
                            {expandedSections.includes(`expiry-${moduleIndex}`) ? (
                              <ChevronUp className="w-5 h-5 text-gray-400" />
                            ) : (
                              <ChevronDown className="w-5 h-5 text-gray-400" />
                            )}
                          </button>

                          {expandedSections.includes(`expiry-${moduleIndex}`) && (
                            <div className="space-y-3 ml-13">
                              {module.checks.expiry.map((check, idx) => (
                                <div key={idx} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                  <div className="flex items-start justify-between mb-3">
                                    <div className="flex items-center gap-2">
                                      {getStatusIcon(check.status)}
                                      <span className="text-sm text-gray-900">{check.message}</span>
                                    </div>
                                    {getStatusBadge(check.status)}
                                  </div>
                                  {check.details && (
                                    <div className="grid grid-cols-3 gap-3 text-xs">
                                      <div>
                                        <span className="text-gray-600">Item:</span>
                                        <span className="text-gray-900 ml-2">{check.details.licenseName || check.details.certificateName}</span>
                                      </div>
                                      <div>
                                        <span className="text-gray-600">Expiry Date:</span>
                                        <span className="text-gray-900 ml-2">{new Date(check.details.expiryDate).toLocaleDateString()}</span>
                                      </div>
                                      <div>
                                        <span className="text-gray-600">Days Remaining:</span>
                                        <span className={`ml-2 ${check.details.daysRemaining < 90 ? 'text-yellow-600' : 'text-green-600'}`}>
                                          {check.details.daysRemaining} days
                                        </span>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
